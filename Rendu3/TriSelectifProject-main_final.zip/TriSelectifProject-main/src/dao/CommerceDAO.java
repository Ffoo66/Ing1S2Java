package dao;
import model.Adresse;
import model.Commerce;
import java.sql.*;
import java.util.UUID;
import java.util.ArrayList;
import java.util.List;

public class CommerceDAO {
    private Connection conn;

    public CommerceDAO(Connection conn) {
        this.conn = conn;
    }



        public List<Commerce> findAll() {
            List<Commerce> commerces = new ArrayList<>();
            String query = "SELECT * FROM commerce";
            try (PreparedStatement stmt = conn.prepareStatement(query);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("idcommerce");
                    String nom = rs.getString("nomcommerce");
                    int idAdresse = rs.getInt("adresse_id");

                    Adresse adresse = new AdresseDAO(conn).find(idAdresse);
                    if (adresse != null) {
                        commerces.add(new Commerce( id,nom, adresse));
                    }
                }
            } catch (SQLException e) {
                System.err.println("Erreur dans CommerceDAO.findAll : " + e.getMessage());
            }
            return commerces;
        }


    public void create(Commerce c, int adresseId) {
        String sql = "INSERT INTO Commerce (nomCommerce, adresse_id) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, c.getNomCommerce());
            stmt.setInt(2, adresseId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int generatedId = generatedKeys.getInt(1);
                        c.setIdCommerce(generatedId); // Set the ID back to the object
                        System.out.println("Commerce inséré avec ID : " + generatedId);
                    } else {
                        System.out.println("Échec de la récupération de l'ID généré.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Commerce find(int idCommerce) {
        //System.out.println("inside com find dao id comm 1"+idCommerce);

        String sql = "SELECT * FROM commerce WHERE idcommerce = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCommerce);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
               // System.out.println("inside com find dao id comm 2"+idCommerce);
                String nom = rs.getString("nomcommerce");
                int idAdresse = rs.getInt("adresse_id");

                Adresse adresse = new AdresseDAO(conn).find(idAdresse);
                if (adresse != null) {
                    Commerce commmerce = new Commerce(idCommerce,nom, adresse);
                    //System.out.println("in com dao"+commmerce.getIdCommerce());

                    return commmerce;
                } else {
                    System.err.println("Adresse non trouvée pour l'ID : " + idAdresse);
                }
            }
        } catch (SQLException e) {
            System.err.println("Erreur dans CommerceDAO.find : " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public void delete(UUID idCommerce) {
        String sql = "DELETE FROM Commerce WHERE idCommerce = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, idCommerce.toString());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Commerce supprimé avec succès.");
            } else {
                System.out.println("Aucun Commerce trouvé avec cet ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}