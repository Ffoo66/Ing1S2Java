package dao;
import main.Main;
import model.*;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.UUID;

public class MenageDAO {
    private Connection conn;

    public MenageDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean create(String nomCompte, String motDePasse, Adresse adresse) {
        String sql = "INSERT INTO Menage (nomCompte, motDePasse, adresse_id) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nomCompte);
            stmt.setString(2, motDePasse);
            stmt.setInt(3, adresse.getId());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public Menage setInfos(String nomCompte) {
        String sql = "SELECT m.nomCompte, m.motDePasse,m.pointsfidelite,m.id as menage_id,a.id, a.numero, a.nomRue, a.codePostal, a.ville " +
                "FROM Menage m JOIN Adresse a ON m.adresse_id = a.id " +
                "WHERE m.nomCompte = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nomCompte);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String mdp = rs.getString("motDePasse");
                int id= rs.getInt("menage_id");
                Adresse adresse = new Adresse(
                        rs.getInt("id"),
                        rs.getInt("numero"),
                        rs.getString("nomRue"),
                        rs.getInt("codePostal"),
                        rs.getString("ville")
                );
                int point=rs.getInt("pointsfidelite");
                System.out.println("point of setId :"+point);
                Menage menage= new Menage(nomCompte, mdp, adresse,point,id);
                // Populate deposit history

                HashMap<Integer, Depot> depotHistory = getDepotHistory(menage);
                menage.setHistorique(depotHistory);

                // Populate voucher history
                HashMap<Integer, BonReduction> bonReductionHistory = getBonReductionHistory(menage);
                menage.setMapBons(bonReductionHistory);
                menage.setPoints(point);
                return  menage;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
    // New method to fetch deposit history for a Menage
    private HashMap<Integer, Depot> getDepotHistory(Menage menage) {
        HashMap<Integer, Depot> depotHistory = new HashMap<>();
        String sql = "SELECT iddepot, poidsdepot, couleur, typedechet, resultat, pointsgagnes, datedepot, heuredepot, adresse_id " +
                "FROM Depot WHERE menage_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, menage.getId());
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int idDepot = rs.getInt("iddepot");
                int poidsDepot = rs.getInt("poidsdepot");
                String couleurStr = rs.getString("couleur");
                String typeDechetStr = rs.getString("typedechet");
                String resultatStr = rs.getString("resultat");
                int pointsGagnes = rs.getInt("pointsgagnes");
                LocalDate dateDepot = rs.getDate("datedepot") != null ? rs.getDate("datedepot").toLocalDate() : null;
                LocalTime heureDepot = rs.getTime("heuredepot") != null ? rs.getTime("heuredepot").toLocalTime() : null;
                int adresseId = rs.getInt("adresse_id");

                // Convert strings to enums

                Couleur couleur = Couleur.valueOf(couleurStr.toLowerCase());
                Type typeDechet = Type.valueOf(typeDechetStr.toLowerCase());
                ResCat resultat = ResCat.valueOf(resultatStr.toLowerCase());
                // Fetch Adresse
                 AdresseDAO ad=new AdresseDAO(conn);
                Adresse adresse = ad.find(adresseId);
                if (adresse == null) {
                    System.out.println("Adresse not found for adresse_id: " + adresseId);
                    continue; // Skip this depot if adresse cannot be found
                }


                Depot depot = new Depot(idDepot, poidsDepot, couleur, typeDechet, adresse, resultat, pointsGagnes, menage, dateDepot, heureDepot,10);
                //System.out.println("history of this menage"+depot);
                depotHistory.put(idDepot, depot);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return depotHistory;
    }

    public Menage find(String nomCompte) {
        String sql = "SELECT * FROM Menage WHERE nomCompte = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nomCompte);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String mdp = rs.getString("motDePasse");
                return new Menage(nomCompte, mdp, null);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Menage find(int  id) {
        String sql = "SELECT * FROM Menage WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int ida = rs.getInt("id");
                String mdp = rs.getString("motDePasse");
                String nomc = rs.getString("nomcompte");

                int pts = rs.getInt("pointsFidelite");
                Menage menage =new Menage(ida, nomc, pts);
                // Populate deposit history
                HashMap<Integer, Depot> depotHistory = getDepotHistory(menage);
                menage.setHistorique(depotHistory);

                // Populate voucher history
                HashMap<Integer, BonReduction> bonReductionHistory = getBonReductionHistory(menage);
                menage.setMapBons(bonReductionHistory);
                return menage;
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    // In MenageDAO.java
    private HashMap<Integer, BonReduction> getBonReductionHistory(Menage menage) {
        HashMap<Integer, BonReduction> bonReductionHistory = new HashMap<>();
        String sql = "SELECT idbon, bonUtilise, dateExpiration FROM BonReduction WHERE menage_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, menage.getId());
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int idBon = rs.getInt("idbon");
                boolean bonUtilise = rs.getBoolean("bonUtilise");
                LocalDate dateExp = rs.getDate("dateExpiration") != null ? rs.getDate("dateExpiration").toLocalDate() : null;

                BonReduction bon = new BonReduction(idBon, menage, bonUtilise, dateExp);
                bonReductionHistory.put(idBon, bon);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bonReductionHistory;
    }
    public void updatePoints(String nomCompte, int nouveauxPoints) {
        String sql = "UPDATE Menage SET pointsFidelite = ? WHERE nomCompte = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, nouveauxPoints);
            stmt.setString(2, nomCompte);
            stmt.executeUpdate();
            System.out.println("Points mis à jour.");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(String nomCompte) {
        String sql = "DELETE FROM Menage WHERE nomCompte = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nomCompte);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Ménage supprimé avec succès.");
            }
            else {
                System.out.println("Aucun Ménage trouvé avec ce nom de compte.");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean authentifier(String username, String password) {
        return true;
    }
}