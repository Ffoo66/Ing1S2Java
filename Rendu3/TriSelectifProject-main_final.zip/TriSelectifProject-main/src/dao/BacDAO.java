package dao;

import model.Adresse;
import model.Bac;
import model.CentreTri;
import model.Couleur;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BacDAO {
    private Connection conn;

    public BacDAO(Connection conn) {
        if (conn == null) {
            System.err.println("Attention: La connexion fournie est null!");
            // Vous pourriez considérer de lancer une exception ici plutôt que de continuer avec une connexion nulle
        }
        this.conn = conn;
        
        try {
            if (conn != null && conn.getAutoCommit()) {
                // Désactiver l'auto-commit pour gérer les transactions manuellement
                conn.setAutoCommit(false);
                System.out.println("Auto-commit désactivé pour les transactions manuelles");
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la désactivation de l'auto-commit: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Insère un nouveau bac dans la base de données.
     * @param bac Le bac à insérer
     * @param centreId L'ID du centre de tri associé
     * @param adresseId L'ID de l'adresse associée
     */
    public void create(Bac bac, int centreId, int adresseId) {
        String checkCentreSql = "SELECT idCentre FROM CentreTri WHERE idCentre = ?";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkCentreSql)) {
            checkStmt.setInt(1, centreId);
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next()) {
                throw new SQLException("Centre de tri avec id " + centreId + " n'existe pas");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Impossible de vérifier le centre_id", e);
        }

        String sql = "INSERT INTO Bac (idBac, centre_id, couleur, capacite, contenu, adresse_id, dateDerniereCollecte, prochaineCollecte) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, bac.getIdBac());
            stmt.setInt(2, centreId);
            stmt.setString(3, bac.getCouleurBac().name());
            stmt.setInt(4, bac.getCapacite());
            stmt.setInt(5, bac.getContenu());
            stmt.setInt(6, adresseId);
            stmt.setObject(7, bac.getDateDerniereCollecte() != null ? java.sql.Date.valueOf(bac.getDateDerniereCollecte()) : null);
            stmt.setObject(8, bac.getProchaineCollecte() != null ? java.sql.Date.valueOf(bac.getProchaineCollecte()) : null);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Bac ajouté avec succès (ID: " + bac.getIdBac() + ").");
                // Valider la transaction
                conn.commit();
            } else {
                System.err.println("Aucun bac inséré pour l'ID: " + bac.getIdBac());
                conn.rollback();
            }
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            throw new RuntimeException("Impossible d'insérer le bac", e);
        }
    }
    public boolean planifierCollecte(int idBac, LocalDate dateCollecte) throws SQLException {
        String sql = "UPDATE Bac SET prochaineCollecte = ? WHERE idBac = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, java.sql.Date.valueOf(dateCollecte));
            stmt.setInt(2, idBac);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }
    }
    /**
     * Recherche tous les bacs associés à un centre de tri.
     * @param centreId L'ID du centre de tri
     * @return Liste des bacs
     */
    public List<Bac> findAllByCentre(int centreId) {
        List<Bac> bacs = new ArrayList<>();
        String sql = "SELECT b.idBac, b.couleur, b.capacite, b.contenu, b.adresse_id, b.centre_id, " +
                "b.dateDerniereCollecte, b.prochaineCollecte, " +
                "a.id AS adresse_id, a.numero, a.nomRue, a.codePostal, a.ville " +
                "FROM Bac b LEFT JOIN Adresse a ON b.adresse_id = a.id WHERE b.centre_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, centreId);
            ResultSet rs = stmt.executeQuery();
            boolean found = false;
            while (rs.next()) {
                found = true;
                Adresse adresse = null;
                if (rs.getInt("adresse_id") != 0) { // Vérifier si l'adresse existe
                    adresse = new Adresse(
                            rs.getInt("adresse_id"),
                            rs.getInt("numero"),
                            rs.getString("nomRue"),
                            rs.getInt("codePostal"),
                            rs.getString("ville")
                    );
                }
                CentreTri centre = new CentreTriDAO(conn).find(rs.getInt("centre_id"));
                if (centre == null) {
                    System.out.println("Centre non trouvé pour centre_id: " + rs.getInt("centre_id"));
                    continue;
                }
                Bac bac = new Bac(
                        rs.getInt("idBac"),
                        centre,
                        Couleur.valueOf(rs.getString("couleur")),
                        rs.getInt("capacite")
                );
                bac.setContenu(rs.getInt("contenu"));
                bac.setAdresseBac(adresse);
                bac.setDateDerniereCollecte(rs.getDate("dateDerniereCollecte") != null ? rs.getDate("dateDerniereCollecte").toLocalDate() : null);
                bac.setProchaineCollecte(rs.getDate("prochaineCollecte") != null ? rs.getDate("prochaineCollecte").toLocalDate() : null);
                bacs.add(bac);
            }
            if (!found) {
                System.out.println("Aucun bac trouvé pour centreId: " + centreId);
            } else {
                System.out.println("Bacs trouvés pour centreId " + centreId + ": " + bacs.size());
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des bacs: " + e.getMessage());
            e.printStackTrace();
        }
        return bacs;
    }

    /**
     * Met à jour un bac dans la base de données.
     * @param bac Le bac à mettre à jour
     * @param adresseId L'ID de l'adresse associée
     */
    public boolean update(Bac bac, int adresseId) {
        String sql = "UPDATE Bac SET couleur = ?, capacite = ?, contenu = ?, adresse_id = ?, dateDerniereCollecte = ?, prochaineCollecte = ? WHERE idBac = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, bac.getCouleurBac().name());
            stmt.setInt(2, bac.getCapacite());
            stmt.setInt(3, bac.getContenu());
            stmt.setInt(4, adresseId);
            stmt.setObject(5, bac.getDateDerniereCollecte() != null ? java.sql.Date.valueOf(bac.getDateDerniereCollecte()) : null);
            stmt.setObject(6, bac.getProchaineCollecte() != null ? java.sql.Date.valueOf(bac.getProchaineCollecte()) : null);
            stmt.setInt(7, bac.getIdBac()); // Utiliser setInt pour un entier
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Bac mis à jour avec succès (ID: " + bac.getIdBac() + ")");
                conn.commit();
                return true;
            } else {
                System.err.println("Aucun bac mis à jour pour l'ID: " + bac.getIdBac());
                conn.rollback();
                return false;
            }
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Erreur lors de la mise à jour du bac: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public List<Bac> findBacsForSoonCollection(int centreId) {
        List<Bac> bacs = new ArrayList<>();
        String sql = "SELECT b.idBac, b.couleur, b.capacite, b.contenu, b.adresse_id, b.centre_id, " +
                "b.dateDerniereCollecte, b.prochaineCollecte, " +
                "a.id AS adresse_id, a.numero, a.nomRue, a.codePostal, a.ville " +
                "FROM Bac b LEFT JOIN Adresse a ON b.adresse_id = a.id " +
                "WHERE b.centre_id = ? AND (b.contenu >= b.capacite * 0.5 OR b.prochaineCollecte IS NOT NULL)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, centreId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Adresse adresse = null;
                if (rs.getInt("adresse_id") != 0) {
                    adresse = new Adresse(
                            rs.getInt("adresse_id"),
                            rs.getInt("numero"),
                            rs.getString("nomRue"),
                            rs.getInt("codePostal"),
                            rs.getString("ville")
                    );
                }
                CentreTri centre = new CentreTriDAO(conn).find(rs.getInt("centre_id"));
                if (centre == null) {
                    System.out.println("Centre non trouvé pour centre_id: " + rs.getInt("centre_id"));
                    continue;
                }
                Bac bac = new Bac(
                        rs.getInt("idBac"),
                        centre,
                        Couleur.valueOf(rs.getString("couleur")),
                        rs.getInt("capacite")
                );
                bac.setContenu(rs.getInt("contenu"));
                bac.setAdresseBac(adresse);
                bac.setDateDerniereCollecte(rs.getDate("dateDerniereCollecte") != null ? rs.getDate("dateDerniereCollecte").toLocalDate() : null);
                bac.setProchaineCollecte(rs.getDate("prochaineCollecte") != null ? rs.getDate("prochaineCollecte").toLocalDate() : null);
                bacs.add(bac);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des bacs à collecter: " + e.getMessage());
            e.printStackTrace();
        }
        return bacs;
    }

    public List<Bac> findBacsFiltered(int centreId, Couleur couleurFiltre, double seuilRemplissage) {
        List<Bac> bacs = new ArrayList<>();
        String sql = "SELECT b.idBac, b.couleur, b.capacite, b.contenu, b.adresse_id, b.centre_id, " +
                "b.dateDerniereCollecte, b.prochaineCollecte, " +
                "a.id AS adresse_id, a.numero, a.nomRue, a.codePostal, a.ville " +
                "FROM Bac b LEFT JOIN Adresse a ON b.adresse_id = a.id " +
                "WHERE b.centre_id = ? " +
                (couleurFiltre != null ? "AND b.couleur = ? " : "") +
                "AND (b.contenu >= b.capacite * ? OR b.prochaineCollecte IS NOT NULL)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, centreId);
            int paramIndex = 2;
            if (couleurFiltre != null) {
                stmt.setString(paramIndex++, couleurFiltre.name());
            }
            stmt.setDouble(paramIndex, seuilRemplissage);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Adresse adresse = null;
                if (rs.getInt("adresse_id") != 0) {
                    adresse = new Adresse(
                            rs.getInt("adresse_id"),
                            rs.getInt("numero"),
                            rs.getString("nomRue"),
                            rs.getInt("codePostal"),
                            rs.getString("ville")
                    );
                }
                CentreTri centre = new CentreTriDAO(conn).find(rs.getInt("centre_id"));
                if (centre == null) {
                    System.out.println("Centre non trouvé pour centre_id: " + rs.getInt("centre_id"));
                    continue;
                }
                Bac bac = new Bac(
                        rs.getInt("idBac"),
                        centre,
                        Couleur.valueOf(rs.getString("couleur")),
                        rs.getInt("capacite")
                );
                bac.setContenu(rs.getInt("contenu"));
                bac.setAdresseBac(adresse);
                bac.setDateDerniereCollecte(rs.getDate("dateDerniereCollecte") != null ? rs.getDate("dateDerniereCollecte").toLocalDate() : null);
                bac.setProchaineCollecte(rs.getDate("prochaineCollecte") != null ? rs.getDate("prochaineCollecte").toLocalDate() : null);
                bacs.add(bac);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des bacs filtrés: " + e.getMessage());
            e.printStackTrace();
        }
        return bacs;
    }

    public boolean collecterBac(int idBac) {
        String sql = "UPDATE Bac SET contenu = 0, dateDerniereCollecte = ?, prochaineCollecte = NULL WHERE idBac = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
            stmt.setInt(2, idBac); // Utiliser setInt pour un entier
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                conn.commit();
                return true;
            } else {
                conn.rollback();
                return false;
            }
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Erreur lors de la collecte du bac: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Supprime un bac de la base de données.
     * @param idBac L'ID du bac à supprimer
     */
    public void delete(int idBac) {
        if (conn == null) {
            System.err.println("Erreur: La connexion à la base de données est null");
            return;
        }
        
        String sql = "DELETE FROM Bac WHERE idBac = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idBac); // Utiliser setInt pour un entier
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Bac supprimé avec succès (ID: " + idBac + ").");
                if (!conn.getAutoCommit()) {
                    conn.commit();
                }
            } else {
                System.out.println("Aucun bac trouvé avec l'ID: " + idBac);
                if (!conn.getAutoCommit()) {
                    conn.rollback();
                }
            }
        } catch (SQLException e) {
            try {
                if (conn != null && !conn.getAutoCommit()) {
                    conn.rollback();
                }
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Erreur lors de la suppression du bac: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Met à jour l'adresse d'un bac dans la base de données.
     * @param idBac L'ID du bac à déplacer
     * @param adresseId L'ID de la nouvelle adresse
     * @return true si la mise à jour est réussie, false sinon
     */
    public boolean updateAdresse(int idBac, int adresseId) {
        if (conn == null) {
            System.err.println("Erreur: La connexion à la base de données est null");
            return false;
        }
        
        String sql = "UPDATE Bac SET adresse_id = ? WHERE idBac = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, adresseId);
            stmt.setInt(2, idBac); // Utiliser setInt pour un entier
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                if (!conn.getAutoCommit()) {
                    conn.commit();
                }
                return true;
            } else {
                if (!conn.getAutoCommit()) {
                    conn.rollback();
                }
                return false;
            }
        } catch (SQLException e) {
            try {
                if (conn != null && !conn.getAutoCommit()) {
                    conn.rollback();
                }
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Erreur lors de la mise à jour de l'adresse du bac: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Trouve toutes les adresses qui ont un bac de la couleur spécifiée.
     * @param couleur La couleur du bac recherché
     * @return Liste des adresses ayant des bacs de cette couleur
     */
    public List<Adresse> findAdressesByCouleur(Couleur couleur) {
        if (conn == null) {
            System.err.println("Erreur: La connexion à la base de données est null");
            return new ArrayList<>();
        }
        
        List<Adresse> adresses = new ArrayList<>();
        String sql = "SELECT DISTINCT a.* FROM Adresse a " +
                     "JOIN Bac b ON a.id = b.adresse_id " +
                     "WHERE b.couleur = ? AND b.adresse_id IS NOT NULL";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, couleur.name());
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                try {
                    Adresse adresse = new Adresse(
                        rs.getInt("id"),
                        rs.getInt("numero"),
                        rs.getString("nomrue"),
                        rs.getInt("codepostal"),
                        rs.getString("ville")
                    );
                    adresses.add(adresse);
                } catch (IllegalArgumentException e) {
                    System.err.println("Ignorer l'enregistrement d'adresse invalide : " + e.getMessage());
                }
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche d'adresses par couleur : " + e.getMessage());
            e.printStackTrace();
        }
        return adresses;
    }

    /**
     * Classe pour représenter le résultat de la mise à jour du contenu d'un bac
     */
    public static class BacUpdateResult {
        private final boolean success;
        private final int poidsAccepte;
        private final int capacite;
        private final int nouveauContenu;
        private final boolean capaciteDepassee;

        public BacUpdateResult(boolean success, int poidsAccepte, int capacite, int nouveauContenu) {
            this.success = success;
            this.poidsAccepte = poidsAccepte;
            this.capacite = capacite;
            this.nouveauContenu = nouveauContenu;
            this.capaciteDepassee = poidsAccepte < 0; // Si poidsAccepte est négatif, c'est qu'on a dépassé la capacité
        }

        public boolean isSuccess() {
            return success;
        }

        public int getPoidsAccepte() {
            return Math.abs(poidsAccepte); // Retourne toujours une valeur positive
        }

        public int getCapacite() {
            return capacite;
        }

        public int getNouveauContenu() {
            return nouveauContenu;
        }

        public boolean isCapaciteDepassee() {
            return capaciteDepassee;
        }
    }

    /**
     * Met à jour le contenu d'un bac en ajoutant le poids d'un nouveau dépôt.
     * Cette méthode recherche un bac par sa couleur et l'ID de son adresse,
     * puis ajoute le poids spécifié à son contenu actuel.
     * 
     * @param couleur La couleur du bac à mettre à jour
     * @param adresseId L'ID de l'adresse du bac
     * @param poidsAAjouter Le poids à ajouter au contenu existant
     * @return Un objet BacUpdateResult contenant les informations sur le résultat de la mise à jour
     */
    public BacUpdateResult updateContenuBacByCouleurAdresse(Couleur couleur, int adresseId, int poidsAAjouter) {
        if (conn == null) {
            System.err.println("Erreur: La connexion à la base de données est null");
            return new BacUpdateResult(false, 0, 0, 0);
        }
        
        // D'abord, récupérer le bac pour connaître son contenu actuel et sa capacité
        String selectSql = "SELECT idBac, contenu, capacite FROM Bac WHERE couleur = ? AND adresse_id = ?";
        try (PreparedStatement selectStmt = conn.prepareStatement(selectSql)) {
            selectStmt.setString(1, couleur.name());
            selectStmt.setInt(2, adresseId);
            ResultSet rs = selectStmt.executeQuery();
            
            if (rs.next()) {
                int idBac = rs.getInt("idBac");
                int contenuActuel = rs.getInt("contenu");
                int capacite = rs.getInt("capacite");
                
                // Calculer l'espace disponible dans le bac
                int espaceDisponible = capacite - contenuActuel;
                
                // Vérifier si le poids à ajouter dépasse l'espace disponible
                int poidsAccepte = poidsAAjouter;
                boolean capaciteDepassee = false;
                int nouveauContenu = contenuActuel;
                
                if (espaceDisponible <= 0) {
                    // Le bac est déjà plein, rien ne peut être ajouté
                    System.out.println("Attention: Le bac est déjà plein. Capacité: " + capacite + 
                            "g, Contenu actuel: " + contenuActuel + 
                            "g. Le dépôt est entièrement refusé.");
                    
                    // Aucun poids accepté
                    poidsAccepte = 0;
                    nouveauContenu = contenuActuel; // Le contenu reste inchangé
                    capaciteDepassee = true;
                    
                    return new BacUpdateResult(true, -poidsAccepte, capacite, nouveauContenu);
                } 
                else if (poidsAAjouter > espaceDisponible) {
                    // Le poids dépasse l'espace disponible - refuser tout le dépôt
                    System.out.println("Attention: Le poids à ajouter (" + poidsAAjouter + 
                            "g) dépasse l'espace disponible dans le bac (" + espaceDisponible + 
                            "g). Le dépôt est entièrement refusé.");
                    
                    // Aucun poids accepté car la capacité est dépassée
                    poidsAccepte = 0;
                    nouveauContenu = contenuActuel; // Le contenu reste inchangé
                    capaciteDepassee = true;
                    
                    return new BacUpdateResult(true, -poidsAccepte, capacite, nouveauContenu);
                } else {
                    // Le poids ne dépasse pas l'espace disponible
                    nouveauContenu = contenuActuel + poidsAAjouter;
                }
                
                // Ne mettre à jour le bac que si du poids est réellement ajouté
                if (poidsAccepte > 0) {
                    String updateSql = "UPDATE Bac SET contenu = ? WHERE idBac = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setInt(1, nouveauContenu);
                        updateStmt.setInt(2, idBac);
                        
                        int rowsAffected = updateStmt.executeUpdate();
                        if (rowsAffected > 0) {
                            System.out.println("Contenu du bac mis à jour avec succès (ID: " + idBac + 
                                    ", Nouveau contenu: " + nouveauContenu + "g)");
                            if (!conn.getAutoCommit()) {
                                conn.commit();
                            }
                        } else {
                            System.err.println("Aucun bac mis à jour pour l'ID: " + idBac);
                            if (!conn.getAutoCommit()) {
                                conn.rollback();
                            }
                            return new BacUpdateResult(false, 0, capacite, contenuActuel);
                        }
                    }
                } else {
                    System.out.println("Aucune mise à jour du bac nécessaire car aucun poids n'a été accepté.");
                }
                
                // Si capacité dépassée, retourner une valeur négative pour poidsAccepte
                // pour indiquer que le bac est plein et que tout le poids n'a pas été accepté
                int poidsRetourne = capaciteDepassee ? -poidsAccepte : poidsAccepte;
                return new BacUpdateResult(true, poidsRetourne, capacite, nouveauContenu);
            } else {
                System.err.println("Aucun bac trouvé avec la couleur " + couleur + " à l'adresse ID: " + adresseId);
                return new BacUpdateResult(false, 0, 0, 0);
            }
        } catch (SQLException e) {
            try {
                if (conn != null && !conn.getAutoCommit()) {
                    conn.rollback();
                }
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Erreur lors de la mise à jour du contenu du bac: " + e.getMessage());
            e.printStackTrace();
            return new BacUpdateResult(false, 0, 0, 0);
        }
    }
}