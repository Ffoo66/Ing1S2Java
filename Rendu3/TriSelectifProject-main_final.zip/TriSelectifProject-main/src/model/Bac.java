package model;

import java.time.LocalDate;
import java.util.UUID;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Bac {
	private int idBac;
	private CentreTri centre;
	private Couleur couleurBac;
	private int capacite;
	private int contenu;
	private Adresse adresseBac;
	private LocalDate dateDerniereCollecte;
	private LocalDate prochaineCollecte;
	private final StringProperty statutCollecteProperty; // Propriété persistante

	public Bac(int idBac, CentreTri centre, Couleur couleur, int capacite) {
		this.idBac = idBac;
		this.centre = centre;
		this.couleurBac = couleur;
		this.capacite = capacite;
		this.contenu = 0;
		this.statutCollecteProperty = new SimpleStringProperty("En attente"); // Valeur initiale
		updateStatutCollecte(); // Calculer le statut initial
	}

	// Getters et setters existants
	public int getIdBac() {
		return idBac;
	}

	public CentreTri getCentre() {
		return centre;
	}

	public Couleur getCouleurBac() {
		return couleurBac;
	}

	public int getCapacite() {
		return capacite;
	}

	public int getContenu() {
		return contenu;
	}

	public Adresse getAdresseBac() {
		return adresseBac;
	}

	public void setCouleurBac(Couleur couleur) {
		if (couleur != null) {
			this.couleurBac = couleur;
		}
	}

	public void setCapacite(int capacite) {
		if (capacite > 0) {
			this.capacite = capacite;
			updateStatutCollecte(); // Mettre à jour le statut lorsque la capacité change
		}
	}

	public void setContenu(int contenu) {
		if (contenu >= 0 && contenu <= capacite) {
			this.contenu = contenu;
			updateStatutCollecte(); // Mettre à jour le statut lorsque le contenu change
		}
	}

	public void setAdresseBac(Adresse adresse) {
		this.adresseBac = adresse;
	}

	public void vider() {
		this.contenu = 0;
		updateStatutCollecte(); // Mettre à jour le statut après vidage
	}

	public LocalDate getDateDerniereCollecte() {
		return dateDerniereCollecte;
	}

	public void setDateDerniereCollecte(LocalDate dateDerniereCollecte) {
		this.dateDerniereCollecte = dateDerniereCollecte;
	}

	public LocalDate getProchaineCollecte() {
		return prochaineCollecte;
	}

	public void setProchaineCollecte(LocalDate prochaineCollecte) {
		this.prochaineCollecte = prochaineCollecte;
		updateStatutCollecte(); // Mettre à jour le statut lorsque la prochaine collecte change
	}

	// Méthode pour calculer le pourcentage de remplissage
	public double getPourcentageRemplissage() {
		return (double) contenu / capacite;
	}

	// Méthode pour déterminer le statut de collecte
	private void updateStatutCollecte() {
		String newStatut;
		if (prochaineCollecte != null) {
			newStatut = "Planifiée (" + prochaineCollecte + ")";
		} else if (getPourcentageRemplissage() >= 0.5) {
			newStatut = "À collecter";
		} else {
			newStatut = "En attente";
		}
		statutCollecteProperty.set(newStatut);
	}

	// Getter pour la propriété statutCollecte
	public StringProperty getStatutCollecteProperty() {
		return statutCollecteProperty;
	}

	public String getStatutCollecte() {
		return statutCollecteProperty.get();
	}

	// Propriété pour l'affichage de l'adresse complète
	public String getAdresseComplete() {
		return adresseBac != null ? adresseBac.getNum() + " " + adresseBac.getNomRue() + ", " + adresseBac.getCodeP() + " " + adresseBac.getVille() : "Non définie";
	}

	public StringProperty getAdresseCompleteProperty() {
		return new SimpleStringProperty(getAdresseComplete());
	}

	@Override
	public String toString() {
		return "Bac {" +
				"idBac=" + idBac +
				", couleur=" + couleurBac +
				", capacite=" + capacite +
				", contenu=" + contenu +
				", adresse=" + adresseBac +
				", dateDerniereCollecte=" + dateDerniereCollecte +
				", prochaineCollecte=" + prochaineCollecte +
				'}';
	}
}