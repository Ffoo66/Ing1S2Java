package model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Depot {
	private Integer idDepot;
	private int poidsDepot;
	private Couleur colDepot;
	private Type typeDepot;
	private ResCat correct;
	private Adresse adresseDepot;
	private int pointsGagnes;
	private Menage utilDepot;
	private LocalDate dateDepot;
	private LocalTime horaireDepot;

	public Depot(int nId, int nPoids, Couleur nCol, Type nType, Adresse nAdresse, ResCat nCorrect, int nPts,
				 Menage nUtil, LocalDate nDate, LocalTime nHoraire) {
		if (nPoids > 0 && nCol != Couleur.toutCol && nType != Type.toutType && nCorrect != ResCat.total
				&& nAdresse != null) {
			this.idDepot = nId;
			this.poidsDepot = nPoids;
			this.colDepot = nCol;
			this.typeDepot = nType;
			this.adresseDepot = nAdresse;
			this.correct = nCorrect;
			this.pointsGagnes = nPts;
			this.utilDepot = nUtil;
			if (this.utilDepot != null) { // Null check to prevent NullPointerException
				this.utilDepot.addPoints(this.pointsGagnes);
			}
			this.dateDepot = nDate;
			this.horaireDepot = nHoraire;
		} else {
			throw new IllegalArgumentException("Invalid Depot parameters");
		}
	}

	public void modifPoints() {
		if (this.utilDepot != null) {
			this.utilDepot.ajouterDepot(this);
		}
	}

	@Override
	public String toString() {
		String userName = (this.utilDepot != null) ? this.utilDepot.getNom() : "N/A";
		return "Dépôt{\n\tId dépôt : " + this.idDepot + "\n\tPoids dépôt : " + this.poidsDepot + "\n\tCouleur dépôt : "
				+ this.colDepot + "\n\tType dépôt : " + this.typeDepot + "\n\tCorrect : " + this.correct
				+ "\n\tAdresse dépôt : " + this.adresseDepot + "\n\tPoints gagnés : " + this.pointsGagnes
				+ "\n\tUtilisateur dépôt: " + userName + "\n\tDate dépôt : " + this.dateDepot
				+ "\n\tHoraire dépôt : " + this.horaireDepot + "\n}\n";
	}

	// Getters and setters
	public Integer getIdDepot() {
		return this.idDepot;
	}

	public void setIdDepot(int idDepot) {
		this.idDepot = idDepot;
	}

	public int getPoidsDepot() {
		return this.poidsDepot;
	}

	public void setPoidsDepot(int poidsDepot) {
		this.poidsDepot = poidsDepot;
	}

	public Couleur getCouleurDepot() {
		return this.colDepot;
	}

	public void setColDepot(Couleur colDepot) {
		this.colDepot = colDepot;
	}

	public Type getType() {
		return this.typeDepot;
	}

	public void setTypeDepot(Type typeDepot) {
		this.typeDepot = typeDepot;
	}

	public ResCat getCorrect() {
		return this.correct;
	}

	public void setCorrect(ResCat correct) {
		this.correct = correct;
	}

	public Adresse getAdresseDepot() {
		return this.adresseDepot;
	}

	public void setAdresseDepot(Adresse adresseDepot) {
		this.adresseDepot = adresseDepot;
	}

	public int getPtsGagnes() {
		return this.pointsGagnes;
	}

	public void setPointsGagnes(int pointsGagnes) {
		this.pointsGagnes = pointsGagnes;
	}

	public Menage getUtilDepot() {
		return this.utilDepot;
	}

	public void setUtilDepot(Menage utilDepot) {
		this.utilDepot = utilDepot;
	}

	public LocalDate getDate() {
		return this.dateDepot;
	}

	public void setDateDepot(LocalDate dateDepot) {
		this.dateDepot = dateDepot;
	}

	public LocalTime getHoraire() {
		return this.horaireDepot;
	}

	public void setHoraireDepot(LocalTime horaireDepot) {
		this.horaireDepot = horaireDepot;
	}

	// Legacy getters for compatibility (if needed elsewhere)
	public Couleur getColDepot() {
		return this.colDepot;
	}

	public Type getTypeDepot() {
		return this.typeDepot;
	}
	//s
	public Depot(int nId, int nPoids, Couleur nCol, Type nType, Adresse nAdresse, ResCat nCorrect, int nPts,
				 Menage nUtil, LocalDate nDate, LocalTime nHoraire,int aa) {

			this.idDepot = nId;
			this.poidsDepot = nPoids;
			this.colDepot = nCol;
			this.typeDepot = nType;
			this.adresseDepot = nAdresse;
			this.correct = nCorrect;
			this.pointsGagnes = nPts;
			this.utilDepot = nUtil;
			this.utilDepot.addPoints(this.pointsGagnes);
			this.dateDepot = nDate;
			this.horaireDepot = nHoraire;

	}
	public LocalDate getDateDepot() {
		return this.dateDepot;
	}

	public LocalTime getHoraireDepot() {
		return this.horaireDepot;
	}

	public int getPointsGagnes() {
		return this.pointsGagnes;
	}
}