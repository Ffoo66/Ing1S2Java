package model;

import java.sql.Connection;
import java.time.LocalDate;

public class ContratPartenariat {
	private Connection conn;
	private int idCentreP;
	private int idCommerceP;
	private CentreTri centrePartner;
	private Commerce commercePartner;
	private boolean estPartenaire;
	private LocalDate dateDebutPartner;
	private LocalDate dateFinPartner;
	private String centrePartnerNom;
	private String commercePartnerNom;

	public void setConnection(Connection conn) {
		this.conn = conn;
	}

	public int getIdCentreP() {
		return this.idCentreP;
	}

	public int getIdCommerceP() {
		return this.idCommerceP;
	}

	public CentreTri getCentrePartner() {
		return this.centrePartner;
	}

	public String getNomCentrePartner() {
		return centrePartner != null ? centrePartner.getNomCentre() : centrePartnerNom;
	}

	public String getNomCommerce() {
		return commercePartner != null ? commercePartner.getNomCommerce() : commercePartnerNom;
	}

	public void setNomCentrePartner(String nom) {
		this.centrePartnerNom = nom;
	}

	public void setNomCommerce(String nom) {
		this.commercePartnerNom = nom;
	}

	public Commerce getCommercePartner() {
		return this.commercePartner;
	}

	public boolean getEstPartner() {
		return this.estPartenaire;
	}

	public LocalDate getDateDP() {
		return this.dateDebutPartner;
	}

	public LocalDate getDateFP() {
		return this.dateFinPartner;
	}

	public void prolongPartner(LocalDate dateDP, LocalDate dateFP) {
		if (this.dateFinPartner.isBefore(dateFP) && LocalDate.now().isBefore(dateFP) && dateDP.isBefore(dateFP)) {
			if (this.dateFinPartner.isBefore(LocalDate.now()) || this.dateFinPartner.isEqual(LocalDate.now())) {
				this.dateDebutPartner = dateDP;
				this.dateFinPartner = dateFP;
				if (LocalDate.now().isAfter(this.dateDebutPartner)) {
					this.estPartenaire = true;
				}
			} else if (this.dateFinPartner.isAfter(dateDP) || this.dateFinPartner.isEqual(dateDP)) {
				this.dateFinPartner = dateFP;
				this.estPartenaire = true;
			} else {
				System.out.println("Contrat actuel non terminé");
			}
		} else {
			System.out.println("Dates invalides");
		}
	}

	@Override
	public String toString() {
		return "ContratPartenariat {\n\tCentre partenaire : " + (centrePartner != null ? centrePartner.getIdCentre() : idCentreP)
				+ "\n\tCommerce partenaire : " + (commercePartner != null ? commercePartner.getIdCommerce() : idCommerceP)
				+ "\n\tEst partenaire : " + this.estPartenaire
				+ "\n\tDate début partenariat : " + this.dateDebutPartner
				+ "\n\tDate fin partenariat : " + this.dateFinPartner + "\n}\n";
	}

	public ContratPartenariat(int centreId, int commerceId, boolean estPartenaire, LocalDate dateDebut, LocalDate dateFin) {
		this.idCentreP = centreId;
		this.idCommerceP = commerceId;
		this.dateDebutPartner = dateDebut;
		this.dateFinPartner = dateFin;
		this.estPartenaire = estPartenaire;
		this.centrePartner = null; // Will be set by DAO
		this.commercePartner = null; // Will be set by DAO
		this.centrePartnerNom = "Centre_" + centreId;
		this.commercePartnerNom = "Commerce_" + commerceId;
	}

	public ContratPartenariat(CentreTri nCentre, Commerce nCommerce, LocalDate nDateDP, LocalDate nDateFP) {
		this.idCentreP = nCentre.getIdCentre();
		this.idCommerceP = nCommerce.getIdCommerce();
		this.centrePartner = nCentre;
		this.commercePartner = nCommerce;
		this.dateDebutPartner = nDateDP;
		this.dateFinPartner = nDateFP;
		this.centrePartnerNom = nCentre.getNomCentre();
		this.commercePartnerNom = nCommerce.getNomCommerce();
		if (LocalDate.now().isAfter(this.dateDebutPartner) && LocalDate.now().isBefore(this.dateFinPartner)) {
			this.estPartenaire = true;
		} else {
			this.estPartenaire = false;
		}
	}
}