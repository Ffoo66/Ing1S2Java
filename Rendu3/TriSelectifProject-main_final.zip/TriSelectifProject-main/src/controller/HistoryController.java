package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.UUID;

import model.Menage;
import model.Depot;

public class HistoryController {

    @FXML
    private ComboBox<String> typeFilterComboBox;

    @FXML
    private DatePicker startDatePicker;

    @FXML
    private DatePicker endDatePicker;

    @FXML
    private TableView<Depot> depositsTableView;

    @FXML
    private TableColumn<Depot, LocalDate> dateColumn;

    @FXML
    private TableColumn<Depot, String> timeColumn; // Optional: unused, left for FXML compatibility

    @FXML
    private TableColumn<Depot, String> poubelleidColumn;

    @FXML
    private TableColumn<Depot, String> typeColumn;

    @FXML
    private TableColumn<Depot, Double> quantityColumn;

    @FXML
    private TableColumn<Depot, Integer> pointsColumn;

    private Menage currentUser;
    private ObservableList<Depot> allDeposits;
    private FilteredList<Depot> filteredDeposits;

    @FXML
    private void initialize() {
        // Setup the table columns
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));

        // Time column no longer needed; keep it empty for compatibility if still in FXML
        timeColumn.setCellValueFactory(cellData -> {
            return javafx.beans.binding.Bindings.createStringBinding(() -> "");
        });

        poubelleidColumn.setCellValueFactory(new PropertyValueFactory<>("idPoubelle"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantite"));
        pointsColumn.setCellValueFactory(new PropertyValueFactory<>("ptsGagnes"));

        // Setup the type filter combo
        typeFilterComboBox.getItems().addAll("Tous", "Verre", "Plastique", "Papier", "Métal");
        typeFilterComboBox.setValue("Tous");

        // Setup date pickers
        startDatePicker.setValue(LocalDate.now().minusMonths(1));
        endDatePicker.setValue(LocalDate.now());
    }

    public void initData(Menage menage) {
        this.currentUser = menage;
        loadDeposits();
        applyFilters();
    }

    private void loadDeposits() {
        HashMap<Integer, Depot> depots = currentUser.getHistorique();
        allDeposits = FXCollections.observableArrayList(depots.values());
        filteredDeposits = new FilteredList<>(allDeposits);
        depositsTableView.setItems(filteredDeposits);
    }

    private void applyFilters() {
        String selectedType = typeFilterComboBox.getValue();
        LocalDate startDate = startDatePicker.getValue();
        LocalDate endDate = endDatePicker.getValue();

        filteredDeposits.setPredicate(depot -> {
            boolean matchesType = "Tous".equals(selectedType) || selectedType.equals(depot.getType());
            LocalDate depotDate = depot.getDate();

            boolean isAfterStartDate = startDate == null ||
                    depotDate.isEqual(startDate) || depotDate.isAfter(startDate);

            boolean isBeforeEndDate = endDate == null ||
                    depotDate.isEqual(endDate) || depotDate.isBefore(endDate.plusDays(1));

            return matchesType && isAfterStartDate && isBeforeEndDate;
        });
    }

    @FXML
    private void handleFilterChange(ActionEvent event) {
        applyFilters();
    }

    @FXML
    private void handleApplyFilter(ActionEvent event) {
        applyFilters();
    }

    @FXML
    private void handleResetFilter(ActionEvent event) {
        typeFilterComboBox.setValue("Tous");
        startDatePicker.setValue(LocalDate.now().minusMonths(1));
        endDatePicker.setValue(LocalDate.now());
        applyFilters();
    }

    @FXML
    private void handleExport(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Exporter l'historique des dépôts");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("CSV Files", "*.csv"),
                new FileChooser.ExtensionFilter("All Files", "*.*")
        );

        File file = fileChooser.showSaveDialog(depositsTableView.getScene().getWindow());

        if (file != null) {
            try (FileWriter writer = new FileWriter(file)) {
                writer.write("Date,ID Poubelle,Type,Quantité,Points gagnés\n");

                DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

                for (Depot depot : filteredDeposits) {
                    writer.write(
                            depot.getDate().format(dateFormatter) + "," +
                                    depot.getIdDepot() + "," +
                                    depot.getType() + "," +
                                    depot.getPoidsDepot() + "," +
                                    depot.getPtsGagnes() + "\n"
                    );
                }

                // Optional: show success message
            } catch (IOException e) {
                e.printStackTrace();
                // Optional: show error message
            }
        }
    }

    @FXML
    private void handleProfileAction(ActionEvent event) {
        // Implement profile view
    }

    @FXML
    private void handleLogoutAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/Login.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) depositsTableView.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/application/view/application.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Connexion - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleDashboardAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/Dashboard.fxml"));
            Parent root = loader.load();

            MenageDashboardController controller = loader.getController();
            controller.initData(currentUser);

            Stage stage = (Stage) depositsTableView.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/application/view/application.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Tableau de bord - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleHistoryAction(ActionEvent event) {
        // Already on history page
    }

    @FXML
    private void handleExchangeAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/Exchange.fxml"));
            Parent root = loader.load();

            ExchangeController controller = loader.getController();
            // controller.initData(currentUser); // Uncomment if needed

            Stage stage = (Stage) depositsTableView.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/application/view/application.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Échanger des points - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
