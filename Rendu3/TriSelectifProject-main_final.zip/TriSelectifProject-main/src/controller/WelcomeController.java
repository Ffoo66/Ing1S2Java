package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import main.Main;
import model.CentreTri;
import model.ContratPartenariat;

import java.io.IOException;
import java.sql.Connection;

public class WelcomeController {
    public Connection coonection;
    @FXML private Button logoutButton;
public void setConnection(Connection coo){
  this.coonection=coo;
}
    @FXML private Label welcomeLabel;
    private int centreId; // Stocker l'ID du centre
    private String centreName; // Stocker le nom du centre

    public void setUserInfo(String accountType, String name, int centreId) {
        this.centreId = centreId;
        this.centreName = name;
        System.out.println("WelcomeController: setUserInfo - accountType = " + accountType +
                ", name = " + name + ", centreId = " + centreId);
        welcomeLabel.setText("Bienvenue, " + accountType + " - " + name);
        // Pour les ménages, centreId est -1
        if (accountType.equals("Centre de Tri") && centreId <= 0) {
            System.out.println("WelcomeController: ID de centre invalide pour Centre de Tri - centreId = " + centreId);
            welcomeLabel.setText(welcomeLabel.getText() + " (Erreur: ID de centre invalide)");
        }
    }

    @FXML
    public void handleOpenGestionBacs() {
        if (centreId <= 0) {
            System.out.println("WelcomeController: Navigation vers Gestion des Bacs bloquée - centreId invalide = " + centreId);
            welcomeLabel.setText("Erreur: ID de centre invalide. Impossible d'accéder à la gestion des bacs.");
            return;
        }
        try {
            System.out.println("WelcomeController: Navigation vers Gestion des Bacs - centreId = " + centreId);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/gestionBacs.fxml"));
            Parent gestionBacsPage = loader.load();
            GestionBacsController gestionBacsController = loader.getController();
            gestionBacsController.setCentreId(centreId);
            gestionBacsController.setCentreName(centreName);
            Scene scene = new Scene(gestionBacsPage);
            Stage stage = (Stage) welcomeLabel.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Gestion des Bacs - " + centreName);
            stage.show();
        } catch (IOException e) {
            System.err.println("WelcomeController: Erreur lors de la navigation vers Gestion des Bacs - " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void handleOpenCollecte() {
        if (centreId <= 0) {
            System.out.println("WelcomeController: Navigation vers Collecte des Déchets bloquée - centreId invalide = " + centreId);
            welcomeLabel.setText("Erreur: ID de centre invalide. Impossible d'accéder à la collecte des déchets.");
            return;
        }
        try {
            System.out.println("WelcomeController: Navigation vers Collecte des Déchets - centreId = " + centreId);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/collecte.fxml"));
            Parent collectePage = loader.load();
            CollecteController collecteController = loader.getController();
            collecteController.setCentreId(centreId);
            collecteController.setCentreName(centreName);
            Scene scene = new Scene(collectePage);
            Stage stage = (Stage) welcomeLabel.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Collecte des Déchets - " + centreName);
            stage.show();
        } catch (IOException e) {
            System.err.println("WelcomeController: Erreur lors de la navigation vers Collecte des Déchets - " + e.getMessage());
            e.printStackTrace();
        }
    }
    @FXML
    public void handleLogout() {
        try {
            CentreTri.clearMapCentre();
            System.out.println("WelcomeController: Déconnexion - mapCentre réinitialisé");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/MainConnection.fxml"));
            Parent loginPage = loader.load();
            Scene scene = new Scene(loginPage);
            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Connexion");
            stage.show();

            System.out.println("WelcomeController: Redirection vers la page de connexion réussie");
        } catch (IOException e) {
            System.err.println("WelcomeController: Erreur lors de la déconnexion - " + e.getMessage());
            e.printStackTrace();
        }
    }
    @FXML
    public void handleOpenStatistiques() {
        if (centreId <= 0) {
            System.out.println("WelcomeController: Navigation vers Statistiques bloquée - centreId invalide = " + centreId);
            welcomeLabel.setText("Erreur: ID de centre invalide. Impossible d'accéder aux statistiques.");
            return;
        }
        try {
            System.out.println("WelcomeController: Navigation vers Statistiques - centreId = " + centreId);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/statistiques.fxml"));
            Parent statistiquesPage = loader.load();
            StatistiquesController statistiquesController = loader.getController();
            statistiquesController.setCentreId(centreId); // This now triggers loadData()
            statistiquesController.setCentreName(centreName);
            Scene scene = new Scene(statistiquesPage);
            Stage stage = (Stage) welcomeLabel.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Statistiques - " + centreName);
            stage.show();
        } catch (IOException e) {
            System.err.println("WelcomeController: Erreur lors de la navigation vers Statistiques - " + e.getMessage());
            e.printStackTrace();
        }
    }


    @FXML
    public void handleOpenPartenaires() {
        if (centreId <= 0) {
            System.out.println("WelcomeController: Navigation vers Partenaires bloquée - centreId invalide = " + centreId);
            welcomeLabel.setText("Erreur: ID de centre invalide. Impossible d'accéder aux partenaires.");
            return;
        }

        try {
            System.out.println("WelcomeController: Navigation vers Partenaires - centreId = " + centreId);

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/partnerShipDashbaord.fxml"));
            Parent root = loader.load(); // Load FXML

            // Get controller and set parameters
          //  AddPartnershipController controller = loader.getController();
            ContratPartenariatController controller = loader.getController();
            controller.setConnection(Main.conn);
            controller.setCentreId(centreId);
            controller.setCentreName(centreName);

            // Set scene
            Stage stage = (Stage) welcomeLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Ajouter un partenariat - " + centreName);
            stage.show();
        } catch (IOException e) {
            System.err.println("WelcomeController: Erreur lors de la navigation vers Partenaires - " + e.getMessage());
            e.printStackTrace();
        }
    }

}