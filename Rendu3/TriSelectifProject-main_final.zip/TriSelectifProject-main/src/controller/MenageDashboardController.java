package controller;

import dao.MenageDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import main.Main;
import model.CentreTri;
import model.Menage;
import model.Depot;
import model.BonReduction;

import static main.Main.conn;

public class MenageDashboardController {

    @FXML private Text userNameText;
    @FXML private Button logoutButton;
    @FXML private Label pointsLabel;
    @FXML private Text totalDepotsText;
    @FXML private Text totalPointsText;
    @FXML private Text availableVouchersText;
    @FXML private Text lastDepositText;
    @FXML private PieChart depositsPieChart;

    private Menage currentUser;
    private Connection connection;

    @FXML
    private void initialize() {
        // Initialize will be called before user data is loaded
    }

    @FXML
    public void handleLogout() {
        try {
            this.currentUser = null; // Clear the local reference
            System.out.println("MenageDashboardController: Déconnexion - user state cleared");

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/MainConnection.fxml"));
            Parent loginPage = loader.load();

            Scene scene = new Scene(loginPage);
            scene.getStylesheets().add(getClass().getResource("/view/css/connection.css").toExternalForm());
            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Connexion - Tri Sélectif");
            stage.show();

            System.out.println("MenageDashboardController: Redirection vers la page de connexion réussie");
        } catch (IOException e) {
            System.err.println("MenageDashboardController: Erreur lors de la déconnexion - " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void setConnection(Connection connection) {
        this.connection = (connection != null) ? connection : conn;
        if (this.connection == null) {
            throw new IllegalStateException("Database connection is null. Ensure Main.conn is properly initialized.");
        }
    }

    public void setMenage(Menage menage) {
        this.currentUser = menage;
    }

    public void initData(Menage menage) {
        this.currentUser = menage;
        System.out.println("menage points: " + currentUser.getPoints());
        initData();
    }

    public void initData() {
        if (currentUser == null) {
            System.err.println("MenageDashboardController: currentUser is null in initData");
            return;
        }

        userNameText.setText(currentUser.getNom());
        pointsLabel.setText(String.valueOf(currentUser.getPoints()));

        updateStatistics();
        createDepositsPieChart();
    }
    @FXML
    private void handleRefreshAction(ActionEvent event) {
        // Récupérer les données à jour du ménage depuis la base de données
        MenageDAO menageDAO = new MenageDAO(conn);
        Menage refreshedMenage = menageDAO.setInfos(currentUser.getNom());

        // Mettre à jour l'utilisateur courant avec les nouvelles données
        this.currentUser = refreshedMenage;

        // Mettre à jour l'interface utilisateur
        initData();

        System.out.println("Données actualisées avec succès.");
    }
    private void updateStatistics() {
        HashMap<Integer, Depot> depots = currentUser.getHistorique();
        HashMap<Integer, BonReduction> bons = currentUser.getMapBons();

        totalDepotsText.setText(String.valueOf(depots.size()));
        System.out.println("nb depot: " + depots.size());

        int totalPointsAccumulated = 0;
        Depot mostRecentDepot = null;

        for (Depot depot : depots.values()) {
            totalPointsAccumulated += depot.getPtsGagnes();
            if (mostRecentDepot == null || depot.getDate().isAfter(mostRecentDepot.getDate())) {
                mostRecentDepot = depot;
            }
        }

        // totalPointsText.setText(String.valueOf(totalPointsAccumulated));

        int availableVouchers = 0;
        for (BonReduction bon : bons.values()) {
            if (!bon.getBonUtilise() && !bon.getDateExp().isBefore(java.time.LocalDate.now())) {
                availableVouchers++;
            }
        }

        availableVouchersText.setText(String.valueOf(availableVouchers));

        if (mostRecentDepot != null) {
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            lastDepositText.setText(mostRecentDepot.getDate().format(dateFormatter));
        } else {
            lastDepositText.setText("Aucun");
        }
    }

    private void createDepositsPieChart() {
        HashMap<Integer, Depot> depots = currentUser.getHistorique();

        Map<String, Integer> depositsByType = new HashMap<>();

        for (Depot depot : depots.values()) {
            String typeName = depot.getType().name();
            depositsByType.put(typeName, depositsByType.getOrDefault(typeName, 0) + 1);
        }

        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
        for (Map.Entry<String, Integer> entry : depositsByType.entrySet()) {
            pieChartData.add(new PieChart.Data(entry.getKey() + " (" + entry.getValue() + ")", entry.getValue()));
        }

        if (pieChartData.isEmpty()) {
            pieChartData.add(new PieChart.Data("Aucun dépôt", 1));
        }

        depositsPieChart.setData(pieChartData);
        depositsPieChart.setTitle("Répartition par type de déchet");
    }



    @FXML
    private void handleLogoutAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/MainConnection.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) userNameText.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/view/css/connection.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Connexion - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleDashboardAction(ActionEvent event) {
        // Already on dashboard, no action needed
    }

    @FXML
    private void handleHistoryAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/History.fxml"));
            Parent root = loader.load();

            HistoryController controller = loader.getController();
            controller.initData(currentUser);

            Stage stage = (Stage) userNameText.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/view/css/menageDashboard.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Historique des dépôts - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleExchangeAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/echangePoint.fxml"));
            Parent root = loader.load();
            ExchangeController controller = loader.getController();
            controller.setMenage(currentUser);
            controller.setConnection(conn);
            Stage stage = (Stage) userNameText.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/view/css/echangePoint.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Échanger des points - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleVouchersAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/BonDachat.fxml"));
            Parent root = loader.load();

            BonDachatController controller = loader.getController();
            controller.setMenage(currentUser); // Pass the currentUser
            controller.setConnection(conn); // Pass the connection

            Stage stage = (Stage) userNameText.getScene().getWindow();
            Scene scene = new Scene(root);
            String cssPath = "/view/css/bonDachat.css";
            if (getClass().getResource(cssPath) != null) {
                scene.getStylesheets().add(getClass().getResource(cssPath).toExternalForm());
            } else {
                System.out.println("CSS file not found: " + cssPath + ". Proceeding without stylesheet.");
            }

            stage.setScene(scene);
            stage.setTitle("Mes bons de réduction - Tri Sélectif");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleNewDepositAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/depotForm.fxml"));
            Parent root = loader.load();

            DepotController controller = loader.getController();
            controller.setConnection(connection);
            controller.setMenage(currentUser);

            Stage stage = (Stage) userNameText.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/view/css/depotForm.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Nouveau dépôt - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAboutAction(ActionEvent event) {
        // Implement about dialog
    }
}