package controller;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import dao.DepotDAO;
import dao.AdresseDAO;
import dao.BacDAO;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ResourceBundle;
import java.util.UUID;
import java.util.List;

public class DepotController implements Initializable {

    @FXML
    private ComboBox<Couleur> couleurComboBox;

    @FXML
    private ComboBox<Type> typeComboBox;

    @FXML
    private ComboBox<ResCat> resultatComboBox;

    @FXML
    private ComboBox<Adresse> adresseComboBox;

    @FXML
    private TextField poidsField;

    @FXML
    private DatePicker dateDepotPicker;

    @FXML
    private TextField heureField;

    @FXML
    private TextField minuteField;

    @FXML
    private Label messageLabel;

    @FXML
    private Button enregistrerButton;

    @FXML
    private Button retourButton;

    private Connection connection;
    private Menage menageCourant;
    private DepotDAO depotDAO;
    private AdresseDAO adresseDAO;
    private boolean isReconnecting = false;  // Flag pour éviter les tentatives multiples simultanées

    public void setConnection(Connection connection) {
        // Utiliser la connexion passée ou essayer d'obtenir la connexion globale
        this.connection = (connection != null) ? connection : main.Main.conn;
        
        if (this.connection == null) {
            messageLabel.setText("Erreur: Connexion à la base de données non disponible");
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("error-message");
            disableControls(true);
            
            // Ajouter un bouton pour réessayer la connexion
            Button retryButton = new Button("Réessayer la connexion");
            retryButton.setOnAction(e -> handleRetryConnection(new ActionEvent()));
            messageLabel.setGraphic(retryButton);
            
            return;
        }
        
        try {
            initializeDAOs();
            enableControls();
            messageLabel.setText("Connexion à la base de données établie");
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("success-message");
            messageLabel.setGraphic(null); // Supprime le bouton de reconnexion s'il existe
        } catch (Exception e) {
            System.err.println("Erreur lors de l'initialisation des DAO: " + e.getMessage());
            e.printStackTrace();
            messageLabel.setText("Erreur lors de l'initialisation: " + e.getMessage());
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("error-message");
            disableControls(true);
        }
    }

    /**
     * Initialise les objets DAO avec la connexion actuelle
     */
    private void initializeDAOs() {
        if (connection != null) {
            this.depotDAO = new DepotDAO(connection);
            this.adresseDAO = new AdresseDAO(connection);
            chargerAdresses();
        } else {
            throw new IllegalStateException("Tentative d'initialisation des DAO avec une connexion null");
        }
    }

    public void setMenage(Menage menage) {
        this.menageCourant = menage;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialiser les ComboBox
        couleurComboBox.setItems(FXCollections.observableArrayList(Couleur.values()));
        typeComboBox.setItems(FXCollections.observableArrayList(Type.values()));
        // Supprimer l'initialisation du ComboBox resultatComboBox car il ne sera plus utilisé

        // Par défaut, désactiver les contrôles jusqu'à ce qu'une connexion soit établie
        disableControls(true);
        messageLabel.setText("En attente de connexion à la base de données...");
        messageLabel.getStyleClass().clear();
        messageLabel.getStyleClass().add("info-message");

        // Exclure les valeurs non valides pour un nouveau dépôt
        couleurComboBox.getItems().remove(Couleur.toutCol);
        typeComboBox.getItems().remove(Type.toutType);
        // Supprimer cette ligne car resultatComboBox ne sera plus utilisé
        // resultatComboBox.getItems().remove(ResCat.total);

        // Masquer le ComboBox du résultat car il sera déterminé automatiquement
        if (resultatComboBox != null) {
            resultatComboBox.setVisible(false);
            resultatComboBox.setManaged(false);
        }

        // Définir les valeurs par défaut
        dateDepotPicker.setValue(LocalDate.now());

        // Initialiser les validateurs
        poidsField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                poidsField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        heureField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                heureField.setText(newValue.replaceAll("[^\\d]", ""));
            }
            if (!newValue.isEmpty() && Integer.parseInt(newValue) > 23) {
                heureField.setText("23");
            }
        });

        minuteField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                minuteField.setText(newValue.replaceAll("[^\\d]", ""));
            }
            if (!newValue.isEmpty() && Integer.parseInt(newValue) > 59) {
                minuteField.setText("59");
            }
        });

        // Ajouter un listener pour la sélection de couleur
        couleurComboBox.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                // Vérifier si la connexion est disponible avant de filtrer
                if (connection == null) {
                    messageLabel.setText("Erreur: Connexion à la base de données non disponible");
                    messageLabel.getStyleClass().clear();
                    messageLabel.getStyleClass().add("error-message");
                    adresseComboBox.setDisable(true);
                    adresseComboBox.setPromptText("Connexion à la base de données indisponible");
                    return;
                }
                
                try {
                    // Réinitialiser l'adresse sélectionnée
                    adresseComboBox.setValue(null);
                    filtrerAdressesParCouleurBac(newVal);
                } catch (Exception e) {
                    System.err.println("Erreur lors du filtrage: " + e.getMessage());
                    e.printStackTrace();
                    messageLabel.setText("Erreur lors du filtrage: " + e.getMessage());
                    messageLabel.getStyleClass().clear();
                    messageLabel.getStyleClass().add("error-message");
                }
            }
        });
        
        // Tentative de récupérer la connexion globale lors de l'initialisation
        try {
            if (connection == null) {
                connection = main.Main.conn;
                if (connection != null) {
                    initializeDAOs();
                    enableControls();
                }
            }
        } catch (Exception e) {
            System.err.println("Erreur lors de la tentative de récupération de connexion globale: " + e.getMessage());
        }
    }

    /**
     * Désactive les contrôles d'interface utilisateur en cas d'erreur de connexion
     */
    private void disableControls(boolean disable) {
        couleurComboBox.setDisable(disable);
        typeComboBox.setDisable(disable);
        // Supprimer cette ligne car resultatComboBox ne sera plus utilisé
        // resultatComboBox.setDisable(disable);
        adresseComboBox.setDisable(true); // Toujours désactivé jusqu'à ce qu'une couleur soit sélectionnée
        poidsField.setDisable(disable);
        dateDepotPicker.setDisable(disable);
        heureField.setDisable(disable);
        minuteField.setDisable(disable);
        enregistrerButton.setDisable(disable);
    }

    /**
     * Réactive les contrôles d'interface utilisateur
     */
    private void enableControls() {
        couleurComboBox.setDisable(false);
        typeComboBox.setDisable(false);
        // Supprimer cette ligne car resultatComboBox ne sera plus utilisé
        // resultatComboBox.setDisable(false);
        poidsField.setDisable(false);
        dateDepotPicker.setDisable(false);
        heureField.setDisable(false);
        minuteField.setDisable(false);
        enregistrerButton.setDisable(false);
    }

    /**
     * Tente de réinitialiser la connexion à la base de données
     */
    @FXML
    private void handleRetryConnection(ActionEvent event) {
        if (isReconnecting) {
            return; // Éviter les tentatives multiples simultanées
        }
        
        isReconnecting = true;
        messageLabel.setText("Tentative de reconnexion à la base de données...");
        messageLabel.getStyleClass().clear();
        messageLabel.getStyleClass().add("info-message");
        
        // Utiliser un Thread séparé pour ne pas bloquer l'UI
        new Thread(() -> {
            try {
                // Essayer plusieurs approches pour récupérer une connexion
                Connection newConnection = null;
                
                // 1. Essayer de récupérer la connexion globale
                newConnection = main.Main.conn;
                
                // 2. Si toujours null, essayer de créer une nouvelle connexion
                if (newConnection == null) {
                    try {
                        // Si une méthode de création de connexion existe dans Main
                        // newConnection = main.Main.createNewConnection();
                        System.out.println("Tentative de création d'une nouvelle connexion");
                    } catch (Exception e) {
                        System.err.println("Échec de la création d'une nouvelle connexion: " + e.getMessage());
                    }
                }
                
                // Mettre à jour l'UI dans le thread JavaFX
                final Connection finalConnection = newConnection;
                Platform.runLater(() -> {
                    if (finalConnection != null) {
                        connection = finalConnection;
                        try {
                            initializeDAOs();
                            enableControls();
                            messageLabel.setText("Reconnexion à la base de données réussie");
                            messageLabel.getStyleClass().clear();
                            messageLabel.getStyleClass().add("success-message");
                            messageLabel.setGraphic(null); // Supprime le bouton de reconnexion
                        } catch (Exception e) {
                            messageLabel.setText("Erreur après reconnexion: " + e.getMessage());
                            messageLabel.getStyleClass().clear();
                            messageLabel.getStyleClass().add("error-message");
                            disableControls(true);
                        }
                    } else {
                        messageLabel.setText("Échec de la reconnexion à la base de données");
                        messageLabel.getStyleClass().clear();
                        messageLabel.getStyleClass().add("error-message");
                        
                        // Recréer le bouton de réessai
                        Button retryButton = new Button("Réessayer la connexion");
                        retryButton.setOnAction(e -> handleRetryConnection(new ActionEvent()));
                        messageLabel.setGraphic(retryButton);
                    }
                    isReconnecting = false;
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    System.err.println("Erreur lors de la tentative de reconnexion: " + e.getMessage());
                    e.printStackTrace();
                    messageLabel.setText("Erreur de reconnexion: " + e.getMessage());
                    messageLabel.getStyleClass().clear();
                    messageLabel.getStyleClass().add("error-message");
                    isReconnecting = false;
                });
            }
        }).start();
    }

    private void chargerAdresses() {
        try {
            if (connection == null) {
                messageLabel.setText("Erreur: Connexion à la base de données non disponible");
                messageLabel.getStyleClass().clear();
                messageLabel.getStyleClass().add("error-message");
                adresseComboBox.setDisable(true);
                adresseComboBox.setPromptText("Connexion à la base de données indisponible");
                return;
            }
            
            if (adresseDAO == null) {
                adresseDAO = new AdresseDAO(connection);
            }
            
            List<Adresse> toutesAdresses = adresseDAO.findAll();
            adresseComboBox.setItems(FXCollections.observableArrayList(toutesAdresses));
            adresseComboBox.setConverter(new StringConverter<Adresse>() {
                @Override
                public String toString(Adresse adresse) {
                    return adresse != null ? adresse.getNomRue() + ", " + adresse.getCodeP() + " " + adresse.getVille() : "";
                }

                @Override
                public Adresse fromString(String string) {
                    return null; // Non utilisé
                }
            });
            
            // Désactiver initialement le ComboBox des adresses tant qu'aucune couleur n'est sélectionnée
            adresseComboBox.setDisable(true);
            adresseComboBox.setPromptText("Choisissez d'abord une couleur de bac");
        } catch (Exception e) {
            System.err.println("Erreur lors du chargement des adresses: " + e.getMessage());
            e.printStackTrace();
            messageLabel.setText("Erreur lors du chargement des adresses: " + e.getMessage());
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("error-message");
            adresseComboBox.setDisable(true);
        }
    }

    // Méthode pour filtrer les adresses en fonction de la couleur de bac
    private void filtrerAdressesParCouleurBac(Couleur couleur) {
        if (couleur == null) {
            messageLabel.setText("Veuillez d'abord sélectionner une couleur de bac");
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("warning-message");
            adresseComboBox.setDisable(true);
            return;
        }
        
        // Vérification de la connexion qui pourrait être nulle
        if (connection == null) {
            messageLabel.setText("Erreur: Connexion à la base de données non disponible");
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("error-message");
            adresseComboBox.getItems().clear();
            adresseComboBox.setDisable(true);
            adresseComboBox.setPromptText("Connexion à la base de données indisponible");
            return;
        }
        
        messageLabel.setText("Recherche des adresses avec des bacs " + couleur.name().toLowerCase() + "...");
        messageLabel.getStyleClass().clear();
        messageLabel.getStyleClass().add("info-message");
        
        try {
            // Création du DAO si nécessaire
            BacDAO bacDAO = new BacDAO(connection);
            
            // Récupérer les adresses qui ont des bacs de la couleur sélectionnée
            List<Adresse> adressesFiltrees = bacDAO.findAdressesByCouleur(couleur);
            
            if (adressesFiltrees == null || adressesFiltrees.isEmpty()) {
                messageLabel.setText("Aucune adresse disponible avec des bacs " + couleur.name().toLowerCase());
                messageLabel.getStyleClass().clear();
                messageLabel.getStyleClass().add("warning-message");
                adresseComboBox.getItems().clear();
                adresseComboBox.setDisable(true);
                adresseComboBox.setPromptText("Aucun bac de couleur " + couleur.name().toLowerCase() + " disponible");
            } else {
                messageLabel.setText(adressesFiltrees.size() + " adresse(s) disponible(s) avec des bacs " + couleur.name().toLowerCase());
                messageLabel.getStyleClass().clear();
                messageLabel.getStyleClass().add("info-message");
                adresseComboBox.setItems(FXCollections.observableArrayList(adressesFiltrees));
                adresseComboBox.setDisable(false);
                adresseComboBox.setPromptText("Sélectionnez une adresse");
            }
        } catch (Exception e) {
            System.err.println("Erreur lors du filtrage des adresses par couleur: " + e.getMessage());
            e.printStackTrace();
            messageLabel.setText("Erreur lors du filtrage: " + e.getMessage());
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("error-message");
            adresseComboBox.getItems().clear();
            adresseComboBox.setDisable(true);
            adresseComboBox.setPromptText("Erreur lors de la recherche des adresses");
        }
    }

    /**
     * Détermine si le type de déchet correspond à la couleur de la poubelle
     * @param couleur La couleur de la poubelle
     * @param type Le type de déchet
     * @return ResCat.correct si la correspondance est correcte, ResCat.incorrect sinon
     */
    private ResCat determinerResultat(Couleur couleur, Type type) {
        // Implémentation basique des règles de correspondance couleur/type
        // À adapter selon les règles métier spécifiques
        if (couleur == Couleur.vert) {
            // Bac vert généralement pour le verre
            return (type == Type.verre) ? ResCat.correct : ResCat.incorrect;
        } else if (couleur == Couleur.jaune) {
            // Bac jaune généralement pour les emballages
            return (type == Type.plastique || type == Type.metal || type == Type.carton) ? ResCat.correct : ResCat.incorrect;
        } else if (couleur == Couleur.bleu) {
            // Bac bleu généralement pour le papier
            return (type == Type.papier) ? ResCat.correct : ResCat.incorrect;
        } else if (couleur == Couleur.gris) {
            // Bac gris généralement pour les ordures ménagères non recyclables
            return (type == Type.autre) ? ResCat.correct : ResCat.incorrect;
        }
        
        // Par défaut, incorrect si pas de correspondance claire
        return ResCat.incorrect;
    }

    /**
     * Calcule les points en fonction du poids et du résultat du dépôt
     * @param poids Le poids du dépôt en grammes
     * @param resultat Le résultat du dépôt (correct ou incorrect)
     * @return Le nombre de points attribués (positif ou négatif)
     */
    private int calculerPoints(int poids, ResCat resultat) {
        // Points de base proportionnels au poids
        int pointsBase = poids / 100; // 1 point par 100g par exemple
        
        // Ajustement selon le résultat
        if (resultat == ResCat.correct) {
            // Bonus pour dépôt correct
            return pointsBase + 5;
        } else {
            // Pénalité pour dépôt incorrect
            return -pointsBase - 10;
        }
    }

    /**
     * Met à jour le contenu d'un bac après un dépôt
     * @param couleur La couleur du bac
     * @param adresse L'adresse du bac
     * @param poids Le poids du dépôt à ajouter au contenu du bac
     * @return Un objet BacUpdateResult avec les informations sur le résultat de la mise à jour
     */
    private dao.BacDAO.BacUpdateResult updateBacContenu(Couleur couleur, Adresse adresse, int poids) {
        if (connection == null) {
            System.err.println("Erreur: Connexion à la base de données non disponible");
            return new dao.BacDAO.BacUpdateResult(false, 0, 0, 0);
        }
        
        try {
            BacDAO bacDAO = new BacDAO(connection);
            return bacDAO.updateContenuBacByCouleurAdresse(couleur, adresse.getId(), poids);
        } catch (Exception e) {
            System.err.println("Erreur lors de la mise à jour du contenu du bac: " + e.getMessage());
            e.printStackTrace();
            return new dao.BacDAO.BacUpdateResult(false, 0, 0, 0);
        }
    }

    @FXML
    private void handleEnregistrer(ActionEvent event) {
        if (validateFields()) {
            try {
                int poids = Integer.parseInt(poidsField.getText());
                Couleur couleur = couleurComboBox.getValue();
                Type type = typeComboBox.getValue();
                Adresse adresse = adresseComboBox.getValue();

                // Déterminer automatiquement le résultat
                ResCat resultat = determinerResultat(couleur, type);
                
                // Vérifier que l'adresse a un bac de la bonne couleur
                if (adresse == null) {
                    messageLabel.setText("Veuillez sélectionner une adresse valide");
                    messageLabel.getStyleClass().clear();
                    messageLabel.getStyleClass().add("error-message");
                    adresseComboBox.requestFocus();
                    return;
                }
                
                // Vérifier que la connexion est disponible
                if (connection == null || depotDAO == null) {
                    messageLabel.setText("Erreur: Connexion à la base de données non disponible");
                    messageLabel.getStyleClass().clear();
                    messageLabel.getStyleClass().add("error-message");
                    return;
                }

                // Mettre à jour le contenu du bac et vérifier s'il y a assez d'espace
                dao.BacDAO.BacUpdateResult updateResult = updateBacContenu(couleur, adresse, poids);
                
                // Si le bac est plein ou si le poids dépasse l'espace disponible, refuser le dépôt
                if (updateResult.isCapaciteDepassee() || updateResult.getPoidsAccepte() == 0) {
                    messageLabel.setText("Dépôt refusé : le bac est plein ou la quantité dépasse la capacité disponible.");
                    messageLabel.getStyleClass().clear();
                    messageLabel.getStyleClass().add("error-message");
                    return; // Ne pas créer de dépôt dans la base de données
                }
                
                // Si on arrive ici, c'est que le dépôt est accepté
                int poidsAccepte = updateResult.getPoidsAccepte();
                
                // Calculer les points en fonction du poids réellement accepté
                int points = calculerPoints(poidsAccepte, resultat);

                // Créer l'objet dépôt avec le poids accepté
                Depot nouveauDepot = new Depot(
                    Utils.generateRandomIntBasedOnTime(),
                    poidsAccepte,  // Utiliser le poids accepté
                    couleur,
                    type,
                    adresse,
                    resultat,
                    points,  
                    menageCourant,
                    dateDepotPicker.getValue(),
                    LocalTime.of(Integer.parseInt(heureField.getText()), Integer.parseInt(minuteField.getText()))
                );

                // Enregistrer le dépôt
                depotDAO.create(nouveauDepot, adresse.getId());

                // Afficher un message de confirmation avec le résultat
                String resultatTexte = resultat == ResCat.correct ? "correct" : "incorrect";
                String pointsTexte = points >= 0 ? "+" + points : String.valueOf(points);
                
                String messageConfirmation = "Dépôt enregistré avec succès! " +
                    "Quantité déposée: " + poidsAccepte + "g. " +
                    "Résultat: " + resultatTexte + ". " +
                    "Points attribués: " + pointsTexte;
                messageLabel.setText(messageConfirmation);
                messageLabel.getStyleClass().clear();
                messageLabel.getStyleClass().add(resultat == ResCat.correct ? "success-message" : "warning-message");

                // Réinitialiser le formulaire
                resetForm();
            } catch (Exception e) {
                messageLabel.setText("Erreur lors de l'enregistrement: " + e.getMessage());
                messageLabel.getStyleClass().clear();
                messageLabel.getStyleClass().add("error-message");
                e.printStackTrace();
            }
        }
    }

    private boolean validateFields() {
        StringBuilder errorMessage = new StringBuilder();

        if (poidsField.getText().isEmpty()) {
            errorMessage.append("Le poids est requis.\n");
        }

        if (couleurComboBox.getValue() == null) {
            messageLabel.setText("Veuillez sélectionner une couleur");
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("error-message");
            return false;
        }

        if (typeComboBox.getValue() == null) {
            errorMessage.append("Le type est requis.\n");
        }

        // Suppression de la vérification du résultat car il est maintenant calculé automatiquement
        // if (resultatComboBox.getValue() == null) {
        //     errorMessage.append("Le résultat est requis.\n");
        // }

        if (adresseComboBox.getValue() == null) {
            messageLabel.setText("Veuillez sélectionner une adresse avec un bac de couleur " + 
                couleurComboBox.getValue().name().toLowerCase());
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("error-message");
            return false;
        }

        if (dateDepotPicker.getValue() == null) {
            errorMessage.append("La date est requise.\n");
        }

        if (heureField.getText().isEmpty() || minuteField.getText().isEmpty()) {
            errorMessage.append("L'heure est requise.\n");
        }

        if (errorMessage.length() > 0) {
            messageLabel.setText(errorMessage.toString());
            messageLabel.setStyle("-fx-text-fill: red;");
            return false;
        }

        return true;
    }

    private void resetForm() {
        poidsField.clear();
        couleurComboBox.setValue(null);
        typeComboBox.setValue(null);
        dateDepotPicker.setValue(LocalDate.now());
        heureField.setText("00");
        minuteField.setText("00");
    }

    @FXML
    private void handleRetour(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/menageDashboard.fxml"));
            Parent root = loader.load();

            MenageDashboardController controller = loader.getController();
            controller.setConnection(connection);
            controller.setMenage(menageCourant);
            controller.initData();

            Stage stage = (Stage) retourButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}