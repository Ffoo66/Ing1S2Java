package controller;

import dao.MenageDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import main.Main;
import model.Adresse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class InscriptionController {

    @FXML
    private TextField nomCompteField;

    @FXML
    private PasswordField motDePasseField;

    @FXML
    private TextField motDePasseVisible;

    @FXML
    private ComboBox<Adresse> adresseComboBox;


    //  private CheckBox proCheckBox;

    @FXML
    private Button inscriptionButton;

    @FXML
    private Label messageLabel;

    @FXML
    private Hyperlink retourLien;

    @FXML
    private ImageView eyeIcon;

    @FXML
    private Button togglePasswordButton;

    private boolean passwordVisible = false;
    private MenageDAO menageDAO;

    private String accountType;

    @FXML
    public void initialize() {
        Connection conn = Main.conn;
        menageDAO = new MenageDAO(conn);

        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Adresse");

            while (rs.next()) {
                Adresse adresse = new Adresse(
                        rs.getInt("id"),
                        rs.getInt("numero"),
                        rs.getString("nomRue"),
                        rs.getInt("codePostal"),
                        rs.getString("ville")
                );
                adresseComboBox.getItems().add(adresse); // ✅ Correct: add the full Adresse object
            }
        } catch (Exception e) {
            e.printStackTrace();
            messageLabel.setText("Erreur lors du chargement des adresses.");
        }

        // Synchronisation des champs de mot de passe
        motDePasseField.textProperty().addListener((obs, oldVal, newVal) -> motDePasseVisible.setText(newVal));
        motDePasseVisible.textProperty().addListener((obs, oldVal, newVal) -> motDePasseField.setText(newVal));

        // Nettoyage du message lors de la saisie
        nomCompteField.textProperty().addListener((obs, oldVal, newVal) -> messageLabel.setText(""));
        motDePasseField.textProperty().addListener((obs, oldVal, newVal) -> messageLabel.setText(""));
        adresseComboBox.valueProperty().addListener((obs, oldVal, newVal) -> messageLabel.setText(""));
    }

    @FXML
    public void togglePasswordVisibility() {
        passwordVisible = !passwordVisible;

        if (passwordVisible) {
            motDePasseVisible.setText(motDePasseField.getText());
            motDePasseField.setVisible(false);
            motDePasseField.setManaged(false);
            motDePasseVisible.setVisible(true);
            motDePasseVisible.setManaged(true);
            togglePasswordButton.setText("🙈");
        } else {
            motDePasseField.setText(motDePasseVisible.getText());
            motDePasseField.setVisible(true);
            motDePasseField.setManaged(true);
            motDePasseVisible.setVisible(false);
            motDePasseVisible.setManaged(false);
            togglePasswordButton.setText("👁");
        }
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    @FXML
    public void handleInscription() {
        String nomCompte = nomCompteField.getText();
        String motDePasse = motDePasseField.getText();
        Adresse selectedAdresse = adresseComboBox.getValue();
        // boolean estProfessionnel = proCheckBox.isSelected();

        if (nomCompte.isEmpty() || motDePasse.isEmpty() || selectedAdresse == null) {
            messageLabel.setText("Veuillez remplir tous les champs");
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("error-message");
            return;
        }

        // Call DAO to create user (update your DAO to accept Adresse object or its ID)
        boolean success = menageDAO.create(nomCompte, motDePasse, selectedAdresse);

        if (success) {
            messageLabel.setText("Compte créé avec succès !");
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("success-message");

            nomCompteField.setDisable(true);
            motDePasseField.setDisable(true);
            motDePasseVisible.setDisable(true);
            adresseComboBox.setDisable(true);
            // proCheckBox.setDisable(true);
            inscriptionButton.setDisable(true);
            togglePasswordButton.setDisable(true);
        } else {
            messageLabel.setText("Erreur lors de la création du compte");
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("error-message");
        }
    }

    @FXML
    public void retourConnexion(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/MainConnection.fxml"));
            Parent connexionView = loader.load();
            Scene connexionScene = new Scene(connexionView);
            Stage stage = (Stage) retourLien.getScene().getWindow();
            stage.setScene(connexionScene);
            stage.setTitle("Connexion");
        } catch (IOException e) {
            e.printStackTrace();
            messageLabel.setText("Erreur lors du chargement de la page de connexion");
            messageLabel.getStyleClass().clear();
            messageLabel.getStyleClass().add("error-message");
        }
    }
}
