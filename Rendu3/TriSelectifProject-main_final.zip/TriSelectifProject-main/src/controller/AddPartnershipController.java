package controller;

import dao.AdresseDAO;
import dao.CommerceDAO;
import dao.ContratPartenariatDAO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import main.Main;
import model.Adresse;
import model.Commerce;
import model.ContratPartenariat;

import java.time.LocalDate;
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;

public class AddPartnershipController {
    @FXML private ComboBox<Adresse> adresseCombo;
    @FXML private ComboBox<Commerce> commerceCombo;
    @FXML private TextField centreIdField;
    @FXML private CheckBox estPartenaireCheckBox;
    @FXML private DatePicker dateDebutPicker;
    @FXML private DatePicker dateFinPicker;
    @FXML private Label feedbackLabel;
    @FXML
    private Label infoLabel;

    private Connection connection;
    private CommerceDAO commerceDAO;
    private ContratPartenariatDAO contratPartenariatDAO;

    public void setConnection(Connection connection) {
        this.connection = connection;
        this.commerceDAO = new CommerceDAO(connection);
        this.contratPartenariatDAO = new ContratPartenariatDAO(connection); // Use the passed connection
    }

    @FXML
    private void initialize() {
        // Initialize DAOs with Main.conn as a fallback
        if (commerceDAO == null) {
            commerceDAO = new CommerceDAO(Main.conn);
        }
        if (contratPartenariatDAO == null) {
            contratPartenariatDAO = new ContratPartenariatDAO(Main.conn);
        }

        // Load addresses
        AdresseDAO adresseDAO = new AdresseDAO(Main.conn);
        List<Adresse> adresses = adresseDAO.findAll();
        adresseCombo.getItems().addAll(adresses);

        adresseCombo.setCellFactory(param -> new ListCell<Adresse>() {
            @Override
            protected void updateItem(Adresse item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null && !empty) {
                    setText(item.toString());
                } else {
                    setText(null);
                }
            }
        });

        adresseCombo.setButtonCell(new ListCell<Adresse>() {
            @Override
            protected void updateItem(Adresse item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null && !empty) {
                    setText(item.toString());
                } else {
                    setText(null);
                }
            }
        });

        // Load commerces
        loadCommerceList();

        // Set default values for date pickers
        dateDebutPicker.setValue(LocalDate.now());
        dateFinPicker.setValue(LocalDate.now().plusMonths(6));
        feedbackLabel.setText("");
    }

    @FXML
    private void handleCommerceSelected() {
        Commerce selectedCommerce = commerceCombo.getSelectionModel().getSelectedItem();
        if (selectedCommerce != null) {
            AdresseDAO adresseDAO = new AdresseDAO(Main.conn);
            List<Adresse> addresses = adresseDAO.findAll();
            adresseCombo.getItems().clear();
            adresseCombo.getItems().addAll(addresses);
        }
    }

    @FXML
    private void handleAddPartnership() {
        try {
            // Validate contratPartenariatDAO
            if (contratPartenariatDAO == null) {
                throw new IllegalStateException("ContratPartenariatDAO is not initialized.");
            }

            Commerce selectedCommerce = commerceCombo.getSelectionModel().getSelectedItem();
            if (selectedCommerce == null) {
                feedbackLabel.setText("Please select a commerce.");
                return;
            }
            int commerceId = selectedCommerce.getIdCommerce();

            int centreId;
            try {
                centreId = Integer.parseInt(centreIdField.getText().trim());
            } catch (NumberFormatException e) {
                feedbackLabel.setText("Centre ID must be a valid integer.");
                return;
            }
            boolean estPartenaire = estPartenaireCheckBox.isSelected();
            LocalDate dateDebut = dateDebutPicker.getValue();
            LocalDate dateFin = dateFinPicker.getValue();

            if (dateDebut == null || dateFin == null) {
                feedbackLabel.setText("Please select both start and end dates.");
                return;
            }

            if (dateFin.isBefore(dateDebut)) {
                feedbackLabel.setText("End date cannot be before start date.");
                return;
            }

            Commerce commerce = commerceDAO.find(commerceId);
            if (commerce == null) {
                feedbackLabel.setText("Commerce with ID " + commerceId + " not found.");
                return;
            }

            System.out.println("Creating ContratPartenariat: centreId=" + centreId + ", commerceId=" + commerceId + ", estPartenaire=" + estPartenaire + ", dateDebut=" + dateDebut + ", dateFin=" + dateFin);
            ContratPartenariat contrat = new ContratPartenariat(centreId, commerceId, estPartenaire, dateDebut, dateFin);
            System.out.println("ContratPartenariat created: " + contrat);
            contratPartenariatDAO.create(contrat);
            infoLabel.setText("ContratPartenariat createdavec succès.");
            infoLabel.setVisible(true);
            feedbackLabel.setText("Partnership added successfully!");
            feedbackLabel.setStyle("-fx-text-fill: green;");

            clearForm();
        } catch (IllegalArgumentException e) {
            feedbackLabel.setText("Invalid input: " + e.getMessage());
            feedbackLabel.setStyle("-fx-text-fill: red;");
        } catch (Exception e) {
            String message = "Error adding partnership: " + e.getMessage();
            if (e.getCause() instanceof SQLException) {
                SQLException sqlEx = (SQLException) e.getCause();
                if (sqlEx.getSQLState().startsWith("23")) {
                    message = "A partnership already exists with these IDs.";
                }
            }
            feedbackLabel.setText(message);
            feedbackLabel.setStyle("-fx-text-fill: red;");
            e.printStackTrace();
        }
    }

    private void loadCommerceList() {
        List<Commerce> commerces = commerceDAO.findAll();
        commerceCombo.getItems().setAll(commerces);

        commerceCombo.setCellFactory(param -> new ListCell<Commerce>() {
            @Override
            protected void updateItem(Commerce item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null && !empty) {
                    setText(item.getNomCommerce());
                } else {
                    setText(null);
                }
            }
        });

        commerceCombo.setButtonCell(new ListCell<Commerce>() {
            @Override
            protected void updateItem(Commerce item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null && !empty) {
                    setText(item.getNomCommerce());
                } else {
                    setText(null);
                }
            }
        });
    }

    public void refreshCommerceList() {
        loadCommerceList();
    }

    @FXML
    private void handleCreateCommerce() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/AddCommerce.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) feedbackLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Create Commerce");
            stage.show();
        } catch (Exception e) {
            System.err.println("Error loading AddCommerce.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleCancel() {
        Stage stage = (Stage) feedbackLabel.getScene().getWindow();
        stage.close();
    }

    private void clearForm() {
        commerceCombo.getSelectionModel().clearSelection();
        centreIdField.clear();
        estPartenaireCheckBox.setSelected(false);
        dateDebutPicker.setValue(LocalDate.now());
        dateFinPicker.setValue(LocalDate.now().plusMonths(6));
        feedbackLabel.setText("");
        feedbackLabel.setStyle("");
    }
}