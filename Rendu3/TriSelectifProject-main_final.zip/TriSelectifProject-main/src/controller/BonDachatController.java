package controller;

import dao.BonReductionDAO;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.BonReduction;
import model.Menage;

import java.io.IOException;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.List;
import java.util.Random;

public class BonDachatController {

    @FXML private TableView<BonReduction> vouchersTableView;
    @FXML private TableColumn<BonReduction, String> idColumn;
    @FXML private TableColumn<BonReduction, String> commerceColumn;
    @FXML private TableColumn<BonReduction, String> valueColumn;
    @FXML private TableColumn<BonReduction, String> dateExpirationColumn;
    @FXML private TableColumn<BonReduction, String> couponCodeColumn;
    @FXML private TableColumn<BonReduction, String> statusColumn;
    @FXML private TableColumn<BonReduction, String> actionColumn;

    private Connection conn;
    private Menage currentMenage;
    private ObservableList<BonReduction> bonList;

    @FXML
    private void initialize() {
        bonList = FXCollections.observableArrayList();

        // Set up TableView columns
        idColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getIdBon().toString()));
        commerceColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getCommerce().getNomCommerce()));
        valueColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getValeur() + " €"));
        dateExpirationColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDateExp().toString()));
        couponCodeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(generateRandomCouponCode()));
        statusColumn.setCellValueFactory(cellData -> {
            BonReduction bon = cellData.getValue();
            if (bon.getBonUtilise()) {
                return new SimpleStringProperty("Utilisé");
            } else if (bon.getDateExp().isBefore(LocalDate.now())) {
                return new SimpleStringProperty("Expiré");
            } else {
                return new SimpleStringProperty("Disponible");
            }
        });
        actionColumn.setCellFactory(param -> new TableCell<>() {
            private final Button actionButton = new Button();

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                    return;
                }
                BonReduction bon = getTableView().getItems().get(getIndex());
                if (bon.getBonUtilise() || bon.getDateExp().isBefore(LocalDate.now())) {
                    setGraphic(null);
                    return;
                }
                actionButton.setText("Utiliser");
                actionButton.setStyle("-fx-background-color: #28a745; -fx-text-fill: white; -fx-background-radius: 5px;");
                actionButton.setOnAction(event -> handleUseVoucher(bon));
                setGraphic(actionButton);
                setText(null);
            }
        });

        vouchersTableView.setItems(bonList);
    }

    // Method to generate a random 8-character coupon code (letters and numbers)
    private String generateRandomCouponCode() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"; // Fixed typo: ABCTUVWXYZ -> ABCDEFGHIJKLMNOPQRSTUVWXYZ
        Random random = new Random();
        StringBuilder couponCode = new StringBuilder(8);
        for (int i = 0; i < 8; i++) {
            couponCode.append(characters.charAt(random.nextInt(characters.length())));
        }
        return couponCode.toString();
    }

    public void setConnection(Connection connection) {
        this.conn = connection;
        if (this.conn == null) {
            throw new IllegalStateException("Database connection is null in BonDachatController");
        }
        loadInitialData();
    }

    public void setMenage(Menage mm) {
        this.currentMenage = mm;
        if (this.currentMenage == null) {
            throw new IllegalStateException("Menage is null in BonDachatController");
        }
        loadInitialData();
    }

    private void loadInitialData() {
        if (currentMenage == null) {
            System.out.println("men emppty in bno dachat");
            return;
        }
        if (conn == null) {
            System.out.println("conn is null in BonDachatController");
            return;
        }
        System.out.println("Current Menage: " + currentMenage.getNom() + ", ID: " + currentMenage.getId());

        // Fetch BonReduction objects from the database
        BonReductionDAO bonReductionDAO = new BonReductionDAO(conn);
        List<BonReduction> bons = bonReductionDAO.findByMenage(currentMenage.getId());

        // Populate mapBons in currentMenage
        currentMenage.getMapBons().clear(); // Clear existing entries to avoid duplicates
        for (BonReduction bon : bons) {
            bon.setMenageBon(currentMenage);
            currentMenage.getMapBons().put(bon.getIdBon(), bon);
        }

        System.out.println("Number of BonReduction in mapBons: " + currentMenage.getMapBons().size());
        bonList.setAll(currentMenage.getMapBons().values());
        System.out.println("bonList size after loading: " + bonList.size());
    }

    private void handleUseVoucher(BonReduction bon) {
        bon.utiliser();
        BonReductionDAO bonReductionDAO = new BonReductionDAO(conn);
        bonReductionDAO.updateBonUtilise(bon.getIdBon(), true);
        vouchersTableView.refresh();
        showAlert(Alert.AlertType.INFORMATION, "Succès", "Bon de réduction utilisé avec succès !");
    }

    @FXML
    private void handleDashboardAction(ActionEvent event) {
        try {
            String fxmlPath = "/view/pages/menageDashboard.fxml";
            if (getClass().getResource(fxmlPath) == null) {
                throw new IOException("FXML file not found: " + fxmlPath);
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();

            Object controller = loader.getController();
            if (controller == null) {
                throw new IllegalStateException("Controller not found in FXML file: " + fxmlPath);
            }
            if (!(controller instanceof MenageDashboardController)) {
                throw new IllegalStateException("Expected MenageDashboardController, but found: " + controller.getClass().getName());
            }

            MenageDashboardController dashboardController = (MenageDashboardController) controller;
            dashboardController.setConnection(conn);
            dashboardController.setMenage(currentMenage);
            dashboardController.initData();

            String cssPath = "/view/css/menageDashboard.css";
            if (getClass().getResource(cssPath) == null) {
                System.out.println("CSS file not found: " + cssPath + ". Proceeding without stylesheet.");
            }

            Stage stage = (Stage) vouchersTableView.getScene().getWindow();
            Scene scene = new Scene(root);
            if (getClass().getResource(cssPath) != null) {
                scene.getStylesheets().add(getClass().getResource(cssPath).toExternalForm());
            }
            stage.setScene(scene);
            stage.setTitle("Tableau de bord - Tri Sélectif");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de retourner au tableau de bord: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur inattendue", "Une erreur est survenue: " + e.getMessage());
        }
    }

    @FXML
    private void handleProfileAction(ActionEvent event) {
        showAlert(Alert.AlertType.INFORMATION, "Info", "Navigation vers Mon Profil (non implémenté).");
    }

    @FXML
    private void handleLogoutAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/LoginPage.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) vouchersTableView.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Connexion - Tri Sélectif");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de se déconnecter: " + e.getMessage());
        }
    }

    @FXML
    private void handleHistoryAction(ActionEvent event) {
        showAlert(Alert.AlertType.INFORMATION, "Info", "Navigation vers Historique des Dépôts (non implémenté).");
    }

    @FXML
    private void handleExchangeAction(ActionEvent event) {
        try {
            String fxmlPath = "/view/pages/ExchangePointsPage.fxml";
            if (getClass().getResource(fxmlPath) == null) {
                throw new IOException("FXML file not found: " + fxmlPath);
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();

            ExchangeController controller = loader.getController();
            controller.setConnection(conn);
            controller.setMenage(currentMenage);

            String cssPath = "/view/css/echangePoint.css";
            if (getClass().getResource(cssPath) == null) {
                System.out.println("CSS file not found: " + cssPath + ". Proceeding without stylesheet.");
            }

            Stage stage = (Stage) vouchersTableView.getScene().getWindow();
            Scene scene = new Scene(root);
            if (getClass().getResource(cssPath) != null) {
                scene.getStylesheets().add(getClass().getResource(cssPath).toExternalForm());
            }
            stage.setScene(scene);
            stage.setTitle("Échanger vos Points - Tri Sélectif");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de naviguer vers la page d'échange: " + e.getMessage());
        }
    }

    @FXML
    private void handleVouchersAction(ActionEvent event) {
        // Already on this page, do nothing
    }

    @FXML
    private void handleAboutAction(ActionEvent event) {
        showAlert(Alert.AlertType.INFORMATION, "À propos", "Application Tri Sélectif\nVersion 1.0\nDéveloppé pour encourager le recyclage.");
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}