package controller;

import dao.BacDAO;
import dao.CentreTriDAO;
import dao.DepotDAO;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Side;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.stage.Stage;
import javafx.util.Duration;
import main.Main;
import model.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class StatistiquesController {

    @FXML private Label titleLabel;
    @FXML private Label totalBacsLabel;
    @FXML private Label totalCapaciteLabel;
    @FXML private Label totalContenuLabel;
    @FXML private Label totalDepotsLabel;
    @FXML private Label totalPoidsDepotsLabel;
    @FXML private Label totalPointsGagnesLabel;
    @FXML private BarChart<String, Number> contenuBarChart;
    @FXML private PieChart couleurPieChart;
    @FXML private LineChart<String, Number> poidsDepotsOverTimeChart;
    @FXML private BarChart<String, Number> poidsDepotsByTypeAndCouleurChart;
    @FXML private PieChart resultatDepotsPieChart;
    @FXML private Button retourButton;
    @FXML private Button logoutButton;

    private Connection connection;
    private BacDAO bacDAO;
    private DepotDAO depotDAO;
    private CentreTriDAO centreTriDAO;
    private int centreId;
    private String centreName;
    private ObservableList<Bac> bacsList;
    private ObservableList<Depot> depotsList;
    private DecimalFormat decimalFormat = new DecimalFormat("#.#");

    public void setCentreId(int centreId) {
        this.centreId = centreId;
        loadData();
    }

    public void setCentreName(String centreName) {
        this.centreName = centreName;
        titleLabel.setText("Statistiques - " + centreName);
    }

    @FXML
    public void initialize() {
        connection = Main.conn;
        if (connection == null) {
            showErrorMessage("Erreur: Connexion à la base de données non disponible");
            return;
        }

        bacDAO = new BacDAO(connection);
        depotDAO = new DepotDAO(connection);
        centreTriDAO = new CentreTriDAO(connection);
        bacsList = FXCollections.observableArrayList();
        depotsList = FXCollections.observableArrayList();

        // Configurer l'apparence des graphiques
        contenuBarChart.setLegendVisible(false); // Bar chart doesn't need a legend since colors are applied directly
        couleurPieChart.setLabelLineLength(20);
        couleurPieChart.setLegendSide(Side.RIGHT);
        couleurPieChart.setLegendVisible(false); // Legend already disabled for couleurPieChart

        poidsDepotsOverTimeChart.setLegendVisible(true);
        poidsDepotsByTypeAndCouleurChart.setLegendVisible(false); // Legend already disabled for poidsDepotsByTypeAndCouleurChart

        resultatDepotsPieChart.setLabelLineLength(20);
        resultatDepotsPieChart.setLegendSide(Side.RIGHT);
        resultatDepotsPieChart.setLegendVisible(false); // Disable legend for resultatDepotsPieChart
        resultatDepotsPieChart.getStyleClass().add("resultat-pie"); // Add custom style class for coloring
    }

    private void loadData() {
        if (centreId <= 0) {
            showErrorMessage("ID du centre non défini.");
            return;
        }

        loadCentreInfo();
        loadBacs();
        loadDepots();
        updateStatistics();
        populateCharts();
    }

    private void loadCentreInfo() {
        try {
            CentreTri centre = centreTriDAO.find(centreId);
            if (centre != null) {
                centreName = centre.getNomCentre();
                titleLabel.setText("Statistiques - " + centreName);
            } else {
                titleLabel.setText("Statistiques - Centre de tri inconnu");
            }
        } catch (Exception e) {
            System.err.println("Erreur lors du chargement des informations du centre: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadBacs() {
        bacsList.clear();
        try {
            CentreTri centre = centreTriDAO.find(centreId);
            if (centre == null) {
                System.out.println("loadBacs: Centre non trouvé pour centreId: " + centreId);
                showErrorMessage("Erreur: Centre de tri non trouvé (ID: " + centreId + ")");
                return;
            }
            System.out.println("Centre trouvé: " + centre.getNomCentre());

            List<Bac> bacs = bacDAO.findAllByCentre(centreId);
            if (bacs.isEmpty()) {
                System.out.println("Aucun bac trouvé pour centreId: " + centreId);
                showInfoMessage("Aucun bac disponible pour ce centre");
            } else {
                System.out.println("Bacs trouvés pour centreId " + centreId + ": " + bacs.size());
                for (Bac bac : bacs) {
                    System.out.println("Bac: " + bac.getIdBac() + ", Couleur: " + bac.getCouleurBac() + ", Contenu: " + bac.getContenu());
                }
                bacsList.addAll(bacs);
                showSuccessMessage("Bacs chargés avec succès");
            }
        } catch (Exception e) {
            System.err.println("Erreur lors du chargement des bacs: " + e.getMessage());
            e.printStackTrace();
            showErrorMessage("Erreur lors du chargement des bacs: " + e.getMessage());
        }
    }

    private void loadDepots() {
        depotsList.clear();
        String sql = "SELECT d.*, a.id AS adresse_id, a.numero, a.nomRue, a.codePostal, a.ville " +
                "FROM Depot d " +
                "JOIN Adresse a ON d.adresse_id = a.id";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Depot depot = new Depot(
                        rs.getInt("idDepot"),
                        rs.getInt("poidsDepot"),
                        Couleur.valueOf(rs.getString("couleur")),
                        Type.valueOf(rs.getString("typeDechet")),
                        new Adresse(
                                rs.getInt("adresse_id"),
                                rs.getInt("numero"),
                                rs.getString("nomRue"),
                                rs.getInt("codePostal"),
                                rs.getString("ville")
                        ),
                        ResCat.valueOf(rs.getString("resultat")),
                        rs.getInt("pointsGagnes"),
                        null, // Menage is not fully loaded here
                        rs.getDate("dateDepot").toLocalDate(),
                        rs.getTime("heureDepot").toLocalTime()
                );
                depotsList.add(depot);
            }
            if (depotsList.isEmpty()) {
                showInfoMessage("Aucun dépôt disponible");
            } else {
                showSuccessMessage("Dépôts chargés avec succès: " + depotsList.size());
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors du chargement des dépôts: " + e.getMessage());
            e.printStackTrace();
            showErrorMessage("Erreur lors du chargement des dépôts: " + e.getMessage());
        }
    }

    private void updateStatistics() {
        // Statistiques des Bacs
        int totalBacs = bacsList.size();
        int totalCapacite = 0;
        int totalContenu = 0;

        for (Bac bac : bacsList) {
            totalCapacite += bac.getCapacite();
            totalContenu += bac.getContenu();
        }

        double tauxRemplissage = totalCapacite > 0 ? (double) totalContenu / totalCapacite * 100 : 0;
        totalBacsLabel.setText("Nombre total de bacs: " + totalBacs);
        totalCapaciteLabel.setText("Capacité totale: " + totalCapacite + " g");
        totalContenuLabel.setText("Contenu total: " + totalContenu + " g (" + decimalFormat.format(tauxRemplissage) + "%)");

        // Statistiques des Dépôts
        int totalDepots = depotsList.size();
        int totalPoidsDepots = 0;
        int totalPointsGagnes = 0;

        for (Depot depot : depotsList) {
            totalPoidsDepots += depot.getPoidsDepot();
            totalPointsGagnes += depot.getPtsGagnes();
        }

        totalDepotsLabel.setText("Nombre total de dépôts: " + totalDepots);
        totalPoidsDepotsLabel.setText("Poids total des dépôts: " + totalPoidsDepots + " g");
        totalPointsGagnesLabel.setText("Points gagnés: " + totalPointsGagnes);
    }

    private void populateCharts() {
        // --- Graphiques pour les Bacs ---
        // Graphique à barres (Contenu par couleur)
        contenuBarChart.getData().clear();
        Map<Couleur, Integer> contenuByCouleur = new HashMap<>();
        Map<Couleur, Integer> capaciteByCouleur = new HashMap<>();

        for (Couleur couleur : Couleur.values()) {
            if (couleur == Couleur.toutCol) continue;
            contenuByCouleur.put(couleur, 0);
            capaciteByCouleur.put(couleur, 0);
        }

        for (Bac bac : bacsList) {
            Couleur couleur = bac.getCouleurBac();
            contenuByCouleur.put(couleur, contenuByCouleur.getOrDefault(couleur, 0) + bac.getContenu());
            capaciteByCouleur.put(couleur, capaciteByCouleur.getOrDefault(couleur, 0) + bac.getCapacite());
        }

        for (Couleur couleur : Couleur.values()) {
            if (couleur == Couleur.toutCol) continue;
            if (capaciteByCouleur.getOrDefault(couleur, 0) > 0) {
                XYChart.Series<String, Number> series = new XYChart.Series<>();
                series.setName(couleur.name().toLowerCase());
                series.getData().add(new XYChart.Data<>(couleur.name().toLowerCase(), contenuByCouleur.getOrDefault(couleur, 0)));
                contenuBarChart.getData().add(series);

                Platform.runLater(() -> {
                    for (XYChart.Data<String, Number> data : series.getData()) {
                        if (data.getNode() != null) {
                            String colorStyle = "-fx-bar-fill: " + getColorForCouleur(couleur) + ";";
                            data.getNode().setStyle(colorStyle);

                            int contenu = contenuByCouleur.getOrDefault(couleur, 0);
                            int capacite = capaciteByCouleur.getOrDefault(couleur, 0);
                            double pourcentage = capacite > 0 ? (double) contenu / capacite * 100 : 0;

                            Tooltip tooltip = new Tooltip(
                                    couleur.name() + "\n" +
                                            "Contenu: " + contenu + " g\n" +
                                            "Capacité: " + capacite + " g\n" +
                                            "Remplissage: " + decimalFormat.format(pourcentage) + "%"
                            );
                            tooltip.setShowDelay(Duration.millis(100));
                            Tooltip.install(data.getNode(), tooltip);
                        }
                    }
                });
            }
        }

        // Graphique en camembert (Distribution des bacs par couleur)
        Map<Couleur, Integer> countByCouleur = new HashMap<>();
        for (Couleur couleur : Couleur.values()) {
            if (couleur == Couleur.toutCol) continue;
            countByCouleur.put(couleur, 0);
        }

        for (Bac bac : bacsList) {
            Couleur couleur = bac.getCouleurBac();
            countByCouleur.put(couleur, countByCouleur.getOrDefault(couleur, 0) + 1);
        }

        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
        int totalCount = bacsList.size();

        for (Couleur couleur : Couleur.values()) {
            if (couleur == Couleur.toutCol) continue;
            int count = countByCouleur.getOrDefault(couleur, 0);
            if (count > 0) {
                double percentage = totalCount > 0 ? (double) count / totalCount * 100 : 0;
                String label = couleur.name().toLowerCase() + " (" + decimalFormat.format(percentage) + "%)";
                PieChart.Data slice = new PieChart.Data(label, count);
                pieChartData.add(slice);
            }
        }

        couleurPieChart.setData(pieChartData);

        Platform.runLater(() -> {
            for (PieChart.Data data : couleurPieChart.getData()) {
                String couleurName = data.getName().split(" ")[0].toLowerCase();
                Couleur couleur = Couleur.valueOf(couleurName);

                String color = getColorForCouleur(couleur);
                data.getNode().setStyle("-fx-pie-color: " + color + ";");

                int count = countByCouleur.getOrDefault(couleur, 0);
                double percentage = totalCount > 0 ? (double) count / totalCount * 100 : 0;

                Tooltip tooltip = new Tooltip(
                        couleurName + "\n" +
                                "Nombre de bacs: " + count + " / " + totalCount + "\n" +
                                "Pourcentage: " + decimalFormat.format(percentage) + "%"
                );
                tooltip.setShowDelay(Duration.millis(100));
                Tooltip.install(data.getNode(), tooltip);
            }
        });

        // --- Graphiques pour les Dépôts ---
        // Line Chart: Poids des dépôts au fil du temps
        poidsDepotsOverTimeChart.getData().clear();
        Map<LocalDate, Integer> poidsByDate = new TreeMap<>();

        for (Depot depot : depotsList) {
            LocalDate date = depot.getDate();
            poidsByDate.put(date, poidsByDate.getOrDefault(date, 0) + depot.getPoidsDepot());
        }

        XYChart.Series<String, Number> poidsSeries = new XYChart.Series<>();
        poidsSeries.setName("Poids des dépôts");
        for (Map.Entry<LocalDate, Integer> entry : poidsByDate.entrySet()) {
            String dateStr = entry.getKey().toString();
            int poids = entry.getValue();
            poidsSeries.getData().add(new XYChart.Data<>(dateStr, poids));
        }
        poidsDepotsOverTimeChart.getData().add(poidsSeries);

        Platform.runLater(() -> {
            for (XYChart.Data<String, Number> data : poidsSeries.getData()) {
                if (data.getNode() != null) {
                    Tooltip tooltip = new Tooltip("Date: " + data.getXValue() + "\nPoids: " + data.getYValue() + " g");
                    tooltip.setShowDelay(Duration.millis(100));
                    Tooltip.install(data.getNode(), tooltip);
                }
            }
        });

        // Stacked Bar Chart: Poids des dépôts par type et couleur
        poidsDepotsByTypeAndCouleurChart.getData().clear();
        Map<Type, Map<Couleur, Integer>> poidsByTypeAndCouleur = new HashMap<>();

        for (Type type : Type.values()) {
            if (type == Type.toutType) continue;
            poidsByTypeAndCouleur.put(type, new HashMap<>());
            for (Couleur couleur : Couleur.values()) {
                if (couleur == Couleur.toutCol) continue;
                poidsByTypeAndCouleur.get(type).put(couleur, 0);
            }
        }

        for (Depot depot : depotsList) {
            Type type = depot.getType();
            Couleur couleur = depot.getCouleurDepot();
            if (type == Type.toutType || couleur == Couleur.toutCol) continue;
            Map<Couleur, Integer> couleurMap = poidsByTypeAndCouleur.get(type);
            couleurMap.put(couleur, couleurMap.getOrDefault(couleur, 0) + depot.getPoidsDepot());
        }

        for (Couleur couleur : Couleur.values()) {
            if (couleur == Couleur.toutCol) continue;
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName(couleur.name().toLowerCase());
            for (Type type : Type.values()) {
                if (type == Type.toutType) continue;
                int poids = poidsByTypeAndCouleur.get(type).getOrDefault(couleur, 0);
                series.getData().add(new XYChart.Data<>(type.name().toLowerCase(), poids));
            }
            poidsDepotsByTypeAndCouleurChart.getData().add(series);

            Platform.runLater(() -> {
                for (XYChart.Data<String, Number> data : series.getData()) {
                    if (data.getNode() != null) {
                        String colorStyle = "-fx-bar-fill: " + getColorForCouleur(couleur) + ";";
                        data.getNode().setStyle(colorStyle);

                        // Add custom attribute for legend styling (not needed since legend is disabled)
                        data.getNode().getStyleClass().add("bar-" + couleur.name().toLowerCase());

                        Tooltip tooltip = new Tooltip(
                                "Type: " + data.getXValue() + "\n" +
                                        "Couleur: " + series.getName() + "\n" +
                                        "Poids: " + data.getYValue() + " g"
                        );
                        tooltip.setShowDelay(Duration.millis(100));
                        Tooltip.install(data.getNode(), tooltip);
                    }
                }
            });
        }

        // Pie Chart: Distribution des dépôts par résultat (correctness)
        Map<ResCat, Integer> countByResultat = new HashMap<>();
        for (ResCat resultat : ResCat.values()) {
            if (resultat == ResCat.total) continue;
            countByResultat.put(resultat, 0);
        }

        for (Depot depot : depotsList) {
            ResCat resultat = depot.getCorrect();
            if (resultat == ResCat.total) continue;
            countByResultat.put(resultat, countByResultat.getOrDefault(resultat, 0) + 1);
        }

        ObservableList<PieChart.Data> resultatPieChartData = FXCollections.observableArrayList();
        int totalDepots = depotsList.size();

        for (ResCat resultat : ResCat.values()) {
            if (resultat == ResCat.total) continue;
            int count = countByResultat.getOrDefault(resultat, 0);
            if (count > 0) {
                double percentage = totalDepots > 0 ? (double) count / totalDepots * 100 : 0;
                String label = resultat.name().toLowerCase() + " (" + decimalFormat.format(percentage) + "%)";
                PieChart.Data slice = new PieChart.Data(label, count);
                resultatPieChartData.add(slice);
            }
        }

        resultatDepotsPieChart.setData(resultatPieChartData);

        Platform.runLater(() -> {
            for (PieChart.Data data : resultatDepotsPieChart.getData()) {
                String resultatName = data.getName().split(" ")[0].toLowerCase();
                ResCat resultat = ResCat.valueOf(resultatName);

                String color = getColorForResultat(resultat);
                data.getNode().setStyle("-fx-pie-color: " + color + ";");

                int count = countByResultat.getOrDefault(resultat, 0);
                double percentage = totalDepots > 0 ? (double) count / totalDepots * 100 : 0;

                Tooltip tooltip = new Tooltip(
                        resultatName + "\n" +
                                "Nombre de dépôts: " + count + " / " + totalDepots + "\n" +
                                "Pourcentage: " + decimalFormat.format(percentage) + "%"
                );
                tooltip.setShowDelay(Duration.millis(100));
                Tooltip.install(data.getNode(), tooltip);
            }
        });
    }

    private String getColorForCouleur(Couleur couleur) {
        switch (couleur) {
            case vert:
                return "#4CAF50"; // Vert
            case jaune:
                return "#FFEB3B"; // Jaune
            case gris:
                return "#9E9E9E"; // Gris
            case bleu:
                return "#2196F3"; // Bleu
            default:
                return "#000000"; // Noir par défaut
        }
    }

    private String getColorForResultat(ResCat resultat) {
        switch (resultat) {
            case correct:
                return "#4CAF50"; // Vert
            case incorrect:
                return "#D32F2F"; // Rouge
            default: // Handles ResCat.total
                return "#000000"; // Noir par défaut
        }
    }

    @FXML
    public void handleRetour() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/welcome.fxml"));
            Parent welcomePage = loader.load();
            WelcomeController welcomeController = loader.getController();
            welcomeController.setUserInfo("Centre de Tri", centreName, centreId);
            Scene scene = new Scene(welcomePage, 800, 600);
            Stage stage = (Stage) retourButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Tableau de Bord - " + centreName);
            stage.show();
        } catch (IOException e) {
            showErrorMessage("Erreur lors du retour au tableau de bord");
            e.printStackTrace();
        }
    }

    @FXML
    public void handleLogout() {
        try {
            CentreTri.clearMapCentre();
            System.out.println("StatistiquesController: Déconnexion - mapCentre réinitialisé");

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/MainConnection.fxml"));
            Parent loginPage = loader.load();
            Scene scene = new Scene(loginPage, 600, 400);
            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Connexion");
            stage.show();

            System.out.println("StatistiquesController: Redirection vers la page de connexion réussie");
        } catch (IOException e) {
            showErrorMessage("Erreur lors de la déconnexion: " + e.getMessage());
            System.err.println("StatistiquesController: Erreur lors de la déconnexion - " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showSuccessMessage(String message) {
        System.out.println("Success: " + message);
    }

    private void showErrorMessage(String message) {
        System.err.println("Error: " + message);
    }

    private void showInfoMessage(String message) {
        System.out.println("Info: " + message);
    }
}