package controller;

import dao.BonReductionDAO;
import dao.CommerceDAO;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.BonReduction;
import model.Commerce;
import model.Menage;
import main.Main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class ExchangeController {

    @FXML private Label availablePointsLabel;
    @FXML private ComboBox<Commerce> commerceComboBox;
    @FXML private TableView<BonReduction> reductionsTableView;
    @FXML private TableColumn<BonReduction, String> idColumn;
    @FXML private TableColumn<BonReduction, String> pointsRequiredColumn;
    @FXML private TableColumn<BonReduction, String> reductionValueColumn;
    @FXML private TableColumn<BonReduction, String> expirationColumn;
    @FXML private TableColumn<BonReduction, String> actionColumn;
    @FXML private VBox exchangeFormContainer;
    @FXML private Label selectedCommerceLabel;
    @FXML private Label selectedIdLabel;
    @FXML private Label pointsRequiredLabel;
    @FXML private Label reductionValueLabel;

    private Connection conn;
    private Menage currentMenage;
    private ObservableList<Commerce> commerceList;
    private ObservableList<BonReduction> availableBons;
    private BonReduction selectedBon;

    @FXML
    private void initialize() {
        commerceList = FXCollections.observableArrayList();
        availableBons = FXCollections.observableArrayList();

        commerceComboBox.setItems(commerceList);
        commerceComboBox.setCellFactory(param -> new ListCell<Commerce>() {
            @Override
            protected void updateItem(Commerce item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getNomCommerce());
                }
            }
        });
        commerceComboBox.setButtonCell(new ListCell<Commerce>() {
            @Override
            protected void updateItem(Commerce item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getNomCommerce());
                }
            }
        });

        idColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getIdBon().toString()));
        pointsRequiredColumn.setCellValueFactory(cellData -> {
            double valeur = cellData.getValue().getValeur();
            int pointsRequired = (int) (valeur * 2); // Assuming 2 points = 1€
            return new SimpleStringProperty(pointsRequired + " points");
        });
        reductionValueColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getValeur() + " €"));
        expirationColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDateExp().toString()));
        actionColumn.setCellFactory(param -> new TableCell<>() {
            private final Button exchangeButton = new Button("Échanger");

            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                    return;
                }
                exchangeButton.setStyle("-fx-background-color: #28a745; -fx-text-fill: white; -fx-background-radius: 5px;");
                exchangeButton.setOnAction(event -> {
                    BonReduction bon = getTableView().getItems().get(getIndex());
                    handleExchangeAction(bon);
                });
                setGraphic(exchangeButton);
                setText(null);
            }
        });
        reductionsTableView.setItems(availableBons);
    }

    public void setConnection(Connection connection) {
        this.conn = connection;
        if (this.conn == null) {
            throw new IllegalStateException("Database connection is null in ExchangeController");
        }
        loadInitialData();
    }

    public void setMenage(Menage mm) {
        this.currentMenage = mm;
        if (this.currentMenage == null) {
            throw new IllegalStateException("Menage is null in ExchangeController");
        }
        loadInitialData();
    }

    private void loadInitialData() {
        if (currentMenage == null || conn == null) {
            return;
        }
        availablePointsLabel.setText(currentMenage.getPoints() + " points");

        CommerceDAO commerceDAO = new CommerceDAO(conn);
        List<Commerce> commerces = commerceDAO.findAll();
        commerceList.setAll(commerces);
    }

    @FXML
    private void handleCommerceSelected(ActionEvent event) {
        Commerce selectedCommerce = commerceComboBox.getSelectionModel().getSelectedItem();
        if (selectedCommerce != null) {
            System.out.println("ExchangeController: Commerce selected - " + selectedCommerce.getNomCommerce() + " (ID: " + selectedCommerce.getIdCommerce() + ")");
            BonReductionDAO bonReductionDAO = new BonReductionDAO(conn);
            List<BonReduction> bons = bonReductionDAO.findByCommerce(selectedCommerce.getIdCommerce());
            //System.out.println("ExchangeController: Received bons: " + bons);
            availableBons.clear();
            availableBons.addAll(bons); // Show all BonReduction objects
            System.out.println("ExchangeController: Updated availableBons: " + availableBons);
            if (availableBons.isEmpty()) {
                showAlert(Alert.AlertType.INFORMATION, "Aucun bon disponible", "Aucun bon de réduction disponible pour ce commerce.");
            }
            reductionsTableView.setItems(availableBons);
            exchangeFormContainer.setVisible(false);
            exchangeFormContainer.setManaged(false);
        } else {
            System.out.println("ExchangeController: No commerce selected");
        }
    }
    private void handleExchangeAction(BonReduction bon) {
        selectedBon = bon;
        Commerce selectedCommerce = commerceComboBox.getSelectionModel().getSelectedItem();
        selectedCommerceLabel.setText(selectedCommerce.getNomCommerce());
        selectedIdLabel.setText(bon.getIdBon().toString());
        int pointsRequired = (int) (bon.getValeur() * 2);
        pointsRequiredLabel.setText(pointsRequired + " points");
        reductionValueLabel.setText(bon.getValeur() + " €");
        exchangeFormContainer.setVisible(true);
        exchangeFormContainer.setManaged(true);
    }

    @FXML
    private void handleConfirmExchange(ActionEvent event) {
        if (selectedBon == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un bon de réduction à échanger.");
            return;
        }

        int pointsRequired = (int) (selectedBon.getValeur() * 2);
        int currentPoints = currentMenage.getPoints();
        if (currentPoints < pointsRequired) {
            showAlert(Alert.AlertType.WARNING, "Points insuffisants", "Vous n'avez pas assez de points pour cet échange.");
            return;
        }

        // Update points
        int newPoints = currentPoints - pointsRequired;
        updatePoints(currentMenage.getNom(), newPoints);
        currentMenage.setPoints(newPoints);
        availablePointsLabel.setText(newPoints + " points");

        // Associate BonReduction with Menage
        selectedBon.setMenageBon(currentMenage);
        BonReductionDAO bonReductionDAO = new BonReductionDAO(conn);
        bonReductionDAO.updateMenageId(selectedBon.getIdBon(), currentMenage.getId());

        // Add BonReduction to Menage's mapBons
        currentMenage.getMapBons().put(selectedBon.getIdBon(), selectedBon);

        // Reset form
        exchangeFormContainer.setVisible(false);
        exchangeFormContainer.setManaged(false);
        reductionsTableView.getItems().clear();
        commerceComboBox.getSelectionModel().clearSelection();
        availableBons.clear();

        showAlert(Alert.AlertType.INFORMATION, "Succès", "Échange effectué avec succès ! Votre bon de réduction a été ajouté.");
    }

    @FXML
    private void handleCancelExchange(ActionEvent event) {
        exchangeFormContainer.setVisible(false);
        exchangeFormContainer.setManaged(false);
        selectedBon = null;
    }

    @FXML
    private void handleGoBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/menageDashboard.fxml"));
            Parent root = loader.load();
            MenageDashboardController controller = loader.getController();
            controller.setConnection(conn);
            controller.setMenage(currentMenage);
            controller.initData();

            Stage stage = (Stage) reductionsTableView.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/view/css/menageDashboard.css").toExternalForm());
            stage.setScene(scene);
            stage.setTitle("Tableau de bord - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de retourner au tableau de bord: " + e.getMessage());
        }
    }

    private void updatePoints(String nomCompte, int nouveauxPoints) {
        String sql = "UPDATE menage SET pointsfidelite = ? WHERE nomcompte = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, nouveauxPoints);
            stmt.setString(2, nomCompte);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No rows updated for nom: " + nomCompte);
            }
            System.out.println("Updated points for " + nomCompte + " to " + nouveauxPoints);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update points in database: " + e.getMessage(), e);
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}