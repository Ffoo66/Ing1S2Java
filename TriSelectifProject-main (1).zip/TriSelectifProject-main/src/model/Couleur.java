package model;
public enum Couleur {
	vert,
	jaune,
	bleu,
	gris,
	toutCol
}