package model;
import java.time.*;
import java.util.*;

import dao.CommerceDAO;
import javafx.beans.property.*;
import main.Main;

public class BonReduction {
	private Integer idBon;
	private double valeur;
	private boolean bonUtilise;
	private Commerce commerce;
	private Menage menageBon;
	private LocalDate dateExpiration;
	// --- JavaFX Properties for TableView only ---

	public StringProperty idBonProperty() {
		return new SimpleStringProperty(this.idBon.toString());
	}

	public DoubleProperty valeurProperty() {
		return new SimpleDoubleProperty(this.valeur);
	}

	public StringProperty statusProperty() {
		return new SimpleStringProperty(this.bonUtilise ? "Utilisé" : "Disponible");
	}

	public StringProperty commerceNameProperty() {
		return new SimpleStringProperty(this.commerce != null ? this.commerce.getNomCommerce() : "");
	}

	public StringProperty dateExpProperty() {
		return new SimpleStringProperty(this.dateExpiration != null ? this.dateExpiration.toString() : "");
	}

	/// -----------------//

	public Integer getIdBon() {
		return this.idBon;
	}

	public double getValeur() {
		return this.valeur;
	}

	public boolean getBonUtilise() {
		return this.bonUtilise;
	}

	public Commerce getCommerce() {
		return this.commerce;
	}
	public void setCommerce(Commerce f) {
		 this.commerce=f;
	}

	public Menage getMenageBon() {
		return this.menageBon;
	}
	public void setMenageBon(Menage mn) {
		 this.menageBon=mn;
	}

	public LocalDate getDateExp() {
		return this.dateExpiration;
	}

	public void setIdBon(int nId) {
			this.idBon = nId;

	}

	public void utiliser() {
		this.bonUtilise = true;
	}

	public String toString() {
		return "BonReduction {\n\tId bon : " + this.idBon + "\n\tValeur : " + this.valeur + "\n\tBon utilisé : "
				+ this.bonUtilise + "\n\tCommerce bon : " + this.commerce.getIdCommerce() + "\n\tMénage bon : "
				+ this.menageBon.getNom() + "\n\tDate expiration : " + this.dateExpiration + "\n}\n"
				;
	}

	public BonReduction(int id,  Menage nMenage,boolean bnUtil ,LocalDate nDateExp) {
		if (   nMenage != null && !LocalDate.now().isAfter(nDateExp)) {
			//int id=Utils.generateRandomIntBasedOnTime();
			this.idBon = id;
			this.bonUtilise = false;
			this.menageBon = nMenage;
			this.dateExpiration = nDateExp;
		}
	}
	public BonReduction( double val,int idCommerce, boolean bnUtil, LocalDate nDateExp) {
		// Fetch Commerce using CommerceDAO
		//System.out.println("BonReduction id comm: " + idCommerce);
		CommerceDAO commerceDAO = new CommerceDAO(Main.conn);
		Commerce fetchedCommerce = commerceDAO.find(idCommerce);
		//System.out.println("fteched comm used in BonReduction : " + fetchedCommerce.getIdCommerce() );
		if (fetchedCommerce == null) {
			throw new IllegalArgumentException("Commerce with id " + idCommerce + " not found.");
		}
		// No Menage provided, so menageBon remains null
		//this.idBon = id;
		this.valeur = val; // Default value since valeur is required in the table
		this.bonUtilise = bnUtil;
		this.menageBon = null; // Keeping menage_id null as requested
		this.dateExpiration = nDateExp;
	}
	public BonReduction(double nValeur, Commerce nCommerce, Menage nMenage, LocalDate nDateExp) {
		if (nValeur > 0 && nCommerce != null && nMenage != null && !LocalDate.now().isAfter(nDateExp)) {
			int id=Utils.generateRandomIntBasedOnTime();
			this.idBon = id;
			this.valeur = nValeur;
			this.bonUtilise = false;
			this.commerce = nCommerce;
			this.menageBon = nMenage;
			this.dateExpiration = nDateExp;
		}
	}
}
