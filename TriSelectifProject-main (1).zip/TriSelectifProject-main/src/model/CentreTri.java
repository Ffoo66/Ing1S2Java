package model;

import java.time.*;
import java.util.*;

public class CentreTri {
    private int idCentre;
    private String nomCentre;
    private Adresse adresseCentre;

    private HashMap<Integer, Bac> mapBac;
    private HashMap<Integer, Boolean> mapNotifPleine;
    private HashMap<Integer, Depot> historiqueDepot;
    private HashMap<Integer, ContratPartenariat> mapPartenaire;

    private static HashMap<Integer, CentreTri> mapCentre = new HashMap<>();
    private static int compteCentre;

    public static void clearMapCentre() {
        mapCentre.clear();
        compteCentre = 0;
        System.out.println("CentreTri: mapCentre et compteCentre réinitialisés");
    }

    public int getIdCentre() {
        return this.idCentre;
    }

    public String getNomC() {
        return this.nomCentre;
    }

    public Adresse getAdresseC() {
        return this.adresseCentre;
    }

    public HashMap<Integer, Bac> getMapBac() {
        return this.mapBac;
    }

    public Bac getBac(Integer idBac) {
        return this.mapBac.get(idBac);
    }

    public HashMap<Integer, Boolean> getMapNotifPleine() {
        return this.mapNotifPleine;
    }

    public boolean getNotifPleine(Integer idBac) {
        return this.mapNotifPleine.getOrDefault(idBac, false);
    }

    public HashMap<Integer, Depot> getMapDepot() {
        return this.historiqueDepot;
    }

    public Depot getDepot(Integer idDepot) {
        return this.historiqueDepot.get(idDepot);
    }

    public HashMap<Integer, ContratPartenariat> getMapPartenaire() {
        return this.mapPartenaire;
    }

    public ContratPartenariat getPartenaire(Integer idPartenaire) {
        return this.mapPartenaire.get(idPartenaire);
    }

    public static HashMap<Integer, CentreTri> getMapCentre() {
        return mapCentre;
    }

    public static int getCompteCentre() {
        return compteCentre;
    }

    public void setIdCentre(int nId) {
        if (nId >= 0) {
            if (mapCentre.containsKey(this.idCentre)) {
                mapCentre.remove(this.idCentre);
            }
            this.idCentre = nId;
            mapCentre.put(nId, this);

            if (nId >= compteCentre) {
                compteCentre = nId + 1;
            }
        }
    }

    public void setNomC(String nNomC) {
        this.nomCentre = nNomC;
    }

    public void creerBac(Couleur col, int capacite) {
        int id = new Random().nextInt(Integer.MAX_VALUE);
        while (mapBac.containsKey(id)) {
            id = new Random().nextInt(Integer.MAX_VALUE);
        }

        Bac p = new Bac(id, this, col, capacite);
        mapBac.put(id, p);
        mapNotifPleine.put(id, false);
    }

    public void supprimerBac(Integer idBac) {
        mapBac.remove(idBac);
        mapNotifPleine.remove(idBac);
    }

    public void placerBac(Integer idBac, Adresse a) {
        Bac p = mapBac.get(idBac);
        if (p != null) {
            p.setAdresseBac(a);
        }
    }

    public void retirerBac(Integer idBac) {
        Bac p = mapBac.get(idBac);
        if (p != null) {
            p.setAdresseBac(this.adresseCentre);
            p.getAdresseBac().setNum(0);
        }
    }

    public void retirerRue(Adresse a) {
        for (Bac p : mapBac.values()) {
            if (a.rueEquals(p.getAdresseBac())) {
                p.setAdresseBac(this.adresseCentre);
                p.getAdresseBac().setNum(0);
            }
        }
    }

    public void retirerTout() {
        for (Bac p : mapBac.values()) {
            p.setAdresseBac(this.adresseCentre);
            p.getAdresseBac().setNum(0);
        }
    }

    public void majBac(Integer idBac) {
        Bac p = mapBac.get(idBac);
        if (p != null) {
            boolean pleine = p.getContenu() >= 0.8 * p.getCapacite();
            mapNotifPleine.put(idBac, pleine);
        }
    }

    public ArrayList<Depot> getRes(Couleur col, Type t, LocalTime heureD, LocalTime heureF, LocalDate dateD, LocalDate dateF,
                                   Adresse a, ResCat cat) {
        ArrayList<Depot> resultat = new ArrayList<>();
        for (Depot d : historiqueDepot.values()) {
            boolean couleurOK = (col == Couleur.toutCol || d.getCouleurDepot().equals(col));
            boolean typeOK = (t == Type.toutType || d.getType().equals(t));
            boolean heureOK = (!d.getHoraire().isBefore(heureD) && !d.getHoraire().isAfter(heureF)) ||
                    ((!d.getHoraire().isBefore(heureD) || !d.getHoraire().isAfter(heureF)) && heureD.isAfter(heureF));
            boolean dateOK = (dateD.isAfter(dateF) || (!d.getDate().isBefore(dateD) && !d.getDate().isAfter(dateF)));
            boolean rueOK = (a == null || d.getAdresseDepot().rueEquals(a));
            boolean catOK = (cat == ResCat.total || d.getCorrect().equals(cat));
            if (couleurOK && typeOK && heureOK && dateOK && rueOK && catOK) {
                resultat.add(d);
            }
        }
        return resultat;
    }

    public void collecter() {
        for (Bac b : mapBac.values()) {
            if (b.getAdresseBac().getNum() <= 0) {
                b.vider();
                mapNotifPleine.put(b.getIdBac(), false);
            }
        }
    }

    public void inscrire(String nCompte, String nMDP, Adresse nAdresse) {
        if (Menage.getMapMenage().containsKey(nCompte)) {
            System.out.println("Identifiant déjà existant");
            return;
        }
        Menage m = new Menage(nCompte, nMDP, nAdresse);
        Menage.getMapMenage().put(m.getNom(), m);
    }

    public String getNomCentre() {
        return this.nomCentre;
    }

    public String toString() {
        return "CentreTri {\n\tId centre : " + this.idCentre + "\n\tNom centre : " + this.nomCentre
                + "\n\tAdresse centre : " + this.adresseCentre + "\n}\n";
    }

    public CentreTri(String nomCentre, Adresse adresseCentre) {
        if (nomCentre != null && !nomCentre.isEmpty() && adresseCentre != null) {
            while (mapCentre.containsKey(compteCentre)) {
                compteCentre++;
            }
            this.idCentre = compteCentre++;
            this.nomCentre = nomCentre;
            this.adresseCentre = adresseCentre;
            this.mapBac = new HashMap<>();
            this.mapNotifPleine = new HashMap<>();
            this.historiqueDepot = new HashMap<>();
            this.mapPartenaire = new HashMap<>();
            mapCentre.put(this.idCentre, this);
        }
    }

    public CentreTri(int idCentre, String nomCentre, Adresse adresseCentre) {
        this.idCentre = idCentre;
        this.nomCentre = nomCentre;
        this.adresseCentre = adresseCentre;
        this.mapBac = new HashMap<>();
        this.mapNotifPleine = new HashMap<>();
        this.historiqueDepot = new HashMap<>();
        this.mapPartenaire = new HashMap<>();
        mapCentre.put(this.idCentre, this);
        if (idCentre >= compteCentre) {
            compteCentre = idCentre + 1;
        }
    }
}
