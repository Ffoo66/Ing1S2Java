package controller;

import dao.BonReductionDAO;
import dao.ContratPartenariatDAO;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import main.Main;
import model.ContratPartenariat;
import model.Menage;

import java.io.IOException;
import java.sql.Connection;
import java.time.LocalDate;
import javafx.stage.Stage;

public class ContratPartenariatController {

    @FXML private TableView<ContratPartenariat> partnershipTable;
    @FXML private TableColumn<ContratPartenariat, String> centreColumn;
    @FXML private TableColumn<ContratPartenariat, String> commerceColumn;
    @FXML private TableColumn<ContratPartenariat, LocalDate> dateDebutColumn;
    @FXML private TableColumn<ContratPartenariat, LocalDate> dateFinColumn;
    @FXML private Label totalPartenariatsLabel;
    @FXML private Button removePartnershipButton;
    @FXML private Button addBonReductionButton;
    @FXML private Button addPartnershipButton;
    @FXML private Button goBackButton;
    @FXML private Button refreshButton;


    private ContratPartenariatDAO contratDAO;
    private BonReductionDAO bonReductionDAO;
    private Menage currentUser;
    private int centreId;
    private String centreName;

    @FXML
    private void initialize() {
        contratDAO = new ContratPartenariatDAO(Main.conn);
        bonReductionDAO = new BonReductionDAO(Main.conn);

        centreColumn.setCellValueFactory(cellData ->
                new ReadOnlyStringWrapper(cellData.getValue().getNomCentrePartner()));
        commerceColumn.setCellValueFactory(cellData ->
                new ReadOnlyStringWrapper(cellData.getValue().getNomCommerce()));
        dateDebutColumn.setCellValueFactory(new PropertyValueFactory<>("dateDP"));
        dateFinColumn.setCellValueFactory(new PropertyValueFactory<>("dateFP"));

        partnershipTable.getColumns().setAll(centreColumn, commerceColumn, dateDebutColumn, dateFinColumn);
        partnershipTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        System.out.println("Politique de redimensionnement appliquée: CONSTRAINED_RESIZE_POLICY");
        System.out.println("Nombre de colonnes dans le TableView: " + partnershipTable.getColumns().size());

        loadPartnerships();
    }

    public void setConnection(Connection connection) {
        if (connection == null) {
            throw new IllegalStateException("Database connection is null");
        }
        contratDAO = new ContratPartenariatDAO(connection);
        bonReductionDAO = new BonReductionDAO(connection);
        loadPartnerships();
    }

    public void setCurrentUser(Menage menage) {
        this.currentUser = menage;
    }
    @FXML
    private void handleRefresh(ActionEvent event) {
        loadPartnerships();
        showAlert(Alert.AlertType.INFORMATION, "Actualisation", "Les données ont été actualisées avec succès.");
    }
    public void setCentreId(int centreId) {
        this.centreId = centreId;
        loadPartnerships();
    }

    public void setCentreName(String centreName) {
        this.centreName = centreName;
    }
    @FXML
    private void loadPartnerships() {
        try {
            ObservableList<ContratPartenariat> partnerships = FXCollections.observableArrayList();
            if (centreId == 0) {
                ContratPartenariat partnership = contratDAO.find(centreId);
                if (partnership != null) {
                    partnerships.add(partnership);
                }
            } else {
                partnerships.addAll(contratDAO.findAll());
            }
            partnershipTable.setItems(partnerships);
            partnershipTable.refresh();
            totalPartenariatsLabel.setText(String.valueOf(partnerships.size()));
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Erreur lors du chargement des partenariats: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAddPartnership(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/AddPartnership.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger la page d'ajout de partenariat: " + e.getMessage());
        }
    }



    @FXML
    private void handleAddBonReduction(ActionEvent event) {
        ContratPartenariat selected = partnershipTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un partenariat pour ajouter un bon.");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/addBonReductionPage.fxml"));
            Parent root = loader.load();
            AddBonReductionController controller = loader.getController();
            controller.setConnection(Main.conn);
            controller.setCommerceId(selected.getIdCommerceP());
            Stage stage = new Stage();
            stage.setTitle("Ajouter un Bon de Réduction");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger la page d'ajout de bon de réduction: " + e.getMessage());
        }
    }

    @FXML
    private void handleGoBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/welcome.fxml"));
            Parent root = loader.load();
            WelcomeController controller = loader.getController();
            controller.setUserInfo("Centre de Tri", centreName, centreId);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Tableau de Bord - " + centreName);
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger la page du tableau de bord: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}