package controller;

import dao.AdresseDAO;
import dao.CommerceDAO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import main.Main;
import model.Adresse;
import model.Commerce;
import model.Utils;

import java.util.UUID;

public class AddCommerceController {

    @FXML private TextField nomCommerceField;
    @FXML private TextField numeroField;
    @FXML private TextField nomRueField;
    @FXML private TextField codePostalField;
    @FXML private TextField villeField;
    @FXML private Label feedbackLabel;
    @FXML
    private Label infoLabel;
    @FXML
    private void handleAddCommerce() {
        // Get commerce name
        String name = nomCommerceField.getText().trim();
        // Get address details
        String numeroStr = numeroField.getText().trim();
        String nomRue = nomRueField.getText().trim();
        String codePostalStr = codePostalField.getText().trim();
        String ville = villeField.getText().trim();

        // Validate inputs
        if (name.isEmpty() || numeroStr.isEmpty() || nomRue.isEmpty() || codePostalStr.isEmpty() || ville.isEmpty()) {
            feedbackLabel.setText("All fields are required.");
            return;
        }

        try {
            // Parse numeric fields
            int numero = Integer.parseInt(numeroStr);
            int codePostal = Integer.parseInt(codePostalStr);

            // Create Adresse object
            Adresse adresse = new Adresse(numero, nomRue, codePostal, ville);

            // Save the address and get its ID using AdresseDAO
            AdresseDAO adresseDAO = new AdresseDAO(Main.conn);
            int adresseId = adresseDAO.create(adresse);
            System.out.println("Adresse ID: " + adresseId);

            if (adresseId == -1) {
                feedbackLabel.setText("Failed to create address.");
                return;
            }

            // Create Commerce object
            int idCommerce = Utils.generateRandomIntBasedOnTime();
            Commerce commerce = new Commerce(name, adresse);

            // Save the commerce with the address ID
            CommerceDAO commerceDAO = new CommerceDAO(Main.conn);
            commerceDAO.create(commerce, adresseId);
            infoLabel.setText("ContratPartenariat createdavec succès.");

            feedbackLabel.setText("Commerce and address added successfully!");

            // Navigate back to AddPartnership.fxml and refresh the commerce list
            navigateToPartnershipForm();

        } catch (NumberFormatException e) {
            feedbackLabel.setText("Numero and Postal Code must be numbers.");
        } catch (Exception e) {
            feedbackLabel.setText("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBack() {
        navigateToPartnershipForm();
    }

    private void navigateToPartnershipForm() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/AddPartnership.fxml"));
            Parent root = loader.load();
            AddPartnershipController partnershipController = loader.getController();
            partnershipController.setConnection(Main.conn); // Ensure the connection is set
            partnershipController.refreshCommerceList(); // Refresh the commerce list
            Stage stage = (Stage) nomCommerceField.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Add Partnership");
            stage.show();
        } catch (Exception e) {
            feedbackLabel.setText("Error navigating back: " + e.getMessage());
            e.printStackTrace();
        }
    }
}