package controller;

import dao.BonReductionDAO;
import dao.CommerceDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.BonReduction;
import model.Commerce;
import main.Main;

import java.io.IOException;
import java.sql.Connection;
import java.time.LocalDate;

public class AddBonReductionController {

    @FXML private TextField commerceIdField;
    @FXML private TextField valeurField;
    @FXML private CheckBox bonUtiliseCheckBox;
    @FXML private DatePicker dateExpirationPicker;
    @FXML private Button saveButton;
    @FXML private Button goBackButton;

    private Connection conn;
    private int commerceId;
    private int centreId;

    @FXML
    private void initialize() {
        // Set default expiration date to 3 months from now
        dateExpirationPicker.setValue(LocalDate.now().plusMonths(3));
    }

    public void setConnection(Connection connection) {
        this.conn = connection;
    }

    public void setCommerceId(int commerceId) {
        this.commerceId = commerceId;
        commerceIdField.setText(String.valueOf(commerceId));
    }

    public void setCentreId(int centreId) {
        this.centreId = centreId;
    }

    @FXML
    private void handleSave(ActionEvent event) {
        try {
            // Validate and parse inputs
            double valeur = Double.parseDouble(valeurField.getText());
            if (valeur <= 0) {
                showAlert(Alert.AlertType.WARNING, "Valeur Invalide", "La valeur doit être supérieure à 0.");
                return;
            }

            boolean bonUtilise = bonUtiliseCheckBox.isSelected();
            LocalDate dateExpiration = dateExpirationPicker.getValue();
            if (dateExpiration == null || dateExpiration.isBefore(LocalDate.now())) {
                showAlert(Alert.AlertType.WARNING, "Date Invalide", "La date d'expiration doit être dans le futur.");
                return;
            }

            // Fetch the Commerce object
            CommerceDAO commerceDAO = new CommerceDAO(Main.conn);
            System.out.println("Fetching Commerce with ID: " + commerceId);
            Commerce commerce = commerceDAO.find(commerceId); // Corrected method name
            if (commerce == null) {
                System.out.println("Commerce not found for ID: " + commerceId);
                showAlert(Alert.AlertType.ERROR, "Erreur", "Commerce avec ID " + commerceId + " non trouvé.");
                return;
            }
            System.out.println("Commerce found: " + commerce.getNomCommerce());

            // Create BonReduction and set the Commerce object
            BonReduction bon = new BonReduction(valeur, commerceId, bonUtilise, dateExpiration);
            bon.setCommerce(commerce); // Set the Commerce object

            // Save the BonReduction
            BonReductionDAO bonReductionDAO = new BonReductionDAO(Main.conn);
            bonReductionDAO.create(bon);

            showAlert(Alert.AlertType.INFORMATION, "Succès", "Bon de réduction ajouté avec succès.");
            handleGoBack(event); // Return to partnership page after saving
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.WARNING, "Entrée Invalide", "Veuillez entrer une valeur numérique valide.");
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Erreur lors de l'ajout du bon de réduction: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleGoBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/ContratPartenariatPage.fxml"));
            Parent root = loader.load();
            ContratPartenariatController controller = loader.getController();
            controller.setConnection(conn);
            controller.setCentreId(centreId);
            Stage stage = (Stage) goBackButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de retourner à la page des partenariats.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}