package controller;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import dao.DepotDAO;
import dao.AdresseDAO;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ResourceBundle;
import java.util.UUID;

public class DepotController implements Initializable {

    @FXML
    private ComboBox<Couleur> couleurComboBox;

    @FXML
    private ComboBox<Type> typeComboBox;

    @FXML
    private ComboBox<ResCat> resultatComboBox;

    @FXML
    private ComboBox<Adresse> adresseComboBox;

    @FXML
    private TextField poidsField;

    @FXML
    private DatePicker dateDepotPicker;

    @FXML
    private TextField heureField;

    @FXML
    private TextField minuteField;

    @FXML
    private Label messageLabel;

    @FXML
    private Button enregistrerButton;

    @FXML
    private Button retourButton;

    private Connection connection;
    private Menage menageCourant;
    private DepotDAO depotDAO;
    private AdresseDAO adresseDAO;

    public void setConnection(Connection connection) {
        this.connection = connection;
        this.depotDAO = new DepotDAO(connection);
        this.adresseDAO = new AdresseDAO(connection);
        chargerAdresses();
    }

    public void setMenage(Menage menage) {
        this.menageCourant = menage;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialiser les ComboBox
        couleurComboBox.setItems(FXCollections.observableArrayList(Couleur.values()));
        typeComboBox.setItems(FXCollections.observableArrayList(Type.values()));
        resultatComboBox.setItems(FXCollections.observableArrayList(ResCat.values()));

        // Exclure les valeurs non valides pour un nouveau dépôt
        couleurComboBox.getItems().remove(Couleur.toutCol);
        typeComboBox.getItems().remove(Type.toutType);
        resultatComboBox.getItems().remove(ResCat.total);

        // Définir les valeurs par défaut
        dateDepotPicker.setValue(LocalDate.now());

        // Initialiser les validateurs
        poidsField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                poidsField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        heureField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                heureField.setText(newValue.replaceAll("[^\\d]", ""));
            }
            if (!newValue.isEmpty() && Integer.parseInt(newValue) > 23) {
                heureField.setText("23");
            }
        });

        minuteField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                minuteField.setText(newValue.replaceAll("[^\\d]", ""));
            }
            if (!newValue.isEmpty() && Integer.parseInt(newValue) > 59) {
                minuteField.setText("59");
            }
        });
    }

    private void chargerAdresses() {
        if (adresseDAO != null) {
            adresseComboBox.setItems(FXCollections.observableArrayList(adresseDAO.findAll()));
            adresseComboBox.setConverter(new StringConverter<Adresse>() {
                @Override
                public String toString(Adresse adresse) {
                    return adresse != null ? adresse.getNomRue() + ", " + adresse.getCodeP() + " " + adresse.getVille() : "";
                }

                @Override
                public Adresse fromString(String string) {
                    return null; // Non utilisé
                }
            });
        }
    }

    @FXML
    private void handleEnregistrer(ActionEvent event) {
        if (validateFields()) {
            try {
                int poids = Integer.parseInt(poidsField.getText());
                Couleur couleur = couleurComboBox.getValue();
                Type type = typeComboBox.getValue();
                ResCat resultat = resultatComboBox.getValue();
                Adresse adresse = adresseComboBox.getValue();

                int heures = Integer.parseInt(heureField.getText());
                int minutes = Integer.parseInt(minuteField.getText());
                LocalTime horaire = LocalTime.of(heures, minutes);

                // Calcul des points (simplifié - à adapter selon vos règles)
                int points = poids * 2;

                Depot nouveauDepot = new Depot(
                       Utils.generateRandomIntBasedOnTime(),
                        poids,
                        couleur,
                        type,
                        adresse,
                        resultat,
                        points,
                        menageCourant,
                        dateDepotPicker.getValue(),
                        horaire
                );

                depotDAO.create(nouveauDepot, adresse.getId());

                // Afficher un message de confirmation
                messageLabel.setText("Dépôt enregistré avec succès!");
                messageLabel.setStyle("-fx-text-fill: green;");

                // Réinitialiser le formulaire
                resetForm();
            } catch (Exception e) {
                messageLabel.setText("Erreur lors de l'enregistrement: " + e.getMessage());
                messageLabel.setStyle("-fx-text-fill: red;");
                e.printStackTrace();
            }
        }
    }

    private boolean validateFields() {
        StringBuilder errorMessage = new StringBuilder();

        if (poidsField.getText().isEmpty()) {
            errorMessage.append("Le poids est requis.\n");
        }

        if (couleurComboBox.getValue() == null) {
            errorMessage.append("La couleur est requise.\n");
        }

        if (typeComboBox.getValue() == null) {
            errorMessage.append("Le type est requis.\n");
        }

        if (resultatComboBox.getValue() == null) {
            errorMessage.append("Le résultat est requis.\n");
        }

        if (adresseComboBox.getValue() == null) {
            errorMessage.append("L'adresse est requise.\n");
        }

        if (dateDepotPicker.getValue() == null) {
            errorMessage.append("La date est requise.\n");
        }

        if (heureField.getText().isEmpty() || minuteField.getText().isEmpty()) {
            errorMessage.append("L'heure est requise.\n");
        }

        if (errorMessage.length() > 0) {
            messageLabel.setText(errorMessage.toString());
            messageLabel.setStyle("-fx-text-fill: red;");
            return false;
        }

        return true;
    }

    private void resetForm() {
        poidsField.clear();
        couleurComboBox.setValue(null);
        typeComboBox.setValue(null);
        resultatComboBox.setValue(null);
        dateDepotPicker.setValue(LocalDate.now());
        heureField.setText("00");
        minuteField.setText("00");
    }

    @FXML
    private void handleRetour(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/menageDashboard.fxml"));
            Parent root = loader.load();

            MenageDashboardController controller = loader.getController();
            controller.setConnection(connection);
            controller.setMenage(menageCourant);
            controller.initData();

            Stage stage = (Stage) retourButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}