package dao;
import main.Main;
import model.Depot;
import model.Menage;

import java.sql.*;
import java.util.UUID;

public class DepotDAO {
    private Connection conn;

    public DepotDAO(Connection connection) {

            this.conn = (connection != null) ? connection : Main.conn;
            if (this.conn == null) {
                throw new IllegalStateException("Database connection is null. Ensure Main.conn is properly initialized.");
        }
    }
    public void create(Depot d, int adresseId) {
        String sql = "INSERT INTO Depot (iddepot, poidsDepot, couleur, typeDechet, resultat, pointsGagnes, dateDepot, heureDepot, adresse_id, menage_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, d.getIdDepot()); // <-- C'est ici la correction
            stmt.setInt(2, d.getPoidsDepot());
            //System.out.println(d.getCouleurDepot().name());
            stmt.setString(3, d.getCouleurDepot().name());
            stmt.setString(4, d.getType().name());
            stmt.setString(5, d.getCorrect().name());
            stmt.setInt(6, d.getPtsGagnes());
            stmt.setDate(7, Date.valueOf(d.getDate()));
            stmt.setTime(8, Time.valueOf(d.getHoraire()));
            stmt.setInt(9, adresseId);
            stmt.setInt(10, d.getUtilDepot().getId());
            stmt.executeUpdate();
            System.out.println("Dépôt inséré.");
            MenageDAO men=new MenageDAO(Main.conn);
            Menage menag=men.find(d.getUtilDepot().getId());
           // System.out.println("menag a mise ajour cc"+menag.toString());
           // System.out.println("cmp a mise ajour pts"+menag.getNom()+"pint nw"+(menag.getPoints()+d.getPtsGagnes()));
            men.updatePoints(menag.getNom(),(menag.getPoints()+d.getPtsGagnes()));

        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public Depot find(int idDepot) {
        String sql = "SELECT * FROM Depot WHERE idDepot = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idDepot);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Depot(rs.getInt("idDepot"), rs.getInt("poidsDepot"), null, null, null,
                	null, rs.getInt("pointsGagnes"), null, rs.getDate("dateDepot").toLocalDate(),
                	rs.getTime("heureDepot").toLocalTime()
                );
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public void deleteByMenage(String menageNomCompte) {
        String sql = "DELETE FROM Depot WHERE menage_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, menageNomCompte);
            stmt.executeUpdate();
            System.out.println("Dépôts associés au ménage supprimés.");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void delete(UUID idDepot) {
        String sql = "DELETE FROM Depot WHERE idDepot = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, idDepot.toString());  // Spécifie l'ID du Depot (UUID)
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Dépôt supprimé avec succès.");
            }
            else {
                System.out.println("Aucun Dépôt trouvé avec cet ID.");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}