package dao;

import model.Adresse;
import model.Bac;
import model.CentreTri;
import model.Couleur;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BacDAO {
    private Connection conn;

    public BacDAO(Connection conn) {
        this.conn = conn;
        try {
            // Désactiver l'auto-commit pour gérer les transactions manuellement
            conn.setAutoCommit(false);
        } catch (SQLException e) {
            System.err.println("Erreur lors de la désactivation de l'auto-commit: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Insère un nouveau bac dans la base de données.
     * @param bac Le bac à insérer
     * @param centreId L'ID du centre de tri associé
     * @param adresseId L'ID de l'adresse associée
     */
    public void create(Bac bac, int centreId, int adresseId) {
        String checkCentreSql = "SELECT idCentre FROM CentreTri WHERE idCentre = ?";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkCentreSql)) {
            checkStmt.setInt(1, centreId);
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next()) {
                throw new SQLException("Centre de tri avec id " + centreId + " n'existe pas");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Impossible de vérifier le centre_id", e);
        }

        String sql = "INSERT INTO Bac (idBac, centre_id, couleur, capacite, contenu, adresse_id, dateDerniereCollecte, prochaineCollecte) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, bac.getIdBac());
            stmt.setInt(2, centreId);
            stmt.setString(3, bac.getCouleurBac().name());
            stmt.setInt(4, bac.getCapacite());
            stmt.setInt(5, bac.getContenu());
            stmt.setInt(6, adresseId);
            stmt.setObject(7, bac.getDateDerniereCollecte() != null ? java.sql.Date.valueOf(bac.getDateDerniereCollecte()) : null);
            stmt.setObject(8, bac.getProchaineCollecte() != null ? java.sql.Date.valueOf(bac.getProchaineCollecte()) : null);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Bac ajouté avec succès (ID: " + bac.getIdBac() + ").");
                // Valider la transaction
                conn.commit();
            } else {
                System.err.println("Aucun bac inséré pour l'ID: " + bac.getIdBac());
                conn.rollback();
            }
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            throw new RuntimeException("Impossible d'insérer le bac", e);
        }
    }
    public boolean planifierCollecte(int idBac, LocalDate dateCollecte) throws SQLException {
        String sql = "UPDATE Bac SET prochaineCollecte = ? WHERE idBac = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, java.sql.Date.valueOf(dateCollecte));
            stmt.setInt(2, idBac);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }
    }
    /**
     * Recherche tous les bacs associés à un centre de tri.
     * @param centreId L'ID du centre de tri
     * @return Liste des bacs
     */
    public List<Bac> findAllByCentre(int centreId) {
        List<Bac> bacs = new ArrayList<>();
        String sql = "SELECT b.idBac, b.couleur, b.capacite, b.contenu, b.adresse_id, b.centre_id, " +
                "b.dateDerniereCollecte, b.prochaineCollecte, " +
                "a.id AS adresse_id, a.numero, a.nomRue, a.codePostal, a.ville " +
                "FROM Bac b LEFT JOIN Adresse a ON b.adresse_id = a.id WHERE b.centre_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, centreId);
            ResultSet rs = stmt.executeQuery();
            boolean found = false;
            while (rs.next()) {
                found = true;
                Adresse adresse = null;
                if (rs.getInt("adresse_id") != 0) { // Vérifier si l'adresse existe
                    adresse = new Adresse(
                            rs.getInt("adresse_id"),
                            rs.getInt("numero"),
                            rs.getString("nomRue"),
                            rs.getInt("codePostal"),
                            rs.getString("ville")
                    );
                }
                CentreTri centre = new CentreTriDAO(conn).find(rs.getInt("centre_id"));
                if (centre == null) {
                    System.out.println("Centre non trouvé pour centre_id: " + rs.getInt("centre_id"));
                    continue;
                }
                Bac bac = new Bac(
                        rs.getInt("idBac"),
                        centre,
                        Couleur.valueOf(rs.getString("couleur")),
                        rs.getInt("capacite")
                );
                bac.setContenu(rs.getInt("contenu"));
                bac.setAdresseBac(adresse);
                bac.setDateDerniereCollecte(rs.getDate("dateDerniereCollecte") != null ? rs.getDate("dateDerniereCollecte").toLocalDate() : null);
                bac.setProchaineCollecte(rs.getDate("prochaineCollecte") != null ? rs.getDate("prochaineCollecte").toLocalDate() : null);
                bacs.add(bac);
            }
            if (!found) {
                System.out.println("Aucun bac trouvé pour centreId: " + centreId);
            } else {
                System.out.println("Bacs trouvés pour centreId " + centreId + ": " + bacs.size());
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des bacs: " + e.getMessage());
            e.printStackTrace();
        }
        return bacs;
    }

    /**
     * Met à jour un bac dans la base de données.
     * @param bac Le bac à mettre à jour
     * @param adresseId L'ID de l'adresse associée
     */
    public boolean update(Bac bac, int adresseId) {
        String sql = "UPDATE Bac SET couleur = ?, capacite = ?, contenu = ?, adresse_id = ?, dateDerniereCollecte = ?, prochaineCollecte = ? WHERE idBac = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, bac.getCouleurBac().name());
            stmt.setInt(2, bac.getCapacite());
            stmt.setInt(3, bac.getContenu());
            stmt.setInt(4, adresseId);
            stmt.setObject(5, bac.getDateDerniereCollecte() != null ? java.sql.Date.valueOf(bac.getDateDerniereCollecte()) : null);
            stmt.setObject(6, bac.getProchaineCollecte() != null ? java.sql.Date.valueOf(bac.getProchaineCollecte()) : null);
            stmt.setInt(7, bac.getIdBac()); // Utiliser setInt pour un entier
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Bac mis à jour avec succès (ID: " + bac.getIdBac() + ")");
                conn.commit();
                return true;
            } else {
                System.err.println("Aucun bac mis à jour pour l'ID: " + bac.getIdBac());
                conn.rollback();
                return false;
            }
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Erreur lors de la mise à jour du bac: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public List<Bac> findBacsForSoonCollection(int centreId) {
        List<Bac> bacs = new ArrayList<>();
        String sql = "SELECT b.idBac, b.couleur, b.capacite, b.contenu, b.adresse_id, b.centre_id, " +
                "b.dateDerniereCollecte, b.prochaineCollecte, " +
                "a.id AS adresse_id, a.numero, a.nomRue, a.codePostal, a.ville " +
                "FROM Bac b LEFT JOIN Adresse a ON b.adresse_id = a.id " +
                "WHERE b.centre_id = ? AND (b.contenu >= b.capacite * 0.5 OR b.prochaineCollecte IS NOT NULL)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, centreId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Adresse adresse = null;
                if (rs.getInt("adresse_id") != 0) {
                    adresse = new Adresse(
                            rs.getInt("adresse_id"),
                            rs.getInt("numero"),
                            rs.getString("nomRue"),
                            rs.getInt("codePostal"),
                            rs.getString("ville")
                    );
                }
                CentreTri centre = new CentreTriDAO(conn).find(rs.getInt("centre_id"));
                if (centre == null) {
                    System.out.println("Centre non trouvé pour centre_id: " + rs.getInt("centre_id"));
                    continue;
                }
                Bac bac = new Bac(
                        rs.getInt("idBac"),
                        centre,
                        Couleur.valueOf(rs.getString("couleur")),
                        rs.getInt("capacite")
                );
                bac.setContenu(rs.getInt("contenu"));
                bac.setAdresseBac(adresse);
                bac.setDateDerniereCollecte(rs.getDate("dateDerniereCollecte") != null ? rs.getDate("dateDerniereCollecte").toLocalDate() : null);
                bac.setProchaineCollecte(rs.getDate("prochaineCollecte") != null ? rs.getDate("prochaineCollecte").toLocalDate() : null);
                bacs.add(bac);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des bacs à collecter: " + e.getMessage());
            e.printStackTrace();
        }
        return bacs;
    }

    public List<Bac> findBacsFiltered(int centreId, Couleur couleurFiltre, double seuilRemplissage) {
        List<Bac> bacs = new ArrayList<>();
        String sql = "SELECT b.idBac, b.couleur, b.capacite, b.contenu, b.adresse_id, b.centre_id, " +
                "b.dateDerniereCollecte, b.prochaineCollecte, " +
                "a.id AS adresse_id, a.numero, a.nomRue, a.codePostal, a.ville " +
                "FROM Bac b LEFT JOIN Adresse a ON b.adresse_id = a.id " +
                "WHERE b.centre_id = ? " +
                (couleurFiltre != null ? "AND b.couleur = ? " : "") +
                "AND (b.contenu >= b.capacite * ? OR b.prochaineCollecte IS NOT NULL)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, centreId);
            int paramIndex = 2;
            if (couleurFiltre != null) {
                stmt.setString(paramIndex++, couleurFiltre.name());
            }
            stmt.setDouble(paramIndex, seuilRemplissage);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Adresse adresse = null;
                if (rs.getInt("adresse_id") != 0) {
                    adresse = new Adresse(
                            rs.getInt("adresse_id"),
                            rs.getInt("numero"),
                            rs.getString("nomRue"),
                            rs.getInt("codePostal"),
                            rs.getString("ville")
                    );
                }
                CentreTri centre = new CentreTriDAO(conn).find(rs.getInt("centre_id"));
                if (centre == null) {
                    System.out.println("Centre non trouvé pour centre_id: " + rs.getInt("centre_id"));
                    continue;
                }
                Bac bac = new Bac(
                        rs.getInt("idBac"),
                        centre,
                        Couleur.valueOf(rs.getString("couleur")),
                        rs.getInt("capacite")
                );
                bac.setContenu(rs.getInt("contenu"));
                bac.setAdresseBac(adresse);
                bac.setDateDerniereCollecte(rs.getDate("dateDerniereCollecte") != null ? rs.getDate("dateDerniereCollecte").toLocalDate() : null);
                bac.setProchaineCollecte(rs.getDate("prochaineCollecte") != null ? rs.getDate("prochaineCollecte").toLocalDate() : null);
                bacs.add(bac);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des bacs filtrés: " + e.getMessage());
            e.printStackTrace();
        }
        return bacs;
    }

    public boolean collecterBac(int idBac) {
        String sql = "UPDATE Bac SET contenu = 0, dateDerniereCollecte = ?, prochaineCollecte = NULL WHERE idBac = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
            stmt.setInt(2, idBac); // Utiliser setInt pour un entier
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                conn.commit();
                return true;
            } else {
                conn.rollback();
                return false;
            }
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Erreur lors de la collecte du bac: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Supprime un bac de la base de données.
     * @param idBac L'ID du bac à supprimer
     */
    public void delete(int idBac) {
        String sql = "DELETE FROM Bac WHERE idBac = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idBac); // Utiliser setInt pour un entier
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Bac supprimé avec succès (ID: " + idBac + ").");
                conn.commit();
            } else {
                System.out.println("Aucun bac trouvé avec l'ID: " + idBac);
                conn.rollback();
            }
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Erreur lors de la suppression du bac: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Met à jour l'adresse d'un bac dans la base de données.
     * @param idBac L'ID du bac à déplacer
     * @param adresseId L'ID de la nouvelle adresse
     * @return true si la mise à jour est réussie, false sinon
     */
    public boolean updateAdresse(int idBac, int adresseId) {
        String sql = "UPDATE Bac SET adresse_id = ? WHERE idBac = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, adresseId);
            stmt.setInt(2, idBac); // Utiliser setInt pour un entier
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                conn.commit();
                return true;
            } else {
                conn.rollback();
                return false;
            }
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException rollbackEx) {
                System.err.println("Erreur lors du rollback: " + rollbackEx.getMessage());
            }
            System.err.println("Erreur lors de la mise à jour de l'adresse du bac: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}