package dao;

import main.Main;
import model.BonReduction;
import model.Commerce;
import model.Menage;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static java.sql.Types.NULL;

public class BonReductionDAO {
    private Connection conn;
    private CommerceDAO commerceDAO;

    public BonReductionDAO(Connection conn) {
        this.conn = conn;
        this.commerceDAO = new CommerceDAO(conn);
    }

    public void create(BonReduction bon) {
        //System.out.println("Creating BonReduction: " + bon);
        String sql = "INSERT INTO bonreduction (valeur, bonutilise, commerce_id, dateexpiration) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setDouble(1, bon.getValeur());
            stmt.setBoolean(2, bon.getBonUtilise());

            Commerce commerce = bon.getCommerce();
            if (commerce == null) {
                throw new IllegalStateException("Commerce is null in BonReduction");
            }
            stmt.setInt(3, commerce.getIdCommerce());

            //Menage menage = bon.getMenageBon();

                //stmt.setNull(4, Types.INTEGER); // Set menage_id to NULL if menageBon is null


            stmt.setDate(4, java.sql.Date.valueOf(bon.getDateExp()));
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int generatedId = rs.getInt(1);
                bon.setIdBon(generatedId);
                commerce.getMapBons().put(generatedId, bon);
                System.out.println("Bon de réduction ajouté avec ID: " + generatedId);
            } else {
                throw new SQLException("Failed to retrieve generated idBon for BonReduction");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert BonReduction into database: " + e.getMessage(), e);
        }
    }

    public List<BonReduction> findByCommerce(int idCommerce) {
        System.out.println("findByCommerce: Starting for commerce ID: " + idCommerce);
        List<BonReduction> bons = new ArrayList<>();
        String sql = "SELECT br.*, c.idcommerce AS commerce_id, c.nomcommerce " +
                "FROM bonreduction br " +
                "INNER JOIN commerce c ON br.commerce_id = c.idcommerce " +
                "WHERE br.commerce_id = ? AND br.menage_id IS NULL " +
                "AND br.bonutilise = FALSE AND br.dateexpiration >= CURRENT_DATE";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCommerce);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    System.out.println("findByCommerce: Processing BonReduction...");
                    int bonId = rs.getInt("idbon");
                    int idcommerce = rs.getInt("commerce_id");
                    double valeur = rs.getDouble("valeur");
                    LocalDate dateExp = rs.getDate("dateexpiration").toLocalDate();
                    boolean bonUtilise = rs.getBoolean("bonutilise");
                    BonReduction bon = new BonReduction(valeur, idcommerce, bonUtilise, dateExp);
                    bon.setIdBon(bonId);

                    Commerce commerce = new Commerce();
                    commerce.setIdCommerce(idCommerce);
                    commerce.setNomCommerce(rs.getString("nomcommerce"));
                    bon.setCommerce(commerce);

                    bons.add(bon);
                    //System.out.println("findByCommerce: Added to bons: " + bons);
                }
            }
        } catch (SQLException e) {
            System.err.println("findByCommerce: SQLException: " + e.getMessage());
            throw new RuntimeException("Error retrieving BonReductions for commerce " + idCommerce + ": " + e.getMessage(), e);
        }
        System.out.println("findByCommerce: Returning bons with size: " + bons.size());
        return bons;
    }

    public List<BonReduction> findByMenage(int menageId) {
        List<BonReduction> bons = new ArrayList<>();
        String sql = "SELECT * FROM bonreduction WHERE menage_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, menageId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idBon = rs.getInt("idbon");
                double valeur = rs.getDouble("valeur");
                boolean bonUtilise = rs.getBoolean("bonutilise");
                int commerceId = rs.getInt("commerce_id");
                LocalDate dateExp = rs.getDate("dateexpiration").toLocalDate();
                Commerce commerce = commerceDAO.find(commerceId);
                if (commerce == null) {
                    throw new IllegalStateException("Commerce with ID " + commerceId + " not found");
                }
                BonReduction bon = new BonReduction(valeur, commerceId, bonUtilise, dateExp);
                bon.setIdBon(idBon);
                bon.setCommerce(commerce);
                bons.add(bon);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch BonReduction by menage: " + e.getMessage(), e);
        }
        return bons;
    }

    public void updateMenageId(int bonId, int menageId) {
        String sql = "UPDATE bonreduction SET menage_id = ? WHERE idbon = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, menageId);
            stmt.setInt(2, bonId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No BonReduction found with idbon: " + bonId);
            }
            System.out.println("Updated menage_id for BonReduction idbon=" + bonId + " to menage_id=" + menageId);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update menage_id for BonReduction: " + e.getMessage(), e);
        }
    }

    public void updateBonUtilise(int bonId, boolean bonUtilise) {
        String sql = "UPDATE bonreduction SET bonutilise = ? WHERE idbon = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setBoolean(1, bonUtilise);
            stmt.setInt(2, bonId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No BonReduction found with idbon: " + bonId);
            }
            System.out.println("Updated bonutilise for BonReduction idbon=" + bonId + " to " + bonUtilise);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update bonutilise for BonReduction: " + e.getMessage(), e);
        }
    }
}