package main;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;


public class Main extends Application {
    public static Connection conn;

    @Override
    public void start(Stage primaryStage) throws Exception {
        String url = "jdbc:mysql://localhost:3306/tri_selectifv3";
        String user = "root";
        String password = "";

        try {
            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connexion réussie !");
        } catch (Exception e) {
            e.printStackTrace();
            return; // On arrête si la connexion échoue
        }

        // Charger l'interface FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/MainConnection.fxml"));
        Parent root = loader.load();

        // Set the title and scene with a custom size
        primaryStage.setTitle("Connexion - Tri Sélectif");
        primaryStage.setScene(new Scene(root, 400, 500));
        primaryStage.show();
    }

    @Override
    public void stop() throws Exception {
        // Close the database connection when the application stops
        if (conn != null && !conn.isClosed()) {
            conn.close();
            System.out.println("Connexion  fermée.");
        }
        super.stop();
    }

    public static void main(String[] args) {
        launch(args);
    }
}