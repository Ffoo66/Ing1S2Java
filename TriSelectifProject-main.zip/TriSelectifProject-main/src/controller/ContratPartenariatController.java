package controller;

import dao.BonReductionDAO;
import dao.ContratPartenariatDAO;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import main.Main;
import model.BonReduction;
import model.Commerce;
import model.ContratPartenariat;
import model.Menage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import javafx.stage.Stage;

public class ContratPartenariatController {

    @FXML private TableView<ContratPartenariat> partnershipTable;
    @FXML private TableColumn<ContratPartenariat, String> centreColumn;
    @FXML private TableColumn<ContratPartenariat, String> commerceColumn;
    @FXML private TableColumn<ContratPartenariat, LocalDate> dateDebutColumn;
    @FXML private TableColumn<ContratPartenariat, LocalDate> dateFinColumn;
    @FXML private Button removePartnershipButton;
    @FXML private Button addBonReductionButton;
    @FXML private Button addPartnershipButton;
    @FXML private Button goBackButton;

    private ContratPartenariatDAO contratDAO;
    private BonReductionDAO bonReductionDAO;
    private Menage currentUser;
    private int centreId;
    private String centreName;

    @FXML
    private void initialize() {
        // Initialize DAO
        contratDAO = new ContratPartenariatDAO(Main.conn);
        bonReductionDAO = new BonReductionDAO(Main.conn);
        System.out.println(centreColumn.getColumns());

        // Set up table columns
        centreColumn.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getNomCentrePartner());
        });
        commerceColumn.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getNomCommerce());
        });
        dateDebutColumn.setCellValueFactory(new PropertyValueFactory<>("dateDP"));
        dateFinColumn.setCellValueFactory(new PropertyValueFactory<>("dateFP"));

        // Load partnerships
        loadPartnerships();
    }

    public void setConnection(Connection connection) {
        if (connection == null) {
            throw new IllegalStateException("Database connection is null");
        }
        contratDAO = new ContratPartenariatDAO(connection);
        bonReductionDAO = new BonReductionDAO(connection);
        loadPartnerships();
    }

    public void setCurrentUser(Menage menage) {
        this.currentUser = menage;
    }

    public void setCentreId(int centreId) {
        this.centreId = centreId;
        loadPartnerships();
    }

    public void setCentreName(String centreName) {
        this.centreName = centreName;
    }

    private void loadPartnerships() {
        ObservableList<ContratPartenariat> partnerships = FXCollections.observableArrayList();
        // do not change this check to >0
        if (centreId ==0) {
            partnerships.addAll(contratDAO.find(centreId));
        } else {
            partnerships.addAll(contratDAO.findAll());
        }
        partnershipTable.setItems(partnerships);
        partnershipTable.refresh();
    }

    @FXML
    private void handleAddPartnership(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/AddPartnership.fxml"));
            Parent root = loader.load();
            AddPartnershipController controller = loader.getController();
            controller.setConnection(Main.conn);
           // controller.setCentreId(centreId);
            Stage stage = (Stage) partnershipTable.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger la page d'ajout de partenariat.");
        }
    }

    @FXML
    private void handleRemovePartnership(ActionEvent event) {
        ContratPartenariat selected = partnershipTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un partenariat à supprimer.");
            return;
        }
        contratDAO.delete(selected.getIdCommerceP(), selected.getIdCentreP());
        loadPartnerships();
        showAlert(Alert.AlertType.INFORMATION, "Succès", "Partenariat supprimé.");
    }
///-------/////
//    @FXML
//    private void handleAddBonReduction(ActionEvent event) throws SQLException {
//        ContratPartenariat selected = partnershipTable.getSelectionModel().getSelectedItem();
//        if (selected == null) {
//            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un partenariat pour ajouter un bon.");
//            return;
//        }
//        Commerce commerce = selected.getCommercePartner();
//        //	 BonReduction( double val,int idCommerce, boolean bnUtil, LocalDate nDateExp) {
//        BonReduction bon = new BonReduction(val,idcomm,isutil,null , LocalDate.now().plusMonths(3));
//        bonReductionDAO.create(bon);
//        //showAlert(Alert.AlertType.INFORMATION, "Succès", "Bon de réduction ajouté pour " + commerce.getNomCommerce() + ".");
//    }
@FXML
private void handleAddBonReduction(ActionEvent event) {
    ContratPartenariat selected = partnershipTable.getSelectionModel().getSelectedItem();
    if (selected == null) {
        showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un partenariat pour ajouter un bon.");
        return;
    }
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/AddBonReductionPage.fxml"));
        Parent root = loader.load();
        AddBonReductionController controller = loader.getController();
        controller.setConnection(Main.conn);
        controller.setCommerceId(selected.getIdCommerceP());
        Stage stage = (Stage) partnershipTable.getScene().getWindow();
        stage.setScene(new Scene(root));
    } catch (IOException e) {
        e.printStackTrace();
        showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de charger la page d'ajout de bon de réduction.");
    }
}
    @FXML

    private void handleGoBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/partnerShipDashbaord.fxml"));
            Parent root = loader.load();

            // Fix: Use the correct controller for the partnership dashboard
            ContratPartenariatController controller = loader.getController();
            controller.setConnection(Main.conn);

            Stage stage = (Stage) partnershipTable.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de retourner à la page précédente.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}