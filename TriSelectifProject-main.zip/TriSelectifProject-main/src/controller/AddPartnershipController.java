package controller;

import dao.AdresseDAO;
import dao.CommerceDAO;
import dao.ContratPartenariatDAO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import main.Main;
import model.Adresse;
import model.Commerce;
import model.ContratPartenariat;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.sql.Connection;
import java.sql.SQLException;

public class AddPartnershipController {
    @FXML
    private ComboBox<Adresse> adresseCombo;

    @FXML
    private ComboBox<Commerce> commerceCombo;

    public void setCentreId(TextField centreIdField) {
        this.centreIdField = centreIdField;
    }

    @FXML
    private TextField centreIdField; // For entering the CentreTri ID

    @FXML
    private CheckBox estPartenaireCheckBox; // For setting estPartenaire (true/false)

    @FXML
    private DatePicker dateDebutPicker; // For selecting the start date

    @FXML
    private DatePicker dateFinPicker; // For selecting the end date

    @FXML
    private Label feedbackLabel; // For displaying success/error messages

    private Connection connection;
    private CommerceDAO commerceDAO;
    private ContratPartenariatDAO contratPartenariatDAO;

    // Initialize the controller with a database connection
    public void setConnection(Connection connection) {
        this.connection = connection;
        this.commerceDAO = new CommerceDAO(connection);
        this.contratPartenariatDAO = new ContratPartenariatDAO(Main.conn);
    }

    @FXML
    private void initialize() {
        // Load all addresses and commerces into ComboBoxes
        AdresseDAO adresseDAO = new AdresseDAO(Main.conn);
        List<Adresse> adresses = adresseDAO.findAll();
        adresseCombo.getItems().addAll(adresses);

        // Set a custom cell factory to display address details
        adresseCombo.setCellFactory(param -> new ListCell<Adresse>() {
            @Override
            protected void updateItem(Adresse item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null && !empty) {
                    setText(item.toString()); // Assuming toString() returns a nice representation
                } else {
                    setText(null);
                }
            }
        });

        // Display the selected Adresse nicely
        adresseCombo.setButtonCell(new ListCell<Adresse>() {
            @Override
            protected void updateItem(Adresse item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null && !empty) {
                    setText(item.toString()); // Display the selected address in the ComboBox button
                } else {
                    setText(null);
                }
            }
        });

        // Load all commerces into the commerce ComboBox
        CommerceDAO commerceDAO = new CommerceDAO(Main.conn);
        //System.out.println("com dao"+commerceDAO);
        this.commerceDAO=commerceDAO;
        List<Commerce> commerces = commerceDAO.findAll();
        System.out.println(commerces);
        commerceCombo.getItems().addAll(commerces);

        // Set a custom cell factory to display commerce details
        commerceCombo.setCellFactory(param -> new ListCell<Commerce>() {
            @Override
            protected void updateItem(Commerce item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null && !empty) {
                    setText(item.getNomCommerce()); // Assuming Commerce has a getNom() method
                } else {
                    setText(null);
                }
            }
        });

        // Display the selected Commerce nicely
        commerceCombo.setButtonCell(new ListCell<Commerce>() {
            @Override
            protected void updateItem(Commerce item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null && !empty) {
                    setText(item.getNomCommerce()); // Display the selected commerce in the ComboBox button
                } else {
                    setText(null);
                }
            }
        });

        // Set default values for date pickers
        dateDebutPicker.setValue(LocalDate.now());
        dateFinPicker.setValue(LocalDate.now().plusMonths(6)); // Default to 6 months duration
        feedbackLabel.setText("");
    }

    @FXML
    private void handleCommerceSelected() {
        Commerce selectedCommerce = commerceCombo.getSelectionModel().getSelectedItem();
        if (selectedCommerce != null) {
            // Load addresses for the selected commerce
            AdresseDAO adresseDAO = new AdresseDAO(Main.conn);
            List<Adresse> addresses = adresseDAO.findAll();
            adresseCombo.getItems().clear(); // Clear previous items
            adresseCombo.getItems().addAll(addresses); // Add new addresses
        }
    }

    @FXML
    private void handleAddPartnership() {
        try {
            // Validate and parse inputs
            Commerce selectedCommerce = commerceCombo.getSelectionModel().getSelectedItem();
            if (selectedCommerce == null) {
                feedbackLabel.setText("Please select a commerce.");
                return;
            }
            int commerceId = selectedCommerce.getIdCommerce(); // Assuming Commerce has a getId() method that returns UUID

            int centreId;
            try {
                centreId = Integer.parseInt(centreIdField.getText().trim());
            } catch (NumberFormatException e) {
                feedbackLabel.setText("Centre ID must be a valid integer.");
                return;
            }
            boolean estPartenaire = estPartenaireCheckBox.isSelected();
            LocalDate dateDebut = dateDebutPicker.getValue();
            LocalDate dateFin = dateFinPicker.getValue();

            // Input validation
            if (dateDebut == null || dateFin == null) {
                feedbackLabel.setText("Please select both start and end dates.");
                return;
            }

            if (dateFin.isBefore(dateDebut)) {
                feedbackLabel.setText("End date cannot be before start date.");
                return;
            }

            // Verify that the Commerce exists
            Commerce commerce = commerceDAO.find(commerceId);
            if (commerce == null) {
                feedbackLabel.setText("Commerce with ID " + commerceId + " not found.");
                return;
            }

            // Check if a partnership already exists (to avoid primary key violation)
            ContratPartenariat existingContrat = contratPartenariatDAO.find(commerceId, centreId);
            if (existingContrat != null) {
                feedbackLabel.setText("A partnership already exists between Commerce " + commerceId + " and Centre " + centreId + ".");
                return;
            }

            // Create the ContratPartenariat object
            ContratPartenariat contrat = new ContratPartenariat(centreId, commerceId, estPartenaire, dateDebut, dateFin);

            // Save the partnership using ContratPartenariatDAO
            contratPartenariatDAO.create(contrat);

            // Provide feedback
            feedbackLabel.setText("Partnership added successfully!");
            feedbackLabel.setStyle("-fx-text-fill: green;");

            // Clear the form
            clearForm();


        } catch (IllegalArgumentException e) {
            feedbackLabel.setText("Invalid input: " + e.getMessage());
            feedbackLabel.setStyle("-fx-text-fill: red;");
        } catch (Exception e) {
            String message = "Error adding partnership: " + e.getMessage();
            if (e.getCause() instanceof SQLException) {
                SQLException sqlEx = (SQLException) e.getCause();
                if (sqlEx.getSQLState().startsWith("23")) { // Constraint violation (e.g., primary key)
                    message = "A partnership already exists with these IDs.";
                }
            }
            feedbackLabel.setText(message);
            feedbackLabel.setStyle("-fx-text-fill: red;");
            e.printStackTrace();
        }
    }
    private void loadCommerceList() {
        CommerceDAO commerceDAO = new CommerceDAO(Main.conn);
        List<Commerce> commerces = commerceDAO.findAll();
        commerceCombo.getItems().setAll(commerces);

        commerceCombo.setCellFactory(param -> new ListCell<Commerce>() {
            @Override
            protected void updateItem(Commerce item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null && !empty) {
                    setText(item.getNomCommerce());
                } else {
                    setText(null);
                }
            }
        });

        commerceCombo.setButtonCell(new ListCell<Commerce>() {
            @Override
            protected void updateItem(Commerce item, boolean empty) {
                super.updateItem(item, empty);
                if (item != null && !empty) {
                    setText(item.getNomCommerce());
                } else {
                    setText(null);
                }
            }
        });
    }
    public void refreshCommerceList() {
        loadCommerceList();
    }


    @FXML
    private void handleCreateCommerce() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/AddCommerce.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) feedbackLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Create Commerce");
            stage.show();
        } catch (Exception e) {
            System.err.println("Error loading AddCommerce.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleCancel() {
        Stage stage = (Stage) feedbackLabel.getScene().getWindow();
        stage.close();
    }

    private void clearForm() {
        commerceCombo.getSelectionModel().clearSelection();
        centreIdField.clear();
        estPartenaireCheckBox.setSelected(false);
        dateDebutPicker.setValue(LocalDate.now());
        dateFinPicker.setValue(LocalDate.now().plusMonths(6));
        feedbackLabel.setText("");
        feedbackLabel.setStyle(""); // Reset style
    }
}