package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import main.Main;
import model.CentreTri;
import model.Menage;
import model.Depot;
import model.BonReduction;

public class MenageDashboardController {

    @FXML
    private Text userNameText;
    @FXML
    private Button logoutButton;
    @FXML
    private Label pointsLabel;

    @FXML
    private Text totalDepotsText;

    @FXML
    private Text totalPointsText;

    @FXML
    private Text availableVouchersText;

    @FXML
    private Text lastDepositText;

    @FXML
    private PieChart depositsPieChart;

    private Menage currentUser;
    private Connection connection;

    @FXML
    private void initialize() {
        // Initialize will be called before user data is loaded
    }
    @FXML
    public void handleLogout() {
        try {
            // Clear user state
            //Menage.clearCurrentUser(); // Assuming Menage has a static method to clear the current user
            this.currentUser = null;   // Clear the local reference
            System.out.println("MenageDashboardController: Déconnexion - user state cleared");

            // Load the login page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/MainConnection.fxml"));
            Parent loginPage = loader.load();

            // Get the current stage and set the new scene
            Scene scene = new Scene(loginPage);
            scene.getStylesheets().add(getClass().getResource("/view/css/connection.css").toExternalForm());
            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Connexion - Tri Sélectif");
            stage.show();

            System.out.println("MenageDashboardController: Redirection vers la page de connexion réussie");
        } catch (IOException e) {
            // Assuming you have a showErrorMessage method like in other controllers
            //showErrorMessage("Erreur lors de la déconnexion: " + e.getMessage());
            System.err.println("MenageDashboardController: Erreur lors de la déconnexion - " + e.getMessage());
            e.printStackTrace();
        }
    }
    // Méthode ajoutée pour définir la connexion à la base de données
    public void setConnection(Connection connection) {
        this.connection = (connection != null) ? connection : Main.conn;
        if (this.connection == null) {
            throw new IllegalStateException("Database connection is null. Ensure Main.conn is properly initialized.");
        }
    }

    // Méthode ajoutée pour définir le ménage courant (alternative à initData)
    public void setMenage(Menage menage) {
        this.currentUser = menage;
    }

    public void initData(Menage menage) {
        this.currentUser = menage;
    System.out.println("menage"+currentUser.getPoints());

        // Set user information
        userNameText.setText(currentUser.getNom());
        pointsLabel.setText(String.valueOf(currentUser.getPoints()));

        // Calculate statistics
        updateStatistics();

        // Create pie chart for deposit types
        createDepositsPieChart();
    }

    // Nouvelle méthode pour initialiser sans passer de ménage (utilise celui déjà défini)
    public void initData() {
        if (currentUser != null) {
            // Set user information
            userNameText.setText(currentUser.getNom());
            pointsLabel.setText(String.valueOf(currentUser.getPoints()));

            // Calculate statistics
            updateStatistics();

            // Create pie chart for deposit types
            createDepositsPieChart();
        }
    }

    private void updateStatistics() {
        HashMap<Integer, Depot> depots = currentUser.getHistorique();
        HashMap<Integer, BonReduction> bons = currentUser.getMapBons();

        // Total deposits
        totalDepotsText.setText(String.valueOf(depots.size()));
        System.out.println("nb depot"+String.valueOf(depots.size()));

        // Total accumulated points (consider points history, not just current balance)
        int totalPointsAccumulated = 0;
        Depot mostRecentDepot = null;

        for (Depot depot : depots.values()) {
            totalPointsAccumulated += depot.getPtsGagnes();

            // Track most recent deposit for last deposit info
            if (mostRecentDepot == null ||
                    depot.getDate().isAfter(mostRecentDepot.getDate())) {
                mostRecentDepot = depot;
            }
        }

        //totalPointsText.setText(String.valueOf(totalPointsAccumulated));

        // Available vouchers (not used, not expired)
        int availableVouchers = 0;
        for (BonReduction bon : bons.values()) {
            if (!bon.getBonUtilise() && !bon.getDateExp().isBefore(java.time.LocalDate.now())) {
                availableVouchers++;
            }
        }

        availableVouchersText.setText(String.valueOf(availableVouchers));

        // Last deposit info
        if (mostRecentDepot != null) {
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            lastDepositText.setText(mostRecentDepot.getDate().format(dateFormatter));
        } else {
            lastDepositText.setText("Aucun");
        }
    }

    private void createDepositsPieChart() {
        HashMap<Integer, Depot> depots = currentUser.getHistorique();

        // Count deposits by type
        Map<String, Integer> depositsByType = new HashMap<>();

        for (Depot depot : depots.values()) {
            String typeName = depot.getType().name();
            depositsByType.put(typeName, depositsByType.getOrDefault(typeName, 0) + 1);
        }

        // Create pie chart data
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
        for (Map.Entry<String, Integer> entry : depositsByType.entrySet()) {
            pieChartData.add(new PieChart.Data(entry.getKey() + " (" + entry.getValue() + ")", entry.getValue()));
        }

        // If no data, add a placeholder
        if (pieChartData.isEmpty()) {
            pieChartData.add(new PieChart.Data("Aucun dépôt", 1));
        }

        depositsPieChart.setData(pieChartData);
        depositsPieChart.setTitle("Répartition par type de déchet");
    }

    @FXML
    private void handleProfileAction(ActionEvent event) {
        // Implement profile view
        // For now, just show a placeholder
    }

    @FXML
    private void handleLogoutAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/MainConnection.fxml"));
            Parent root = loader.load();

            // Reset current user to null
            //LoginController.currentUser = null;

            Stage stage = (Stage) userNameText.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/view/css/connection.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Connexion - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleDashboardAction(ActionEvent event) {
        // Already on dashboard, no action needed
    }

    @FXML
    private void handleHistoryAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/History.fxml"));
            Parent root = loader.load();

            HistoryController controller = loader.getController();
            controller.initData(currentUser);

            Stage stage = (Stage) userNameText.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/view/pages/menageDashboard.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Historique des dépôts - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleExchangeAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/echangePoint.fxml"));
            Parent root = loader.load();

            ExchangeController controller = loader.getController();
            // controller.initData(currentUser);
            controller.setMenage(currentUser);
            controller.setConnection(Main.conn);

            Stage stage = (Stage) userNameText.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/view/css/menageDashboard.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Échanger des points - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleVouchersAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/BonDachat.fxml"));
            Parent root = loader.load();

            BonDachatController controller = loader.getController();

            //controller.initData(currentUser);

            Stage stage = (Stage) userNameText.getScene().getWindow();
            Scene scene = new Scene(root);
           // scene.getStylesheets().add(getClass().getResource("/view/css/menageDashboard.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Mes bons de réduction - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleNewDepositAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/depotForm.fxml"));
            Parent root = loader.load();

            DepotController controller = loader.getController();
            controller.setConnection(connection);
            controller.setMenage(currentUser);

            Stage stage = (Stage) userNameText.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/view/css/depotForm.css").toExternalForm());

            stage.setScene(scene);
            stage.setTitle("Nouveau dépôt - Tri Sélectif");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAboutAction(ActionEvent event) {
        // Implement about dialog
        // For now just a placeholder
    }
}