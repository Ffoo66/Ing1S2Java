package controller;

import dao.BacDAO;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.util.Callback;
import model.Bac;
import model.Couleur;
import main.Main;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class CollecteController implements Initializable {

    @FXML private Label titleLabel;
    @FXML private Label statusLabel;
    @FXML private Label totalBacsLabel;
    @FXML private Label remplissageMoyenLabel;
    @FXML private Label collectesPlanifieesLabel;
    @FXML private Label miseAJourLabel;
    @FXML private Label versionLabel;

    @FXML private TableView<Bac> collecteTableView;
    @FXML private TableColumn<Bac, String> idBacColumn;
    @FXML private TableColumn<Bac, String> couleurColumn;
    @FXML private TableColumn<Bac, String> adresseColumn;
    @FXML private TableColumn<Bac, Integer> niveauRemplissageColumn;
    @FXML private TableColumn<Bac, String> dateDerniereCollecteColumn;
    @FXML private TableColumn<Bac, String> prochaineCollecteColumn;
    @FXML private TableColumn<Bac, String> statutColumn;
    @FXML private TableColumn<Bac, Void> actionsColumn;

    @FXML private Button retourButton;
    @FXML private Button actualiserButton;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> filterTypeComboBox;
    @FXML private ComboBox<String> filterStatusComboBox;

    private BacDAO bacDAO;
    private int centreId;
    private String centreName;
    private ObservableList<Bac> bacsData = FXCollections.observableArrayList();
    private ObservableList<Bac> allBacs = FXCollections.observableArrayList();
    private FilteredList<Bac> filteredBacs;
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

    // Mapper pour les couleurs des bacs
    private final Map<Couleur, String> couleurStyleClasses = new HashMap<>();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            bacDAO = new BacDAO(Main.conn);

            // Initialiser la map des styles de couleurs
            couleurStyleClasses.put(Couleur.vert, "bac-vert");
            couleurStyleClasses.put(Couleur.jaune, "bac-jaune");
            couleurStyleClasses.put(Couleur.bleu, "bac-bleu");
            couleurStyleClasses.put(Couleur.toutCol, "bac-marron");

            // Activer la sélection multiple
            collecteTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

            // Configuration des colonnes de la table
            setupTableColumns();

            // Initialiser les filtres
            setupFilters();

            // Mettre à jour les statistiques
            updateStats();

            // Configurer l'heure de mise à jour
            updateLastRefreshTime();

        } catch (Exception e) {
            System.err.println("Erreur d'initialisation: " + e.getMessage());
            e.printStackTrace();
            if (statusLabel != null) {
                statusLabel.setText("Erreur lors de l'initialisation");
            }
        }
    }

    private void setupTableColumns() {
        idBacColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(String.valueOf(cellData.getValue().getIdBac())));

        // Cellule personnalisée pour la couleur du bac
        couleurColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(cellData.getValue().getCouleurBac().name()));
        couleurColumn.setCellFactory(column -> new TableCell<Bac, String>() {
            @Override
            protected void updateItem(String couleur, boolean empty) {
                super.updateItem(couleur, empty);
                if (empty || couleur == null) {
                    setText(null);
                    setGraphic(null);
                    getStyleClass().removeAll("bac-vert", "bac-jaune", "bac-bleu", "bac-marron");
                } else {
                    setText(couleur);
                    getStyleClass().removeAll("bac-vert", "bac-jaune", "bac-bleu", "bac-marron");
                    try {
                        Couleur bacCouleur = Couleur.valueOf(couleur);
                        getStyleClass().add(couleurStyleClasses.get(bacCouleur));
                    } catch (Exception e) {
                        // En cas d'erreur, ne pas appliquer de style
                    }
                }
            }
        });

        adresseColumn.setCellValueFactory(cellData -> cellData.getValue().getAdresseCompleteProperty());

        // Cellule personnalisée pour le pourcentage de remplissage (sans texte)
        niveauRemplissageColumn.setCellValueFactory(cellData -> {
            int pourcentage = (int) (cellData.getValue().getPourcentageRemplissage() * 100);
            return javafx.beans.binding.Bindings.createObjectBinding(() -> pourcentage);
        });
        niveauRemplissageColumn.setCellFactory(column -> new TableCell<Bac, Integer>() {
            private final ProgressBar progressBar = new ProgressBar();
            private final HBox container = new HBox(progressBar);

            {
                progressBar.setPrefWidth(80);
                container.setAlignment(Pos.CENTER_LEFT);
            }

            @Override
            protected void updateItem(Integer pourcentage, boolean empty) {
                super.updateItem(pourcentage, empty);
                if (empty || pourcentage == null) {
                    setText(null);
                    setGraphic(null);
                    getStyleClass().removeAll("high-level", "medium-level", "low-level");
                } else {
                    double valeur = pourcentage / 100.0;
                    progressBar.setProgress(valeur);

                    // Définir les styles basés sur le pourcentage
                    progressBar.getStyleClass().removeAll("high-level-bar", "medium-level-bar", "low-level-bar");

                    if (pourcentage >= 80) {
                        progressBar.getStyleClass().add("high-level-bar");
                    } else if (pourcentage >= 50) {
                        progressBar.getStyleClass().add("medium-level-bar");
                    } else {
                        progressBar.getStyleClass().add("low-level-bar");
                    }

                    setGraphic(container);
                }
            }
        });

        dateDerniereCollecteColumn.setCellValueFactory(cellData -> {
            LocalDate date = cellData.getValue().getDateDerniereCollecte();
            return new javafx.beans.property.SimpleStringProperty(
                    date != null ? date.format(dateFormatter) : "N/A");
        });

        prochaineCollecteColumn.setCellValueFactory(cellData -> {
            LocalDate date = cellData.getValue().getProchaineCollecte();
            return new javafx.beans.property.SimpleStringProperty(
                    date != null ? date.format(dateFormatter) : "Non planifiée");
        });

        // Cellule personnalisée pour le statut
        statutColumn.setCellValueFactory(cellData -> cellData.getValue().getStatutCollecteProperty());
        statutColumn.setCellFactory(column -> new TableCell<Bac, String>() {
            @Override
            protected void updateItem(String statut, boolean empty) {
                super.updateItem(statut, empty);
                if (empty || statut == null) {
                    setText(null);
                    setGraphic(null);
                    getStyleClass().removeAll("statut-planifie", "statut-urgent", "statut-normal");
                } else {
                    setText(statut);
                    getStyleClass().removeAll("statut-planifie", "statut-urgent", "statut-normal");

                    if (statut.contains("Planifié")) {
                        getStyleClass().add("statut-planifie");
                    } else if (statut.contains("Urgent")) {
                        getStyleClass().add("statut-urgent");
                    } else {
                        getStyleClass().add("statut-normal");
                    }
                }
            }
        });

        // Configuration de la colonne d'actions
        actionsColumn.setCellFactory(new Callback<TableColumn<Bac, Void>, TableCell<Bac, Void>>() {
            @Override
            public TableCell<Bac, Void> call(final TableColumn<Bac, Void> param) {
                return new TableCell<Bac, Void>() {
                    private final Button planifierBtn = new Button("Planifier");
                    private final Button collecterBtn = new Button("Collecter");
                    private final Button detailsBtn = new Button("Détails");
                    private final HBox buttonsContainer = new HBox(5, planifierBtn, collecterBtn, detailsBtn);

                    {
                        buttonsContainer.setAlignment(Pos.CENTER);

                        // Définir une taille minimale pour les boutons
                        planifierBtn.setMinWidth(50);
                        collecterBtn.setMinWidth(50);
                        detailsBtn.setMinWidth(50);

                        // Appliquer la classe CSS pour les boutons d'action
                        planifierBtn.getStyleClass().add("action-button");
                        collecterBtn.getStyleClass().add("action-button");
                        detailsBtn.getStyleClass().add("action-button");

                        // Ajouter des tooltips pour expliquer pourquoi un bouton est désactivé
                        planifierBtn.setTooltip(new Tooltip("Planifier une collecte pour ce bac"));
                        collecterBtn.setTooltip(new Tooltip("Marquer ce bac comme collecté"));
                        detailsBtn.setTooltip(new Tooltip("Voir les détails de ce bac"));

                        planifierBtn.setOnAction(event -> {
                            Bac bac = getTableRow().getItem();
                            if (bac != null) {
                                System.out.println("Clic sur Planifier pour le bac #" + bac.getIdBac());
                                planifierCollecte(bac);
                            } else {
                                System.err.println("Erreur: Aucun bac trouvé pour l'index " + getIndex());
                            }
                        });

                        collecterBtn.setOnAction(event -> {
                            Bac bac = getTableRow().getItem();
                            if (bac != null) {
                                System.out.println("Clic sur Collecter pour le bac #" + bac.getIdBac() + " (remplissage: " + bac.getPourcentageRemplissage() + ")");
                                try {
                                    effectuerCollecte(bac);
                                } catch (Exception e) {
                                    System.err.println("Erreur lors de la collecte: " + e.getMessage());
                                    e.printStackTrace();
                                }
                            } else {
                                System.err.println("Erreur: Aucun bac trouvé pour l'index " + getIndex());
                            }
                        });

                        detailsBtn.setOnAction(event -> {
                            Bac bac = getTableRow().getItem();
                            if (bac != null) {
                                System.out.println("Clic sur Détails pour le bac #" + bac.getIdBac());
                                try {
                                    handleDetailsBac(bac);
                                } catch (Exception e) {
                                    System.err.println("Erreur lors de l'affichage des détails: " + e.getMessage());
                                    e.printStackTrace();
                                }
                            } else {
                                System.err.println("Erreur: Aucun bac trouvé pour l'index " + getIndex());
                            }
                        });
                    }

                    @Override
                    protected void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty || getTableRow().getItem() == null) {
                            setGraphic(null);
                        } else {
                            Bac bac = getTableRow().getItem();

                            // Log des informations pour déboguer
                            System.out.println("Mise à jour de la cellule pour le bac #" + bac.getIdBac() +
                                    " - Prochaine collecte: " + bac.getProchaineCollecte() +
                                    " - Remplissage: " + bac.getPourcentageRemplissage());

                            // Désactiver le bouton planifier si une collecte est déjà planifiée
                            boolean hasProchaineCollecte = bac.getProchaineCollecte() != null;
                            planifierBtn.setDisable(hasProchaineCollecte);
                            planifierBtn.getTooltip().setText(hasProchaineCollecte ? "Une collecte est déjà planifiée" : "Planifier une collecte pour ce bac");

                            // Désactiver le bouton collecter si le niveau est à 0
                            boolean niveauZero = bac.getPourcentageRemplissage() <= 0;
                            collecterBtn.setDisable(niveauZero);
                            collecterBtn.getTooltip().setText(niveauZero ? "Niveau de remplissage à 0%" : "Marquer ce bac comme collecté");

                            setGraphic(buttonsContainer);
                        }
                    }
                };
            }
        });
    }

    private void setupFilters() {
        // Initialiser la liste filtrée
        filteredBacs = new FilteredList<>(bacsData, p -> true);

        // Configure le filtre par type (couleur)
        filterTypeComboBox.getItems().add("Tous les types");
        for (Couleur couleur : Couleur.values()) {
            filterTypeComboBox.getItems().add(couleur.name());
        }
        filterTypeComboBox.setValue("Tous les types");

        // Configure le filtre par statut
        filterStatusComboBox.getItems().addAll("Tous les statuts", "À collecter", "Planifié", "Normal");
        filterStatusComboBox.setValue("Tous les statuts");

        // Application des filtres sur changement
        filterTypeComboBox.setOnAction(e -> appliquerFiltres());
        filterStatusComboBox.setOnAction(e -> appliquerFiltres());

        // Filtre de recherche
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            appliquerFiltres();
        });

        // Lier la liste filtrée triée à la TableView
        SortedList<Bac> sortedData = new SortedList<>(filteredBacs);
        sortedData.comparatorProperty().bind(collecteTableView.comparatorProperty());
        collecteTableView.setItems(sortedData);
    }

    private void appliquerFiltres() {
        filteredBacs.setPredicate(bac -> {
            // Filtre par texte de recherche
            String searchText = searchField.getText().toLowerCase();
            boolean matchSearch = searchText.isEmpty() ||
                    String.valueOf(bac.getIdBac()).toLowerCase().contains(searchText) ||
                    bac.getAdresseComplete().toLowerCase().contains(searchText);

            // Filtre par type (couleur)
            String selectedType = filterTypeComboBox.getValue();
            boolean matchType = "Tous les types".equals(selectedType) ||
                    bac.getCouleurBac().name().equals(selectedType);

            // Filtre par statut
            String selectedStatus = filterStatusComboBox.getValue();
            boolean matchStatus = "Tous les statuts".equals(selectedStatus);

            if (!matchStatus) {
                switch (selectedStatus) {
                    case "À collecter":
                        matchStatus = bac.getPourcentageRemplissage() >= 0.8;
                        break;
                    case "Planifié":
                        matchStatus = bac.getProchaineCollecte() != null;
                        break;
                    case "Normal":
                        matchStatus = bac.getPourcentageRemplissage() < 0.8 && bac.getProchaineCollecte() == null;
                        break;
                }
            }

            return matchSearch && matchType && matchStatus;
        });

        // Mettre à jour les statistiques basées sur le filtre actuel
        updateStats();
    }

    public void setCentreId(int centreId) {
        this.centreId = centreId;
        loadData();
    }

    public void setCentreName(String centreName) {
        this.centreName = centreName;
        titleLabel.setText("Gestion des Collectes - " + centreName);
    }

    private void loadData() {
        try {
            // Charger tous les bacs pour le centre
            allBacs.clear();
            List<Bac> allBacsList = bacDAO.findAllByCentre(centreId);
            allBacs.addAll(allBacsList);
            bacsData.clear();
            bacsData.addAll(allBacsList);

            // Réinitialiser les filtres
            searchField.clear();
            filterTypeComboBox.setValue("Tous les types");
            filterStatusComboBox.setValue("Tous les statuts");

            updateStats();
            updateLastRefreshTime();

            statusLabel.setText("Données chargées avec succès");
        } catch (Exception e) {
            statusLabel.setText("Erreur de chargement des données");
            System.err.println("Erreur lors du chargement des bacs: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void updateStats() {
        // Statistiques sur les bacs filtrés actuellement
        List<Bac> currentBacs = filteredBacs.stream().collect(Collectors.toList());

        // Nombre total de bacs
        totalBacsLabel.setText(String.valueOf(currentBacs.size()));

        // Taux de remplissage moyen
        double remplissageMoyen = currentBacs.stream()
                .mapToDouble(Bac::getPourcentageRemplissage)
                .average()
                .orElse(0.0) * 100;
        remplissageMoyenLabel.setText(String.format("%.1f%%", remplissageMoyen));

        // Nombre de collectes planifiées
        long collectesPlanifiees = currentBacs.stream()
                .filter(bac -> bac.getProchaineCollecte() != null)
                .count();
        collectesPlanifieesLabel.setText(String.valueOf(collectesPlanifiees));

        // Version de l'application
        versionLabel.setText("v1.2.0");
    }

    private void updateLastRefreshTime() {
        LocalTime now = LocalTime.now();
        miseAJourLabel.setText("Dernière mise à jour: " + now.format(timeFormatter));
    }

    @FXML
    private void handleRetour() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/welcome.fxml"));
            Parent dashboardPage = loader.load();
            WelcomeController controller = loader.getController();
            controller.setUserInfo("Centre de Tri", centreName, centreId);
            Scene scene = new Scene(dashboardPage);
            Stage stage = (Stage) retourButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Tableau de Bord - " + centreName);
            stage.show();
        } catch (IOException e) {
            statusLabel.setText("Erreur lors du retour au tableau de bord");
            System.err.println("Erreur lors du chargement du tableau de bord: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleActualiser() {
        loadData();
    }

    // Méthode pour valider si une date est sélectionnée et dans le futur
    private boolean isValidDate(LocalDate date) {
        return date != null && !date.isBefore(LocalDate.now());
    }

    private void planifierCollecte(Bac bac) {
        // Créer une boîte de dialogue pour choisir la date de la collecte
        Dialog<LocalDate> dialog = new Dialog<>();
        dialog.setTitle("Planifier une collecte");
        dialog.setHeaderText("Sélectionnez la date de collecte pour le bac #" + bac.getIdBac());

        // Ajouter des boutons OK et Annuler
        ButtonType planifierButtonType = new ButtonType("Planifier", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(planifierButtonType, ButtonType.CANCEL);

        // Créer un DatePicker pour sélectionner la date
        DatePicker datePicker = new DatePicker();
        LocalDate defaultDate = LocalDate.now().plusDays(1);
        datePicker.setValue(defaultDate); // Par défaut, demain
        datePicker.setPromptText("Choisissez une date");

        // Log de la date initiale
        System.out.println("Date initiale du DatePicker (planifierCollecte): " + datePicker.getValue());

        // S'assurer que la date choisie est dans le futur
        datePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isBefore(LocalDate.now()));
            }
        });

        VBox dialogContent = new VBox(10);
        dialogContent.getChildren().addAll(new Label("Date de la collecte :"), datePicker);
        dialog.getDialogPane().setContent(dialogContent);

        // Récupérer le bouton "Planifier"
        Button planifierButton = (Button) dialog.getDialogPane().lookupButton(planifierButtonType);

        // Vérifier si la date initiale est valide et activer/désactiver le bouton en conséquence
        boolean isInitialDateValid = isValidDate(datePicker.getValue());
        planifierButton.setDisable(!isInitialDateValid);
        System.out.println("État initial du bouton Planifier (planifierCollecte): " + (isInitialDateValid ? "Activé" : "Désactivé"));

        // Ajouter un listener pour activer/désactiver le bouton en fonction de la date sélectionnée
        datePicker.valueProperty().addListener((obs, oldVal, newVal) -> {
            boolean isDateValid = isValidDate(newVal);
            planifierButton.setDisable(!isDateValid);
            System.out.println("Date sélectionnée (planifierCollecte): " + newVal + " - Bouton Planifier: " + (isDateValid ? "Activé" : "Désactivé"));
        });

        // Récupérer la date sélectionnée
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == planifierButtonType) {
                return datePicker.getValue();
            }
            return null;
        });

        dialog.showAndWait().ifPresent(selectedDate -> {
            try {
                // Mettre à jour la date de la prochaine collecte dans la base de données
                boolean success = bacDAO.planifierCollecte(bac.getIdBac(), selectedDate);
                if (success) {
                    // Actualiser les données
                    loadData();
                    // Notification de succès
                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                    successAlert.setTitle("Collecte planifiée");
                    successAlert.setHeaderText(null);
                    successAlert.setContentText("La collecte du bac #" + bac.getIdBac() + " a été planifiée pour le " + selectedDate.format(dateFormatter) + ".");
                    successAlert.showAndWait();
                } else {
                    throw new Exception("Échec de la mise à jour en base de données");
                }
            } catch (Exception e) {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Erreur");
                errorAlert.setHeaderText("Échec de la planification");
                errorAlert.setContentText("Une erreur est survenue lors de la planification: " + e.getMessage());
                errorAlert.showAndWait();
                System.err.println("Erreur lors de la planification: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    private void effectuerCollecte(Bac bac) {
        Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
        confirmDialog.setTitle("Confirmation de collecte");
        confirmDialog.setHeaderText("Collecte du bac #" + bac.getIdBac());
        confirmDialog.setContentText("Êtes-vous sûr de vouloir marquer ce bac comme collecté aujourd'hui?");

        confirmDialog.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    // Appeler la méthode collecterBac de BacDAO
                    boolean success = bacDAO.collecterBac(bac.getIdBac());
                    if (success) {
                        // Actualiser les données
                        loadData();
                        // Notification de succès
                        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                        successAlert.setTitle("Collecte effectuée");
                        successAlert.setHeaderText(null);
                        successAlert.setContentText("Le bac #" + bac.getIdBac() + " a été collecté avec succès.");
                        successAlert.showAndWait();
                    } else {
                        throw new Exception("Échec de la mise à jour en base de données");
                    }
                } catch (Exception e) {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setTitle("Erreur");
                    errorAlert.setHeaderText("Échec de la collecte");
                    errorAlert.setContentText("Une erreur est survenue lors de la collecte du bac: " + e.getMessage());
                    errorAlert.showAndWait();
                    System.err.println("Erreur lors de la collecte: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        });
    }

    @FXML
    private void handlePlanifierCollecteSelection() {
        ObservableList<Bac> selectedBacs = collecteTableView.getSelectionModel().getSelectedItems();

        if (selectedBacs.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aucune sélection");
            alert.setHeaderText(null);
            alert.setContentText("Veuillez sélectionner au moins un bac à planifier.");
            alert.showAndWait();
            return;
        }

        // Filtrer les bacs qui n'ont pas déjà une collecte planifiée
        List<Bac> planifiableBacs = selectedBacs.stream()
                .filter(bac -> bac.getProchaineCollecte() == null)
                .collect(Collectors.toList());

        if (planifiableBacs.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Planification impossible");
            alert.setHeaderText(null);
            alert.setContentText("Tous les bacs sélectionnés ont déjà une collecte planifiée.");
            alert.showAndWait();
            return;
        }

        // Créer une boîte de dialogue pour choisir la date de la collecte multiple
        Dialog<LocalDate> dialog = new Dialog<>();
        dialog.setTitle("Planifier une collecte multiple");
        dialog.setHeaderText("Sélectionnez la date de collecte pour " + planifiableBacs.size() + " bac(s)");

        // Ajouter des boutons OK et Annuler
        ButtonType planifierButtonType = new ButtonType("Planifier", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(planifierButtonType, ButtonType.CANCEL);

        // Créer un DatePicker pour sélectionner la date
        DatePicker datePicker = new DatePicker();
        LocalDate defaultDate = LocalDate.now().plusDays(1);
        datePicker.setValue(defaultDate); // Par défaut, demain
        datePicker.setPromptText("Choisissez une date");

        // Log de la date initiale
        System.out.println("Date initiale du DatePicker (handlePlanifierCollecteSelection): " + datePicker.getValue());

        // S'assurer que la date choisie est dans le futur
        datePicker.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(empty || date.isBefore(LocalDate.now()));
            }
        });

        VBox dialogContent = new VBox(10);
        dialogContent.getChildren().addAll(new Label("Date de la collecte :"), datePicker);
        dialog.getDialogPane().setContent(dialogContent);

        // Récupérer le bouton "Planifier"
        Button planifierButton = (Button) dialog.getDialogPane().lookupButton(planifierButtonType);

        // Vérifier si la date initiale est valide et activer/désactiver le bouton en conséquence
        boolean isInitialDateValid = isValidDate(datePicker.getValue());
        planifierButton.setDisable(!isInitialDateValid);
        System.out.println("État initial du bouton Planifier (handlePlanifierCollecteSelection): " + (isInitialDateValid ? "Activé" : "Désactivé"));

        // Ajouter un listener pour activer/désactiver le bouton en fonction de la date sélectionnée
        datePicker.valueProperty().addListener((obs, oldVal, newVal) -> {
            boolean isDateValid = isValidDate(newVal);
            planifierButton.setDisable(!isDateValid);
            System.out.println("Date sélectionnée (handlePlanifierCollecteSelection): " + newVal + " - Bouton Planifier: " + (isDateValid ? "Activé" : "Désactivé"));
        });

        // Récupérer la date sélectionnée
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == planifierButtonType) {
                return datePicker.getValue();
            }
            return null;
        });

        dialog.showAndWait().ifPresent(selectedDate -> {
            try {
                boolean allSuccess = true;
                for (Bac bac : planifiableBacs) {
                    boolean success = bacDAO.planifierCollecte(bac.getIdBac(), selectedDate);
                    if (!success) {
                        allSuccess = false;
                        System.err.println("Échec de la planification du bac " + bac.getIdBac());
                    }
                }

                if (allSuccess) {
                    loadData();
                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                    successAlert.setTitle("Collectes planifiées");
                    successAlert.setHeaderText(null);
                    successAlert.setContentText(planifiableBacs.size() + " bac(s) ont été planifiés pour le " + selectedDate.format(dateFormatter) + ".");
                    successAlert.showAndWait();
                } else {
                    throw new Exception("Échec de la mise à jour de certains bacs");
                }
            } catch (Exception e) {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Erreur");
                errorAlert.setHeaderText("Échec de la planification");
                errorAlert.setContentText("Une erreur est survenue lors de la planification: " + e.getMessage());
                errorAlert.showAndWait();
                System.err.println("Erreur lors de la planification multiple: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    @FXML
    private void handleGenererItineraire() {
        List<Bac> bacsToCollect = filteredBacs.stream()
                .filter(bac -> bac.getProchaineCollecte() != null || bac.getPourcentageRemplissage() >= 0.5)
                .collect(Collectors.toList());

        if (bacsToCollect.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aucun bac");
            alert.setHeaderText(null);
            alert.setContentText("Aucun bac à collecter pour générer un itinéraire.");
            alert.showAndWait();
            return;
        }

        StringBuilder itineraire = new StringBuilder("Itinéraire de collecte :\n\n");
        for (Bac bac : bacsToCollect) {
            itineraire.append("Bac ")
                    .append(bac.getIdBac())
                    .append(" (")
                    .append(bac.getCouleurBac().name())
                    .append(") à ")
                    .append(bac.getAdresseComplete())
                    .append("\n");
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Itinéraire de collecte");
        alert.setHeaderText(null);
        alert.setContentText(itineraire.toString());
        alert.showAndWait();
    }

    private void handleDetailsBac(Bac bac) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Détails du Bac");
        alert.setHeaderText(null);
        alert.setContentText(
                "ID: " + bac.getIdBac() + "\n" +
                        "Couleur: " + bac.getCouleurBac().name() + "\n" +
                        "Capacité: " + bac.getCapacite() + "\n" +
                        "Contenu actuel: " + bac.getContenu() + "\n" +
                        "Niveau de remplissage: " + (int)(bac.getPourcentageRemplissage() * 100) + "%\n" +
                        "Adresse: " + bac.getAdresseComplete() + "\n" +
                        "Dernière collecte: " + (bac.getDateDerniereCollecte() != null ? bac.getDateDerniereCollecte().toString() : "N/A") + "\n" +
                        "Prochaine collecte: " + (bac.getProchaineCollecte() != null ? bac.getProchaineCollecte().toString() : "Non planifiée")
        );
        alert.showAndWait();
    }

    // Méthode pour exporter les données en CSV
    @FXML
    private void handleExportData() {
        try {
            List<Bac> currentBacs = filteredBacs.stream().collect(Collectors.toList());
            String csvContent = generateCSV(currentBacs);

            // Utiliser FileChooser pour permettre à l'utilisateur de choisir où sauvegarder le fichier
            javafx.stage.FileChooser fileChooser = new javafx.stage.FileChooser();
            fileChooser.setTitle("Exporter les données en CSV");
            fileChooser.setInitialFileName("collectes_" + LocalDate.now().format(dateFormatter).replace("/", "-") + ".csv");
            fileChooser.getExtensionFilters().add(new javafx.stage.FileChooser.ExtensionFilter("Fichiers CSV", "*.csv"));
            java.io.File file = fileChooser.showSaveDialog(collecteTableView.getScene().getWindow());

            if (file != null) {
                try (java.io.PrintWriter writer = new java.io.PrintWriter(file, "UTF-8")) {
                    writer.write(csvContent);
                    writer.flush();
                    statusLabel.setText("Données exportées avec succès dans " + file.getName());
                }
            }
        } catch (Exception e) {
            statusLabel.setText("Erreur lors de l'exportation");
            System.err.println("Erreur d'exportation: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String generateCSV(List<Bac> bacs) {
        StringBuilder csv = new StringBuilder();

        // En-têtes
        csv.append("ID;Couleur;Adresse;Niveau de remplissage;Dernière collecte;Prochaine collecte;Statut\n");

        // Données
        for (Bac bac : bacs) {
            csv.append(bac.getIdBac()).append(";");
            csv.append(bac.getCouleurBac()).append(";");
            csv.append(bac.getAdresseComplete()).append(";");
            csv.append(String.format("%.0f%%", bac.getPourcentageRemplissage() * 100)).append(";");
            csv.append(bac.getDateDerniereCollecte() != null ? bac.getDateDerniereCollecte().format(dateFormatter) : "N/A").append(";");
            csv.append(bac.getProchaineCollecte() != null ? bac.getProchaineCollecte().format(dateFormatter) : "Non planifiée").append(";");
            csv.append(bac.getStatutCollecte()).append("\n");
        }

        return csv.toString();
    }

    // Méthode pour rafraîchir les données après une collecte ou planification
    public void refreshData() {
        loadData();
    }
}