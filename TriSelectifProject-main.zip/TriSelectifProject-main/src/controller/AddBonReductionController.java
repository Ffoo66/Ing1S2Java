package controller;


import dao.BonReductionDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.BonReduction;
import main.Main;

import java.io.IOException;
import java.sql.Connection;
import java.time.LocalDate;

public class AddBonReductionController {

    @FXML private TextField commerceIdField;
    @FXML private TextField valeurField;
    @FXML private CheckBox bonUtiliseCheckBox;
    @FXML private DatePicker dateExpirationPicker;
    @FXML private Button saveButton;
    @FXML private Button goBackButton;

    private Connection conn;
    private int commerceId;

    @FXML
    private void initialize() {
        // Set default expiration date to 3 months from now
        dateExpirationPicker.setValue(LocalDate.now().plusMonths(3));
    }

    public void setConnection(Connection connection) {
        this.conn = connection;
    }

    public void setCommerceId(int commerceId) {
        this.commerceId = commerceId;
        commerceIdField.setText(String.valueOf(commerceId));
    }

    @FXML
    private void handleSave(ActionEvent event) {
        try {
            // Validate and parse inputs
            double valeur = Double.parseDouble(valeurField.getText());
            if (valeur <= 0) {
                showAlert(Alert.AlertType.WARNING, "Valeur Invalide", "La valeur doit être supérieure à 0.");
                return;
            }

            boolean bonUtilise = bonUtiliseCheckBox.isSelected();
            LocalDate dateExpiration = dateExpirationPicker.getValue();
            if (dateExpiration == null || dateExpiration.isBefore(LocalDate.now())) {
                showAlert(Alert.AlertType.WARNING, "Date Invalide", "La date d'expiration doit être dans le futur.");
                return;
            }

            // Create BonReduction
            BonReduction bon = new BonReduction(valeur, commerceId, bonUtilise, dateExpiration);
            BonReductionDAO bonReductionDAO = new BonReductionDAO(Main.conn);
           // System.out.println("before creaate");
            bonReductionDAO.create(bon);

            showAlert(Alert.AlertType.INFORMATION, "Succès", "Bon de réduction ajouté avec succès.");
            handleGoBack(event); // Return to partnership page after saving
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.WARNING, "Entrée Invalide", "Veuillez entrer une valeur numérique valide.");
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Erreur lors de l'ajout du bon de réduction: " + e.getMessage());
        }
    }

    @FXML
    private void handleGoBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/pages/ContratPartenariatPage.fxml"));
            Parent root = loader.load();
            ContratPartenariatController controller = loader.getController();
            controller.setConnection(conn);
            // Assuming centreId needs to be passed back; adjust if necessary
            Stage stage = (Stage) goBackButton.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Impossible de retourner à la page des partenariats.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}