package dao;
import main.Main;
import model.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ContratPartenariatDAO {
    private Connection conn;

    public ContratPartenariatDAO(Connection conn) {
        this.conn = conn;
    }

    public void create(ContratPartenariat cp) {
        String sql = "INSERT INTO ContratPartenariat (idCentreP, idCommerceP, estPartenaire, dateDebut, dateFin) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cp.getIdCentreP());
            stmt.setInt(2, cp.getIdCommerceP());
            stmt.setBoolean(3, cp.getEstPartner());
            stmt.setDate(4, Date.valueOf(cp.getDateDP()));
            stmt.setDate(5, Date.valueOf(cp.getDateFP()));
            stmt.executeUpdate();
            System.out.println("Contrat de partenariat ajouté.");
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public ContratPartenariat find(int idCommerce, int idCentre) {
        String sql = "SELECT * FROM ContratPartenariat WHERE idCommerceP = ? AND idCentreP = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCommerce);
            stmt.setInt(2, idCentre);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Date dateDebut = rs.getDate("dateDebut");
                Date dateFin = rs.getDate("dateFin");
                int centreId = rs.getInt("idCentreP");
                CentreTriDAO centreDao = new CentreTriDAO(conn);
                String nomCentre = centreDao.find(centreId).getNomCentre();
                Adresse adresseCentre = new Adresse(centreId, "Nom Rue", 75000, "Ville");
                CentreTri centre = new CentreTri(nomCentre, adresseCentre);
                CommerceDAO comDao = new CommerceDAO(conn);

                String nomCommerce = comDao.find(idCommerce).getNomCommerce();
                Commerce commerce = new Commerce(idCommerce,nomCommerce, adresseCentre);
                return new ContratPartenariat(centre, commerce, dateDebut.toLocalDate(), dateFin.toLocalDate());
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ContratPartenariat find( int idCentre) {
        String sql = "SELECT * FROM ContratPartenariat WHERE  idCentreP = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCentre);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int idCommerce = rs.getInt("idCommerceP");
                Date dateDebut = rs.getDate("dateDebut");
                Date dateFin = rs.getDate("dateFin");
                int centreId = rs.getInt("idCentreP");
                CentreTriDAO centreDao = new CentreTriDAO(conn);
                String nomCentre = centreDao.find(centreId).getNomCentre();
                Adresse adresseCentre = new Adresse(centreId, "Nom Rue", 75000, "Ville");
                CentreTri centre = new CentreTri(nomCentre, adresseCentre);
                CommerceDAO comDao = new CommerceDAO(conn);

                String nomCommerce = comDao.find(idCommerce).getNomCommerce();
                Commerce commerce = new Commerce(idCommerce,nomCommerce, adresseCentre);
                return new ContratPartenariat(centre, commerce, dateDebut.toLocalDate(), dateFin.toLocalDate());
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void delete(int idCommerce, int idCentre) {
        String sql = "DELETE FROM ContratPartenariat WHERE idCommerceP = ? AND idCentreP = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCommerce);
            stmt.setInt(2, idCentre);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Contrat de partenariat supprimé avec succès.");
            }
            else {
                System.out.println("Aucun Contrat de partenariat trouvé avec ces identifiants.");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<ContratPartenariat> findAll() {
        List<ContratPartenariat> contrats = new ArrayList<>();
        String sql = "SELECT * FROM ContratPartenariat";
        try (PreparedStatement stmt = Main.conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int idCommerce = rs.getInt("idCommerceP");
                int idCentre = rs.getInt("idCentreP");
                Date dateDebut = rs.getDate("dateDebut");
                Date dateFin = rs.getDate("dateFin");
                CentreTriDAO centreDao = new CentreTriDAO(conn);
                String nomCentre = centreDao.find(idCentre).getNomCentre();
                Adresse adresseCentre = new Adresse(idCentre, "Nom Rue", 75000, "Ville");
                CentreTri centre = new CentreTri(nomCentre, adresseCentre);
                CommerceDAO comDao = new CommerceDAO(conn);
                String nomCommerce = comDao.find(idCommerce).getNomCommerce();
                Commerce commerce = new Commerce(idCommerce, nomCommerce, adresseCentre);
                ContratPartenariat cp = new ContratPartenariat(centre, commerce, dateDebut.toLocalDate(), dateFin.toLocalDate());
                contrats.add(cp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return contrats;
    }

}
