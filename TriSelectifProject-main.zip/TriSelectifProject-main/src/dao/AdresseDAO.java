package dao;

import main.Main;
import model.Adresse;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static main.Main.conn;

public class AdresseDAO {
    private Connection conn;

    public AdresseDAO(Connection conne) {
//(conne != null) ? conn :
            this.conn =  Main.conn;
            if (this.conn == null) {
                throw new IllegalStateException("Database connection is null. Ensure Main.conn is properly initialized.");

        }
    }
    /**
     * Récupère toutes les adresses de la base de données.
     * @return Liste des adresses
     */
    public List<Adresse> findAll() {
        List<Adresse> adresses = new ArrayList<>();
        String query = "SELECT * FROM adresse";
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                try {
                    Adresse adresse = new Adresse(
                            rs.getInt("id"), // Changement de "idadresse" à "id"
                            rs.getInt("numero"),
                            rs.getString("nomrue"),
                            rs.getInt("codepostal"),
                            rs.getString("ville")
                    );
                    adresses.add(adresse);
                } catch (IllegalArgumentException e) {
                    System.err.println("Ignorer l'enregistrement d'adresse invalide (ID: " + rs.getInt("id") + ") : " + e.getMessage());
                }
            }
        } catch (SQLException e) {
            System.err.println("Erreur dans AdresseDAO.findAll : " + e.getMessage());
            e.printStackTrace();
        }
        return adresses;
    }


    public int create(Adresse a) {
        String sql = "INSERT INTO adresse (numero, nomrue, codepostal, ville) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, a.getNum());
            stmt.setString(2, a.getNomRue());
            stmt.setInt(3, a.getCodeP());
            stmt.setString(4, a.getVille());

            // Execute the insert statement
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                // Get the generated key (ID)
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        int id = rs.getInt(1); // Obtention de la clé générée
                        a.setId(id);
                        System.out.println("Adresse ajoutée avec ID : " + id);
                        return id;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la création de l'adresse : " + e.getMessage());
            e.printStackTrace();
        }
        return -1; // Si une erreur s'est produite ou aucune ligne n'a été affectée
    }
    public Adresse find(int adresseId) {
        String sql = "SELECT * FROM adresse WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, adresseId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Adresse(
                        rs.getInt("id"),
                        rs.getInt("numero"),
                        rs.getString("nomrue"),
                        rs.getInt("codepostal"),
                        rs.getString("ville")
                );
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche de l'adresse : " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    public boolean update(Adresse adresse, int adresseId) {
        String sql = "UPDATE adresse SET numero = ?, nomrue = ?, codepostal = ?, ville = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, adresse.getNum());
            stmt.setString(2, adresse.getNomRue());
            stmt.setInt(3, adresse.getCodeP());
            stmt.setString(4, adresse.getVille());
            stmt.setInt(5, adresseId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de la mise à jour de l'adresse : " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    public int findByAdresse(Adresse a) {
        String sql = "SELECT id FROM adresse WHERE numero = ? AND nomrue = ? AND codepostal = ? AND ville = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, a.getNum());
            stmt.setString(2, a.getNomRue());
            stmt.setInt(3, a.getCodeP());
            stmt.setString(4, a.getVille());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la vérification de l'adresse : " + e.getMessage());
            e.printStackTrace();
        }
        return -1;
    }
    public void delete(int adresseId) {
        String sql = "DELETE FROM adresse WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, adresseId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Adresse supprimée avec succès.");
            } else {
                System.out.println("Aucune adresse trouvée avec cet ID.");
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression de l'adresse : " + e.getMessage());
            e.printStackTrace();
        }
    }}