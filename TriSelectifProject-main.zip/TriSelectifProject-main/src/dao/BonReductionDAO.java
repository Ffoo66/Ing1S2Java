package dao;

import model.BonReduction;
import model.Commerce;
import model.Menage;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BonReductionDAO {
    private Connection conn;

    public BonReductionDAO(Connection conn) {
        this.conn = conn;
    }
    public void create(BonReduction bon) {
        System.out.println("whats bon");

        String sql = "INSERT INTO bonreduction (valeur, bonutilise, commerce_id, menage_id, dateexpiration) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setDouble(1, bon.getValeur());
            stmt.setBoolean(2, bon.getBonUtilise());
           // System.out.println("commerce object of bon");
            Commerce commerce = bon.getCommerce();
            //System.out.println("commerce object of bon"+commerce);

            if (commerce == null) {
                throw new IllegalStateException("Commerce is null in BonReduction");
            }
            stmt.setInt(3, bon.getCommerce().getIdCommerce());
            // Set menage_id to NULL if menage is null
            stmt.setObject(4, bon.getMenageBon() != null ? bon.getMenageBon().getId() : null);
            stmt.setDate(5, java.sql.Date.valueOf(bon.getDateExp()));
            stmt.executeUpdate();

            // Retrieve the generated idBon
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                int generatedId = rs.getInt(1);
                bon.setIdBon(generatedId);
                // Add the BonReduction to the Commerce's mapBonsC
                commerce.getMapBons().put(generatedId, bon);
                System.out.println("Bon de réduction ajouté avec ID: " + generatedId);
            } else {
                throw new SQLException("Failed to retrieve generated idBon for BonReduction");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert BonReduction into database: " + e.getMessage(), e);
        }
    }
    public List<BonReduction> findByCommerce(int commerceId) {
        List<BonReduction> bons = new ArrayList<>();
        String sql = "SELECT * FROM bonreduction WHERE commerce_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, commerceId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int idBon = rs.getInt("idbon");
                double valeur = rs.getDouble("valeur");
                boolean bonUtilise = rs.getBoolean("bonutilise");
                LocalDate dateExp = rs.getDate("dateexpiration").toLocalDate();
                BonReduction bon = new BonReduction(valeur, commerceId, bonUtilise, dateExp);
                bon.setIdBon(idBon); // Set the ID after creation
                bons.add(bon);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch BonReduction by commerce: " + e.getMessage(), e);
        }
        return bons;
    }
    public void updateMenageId(int bonId, int menageId) {
        String sql = "UPDATE bonreduction SET menage_id = ? WHERE idbon = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, menageId);
            stmt.setInt(2, bonId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No BonReduction found with idbon: " + bonId);
            }
            System.out.println("Updated menage_id for BonReduction idbon=" + bonId + " to menage_id=" + menageId);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update menage_id for BonReduction: " + e.getMessage(), e);
        }
    }


    public void updateBonUtilise(int bonId, boolean bonUtilise) {
        String sql = "UPDATE bonreduction SET bonutilise = ? WHERE idbon = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setBoolean(2, bonUtilise);
            stmt.setInt(1, bonId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("bon dachat utilisé"  + bonId);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to consume bon d'achat : " + e.getMessage(), e);
        }
    }
}