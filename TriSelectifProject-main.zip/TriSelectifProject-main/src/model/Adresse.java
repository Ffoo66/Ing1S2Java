package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static main.Main.conn;

public class Adresse {
	private int id;
	private int numero;
	private String nomRue;
	private int codePostal;
	private String ville;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNum() {
		return this.numero;
	}

	public String getNomRue() {
		return this.nomRue;
	}

	public int getCodeP() {
		return this.codePostal;
	}

	public String getVille() {
		return this.ville;
	}

	public void setNum(int nNum) {
		if (nNum > -1) {
			this.numero = nNum;
		}
	}

	public void setNomRue(String nRue) {
		if (nRue != null && !nRue.isEmpty()) {
			this.nomRue = nRue;
		}
	}

	public void setCodeP(int nCodeP) {
		if (nCodeP > 1000 && nCodeP < 100000) {
			this.codePostal = nCodeP;
		}
	}

	public void setVille(String nVille) {
		if (nVille != null && !nVille.isEmpty()) {
			this.ville = nVille;
		}
	}

	public boolean equals(Adresse a) {
		if (this == a) {
			return true;
		}
		if (a == null || this.getClass() != a.getClass()) {
			return false;
		}
		return this.codePostal == a.codePostal && this.nomRue.equals(a.nomRue) && this.numero == a.numero
				&& this.ville.equals(a.ville);
	}

	public boolean rueEquals(Adresse a) {
		if (this.equals(a)) {
			return true;
		}
		if (a == null || this.getClass() != a.getClass()) {
			return false;
		}
		return this.codePostal == a.codePostal && this.nomRue.equals(a.nomRue) && this.ville.equals(a.ville);
	}

	public String toString() {
		return "Nom rue : " + this.nomRue + "\tCode postal : " + this.codePostal;
	}


	public Adresse(int id, int nNum, String nRue, int nCodeP, String nVille) {
		if (nNum <= 0) {
			throw new IllegalArgumentException("Le numéro doit être supérieur à 0");
		}
		if (nRue == null || nRue.isEmpty()) {
			throw new IllegalArgumentException("Le nom de la rue ne peut pas être vide ou null");
		}
		if (nCodeP <= 1000 || nCodeP >= 100000) {
			throw new IllegalArgumentException("Le code postal doit être compris entre 1000 et 99999");
		}
		if (nVille == null || nVille.isEmpty()) {
			throw new IllegalArgumentException("La ville ne peut pas être vide ou null");
		}
		this.id = id;
		this.numero = nNum;
		this.nomRue = nRue;
		this.codePostal = nCodeP;
		this.ville = nVille;
	}

	public Adresse(int nNum, String nRue, int nCodeP, String nVille) {
		this(-1, nNum, nRue, nCodeP, nVille);
	}

	public Adresse(int nNum, Adresse nAdresse) {
		if (nNum > -2 && nAdresse != null) {
			this.id = -1;
			this.numero = nNum;
			this.nomRue = nAdresse.getNomRue();
			this.codePostal = nAdresse.getCodeP();
			this.ville = nAdresse.getVille();
		}
	}
}