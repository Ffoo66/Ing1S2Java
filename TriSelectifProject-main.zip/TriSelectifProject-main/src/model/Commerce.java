package model;

import java.time.LocalDate;
import java.util.HashMap;

public class Commerce {
	private Integer idCommerce; // Nullable until set from DB
	private String nomCommerce;
	private Adresse adresseCommerce;
	private HashMap<String, Double> produitsAff;
	private HashMap<Integer, BonReduction> mapBonsC;
	private HashMap<Integer, ContratPartenariat> mapPartenariats;

	public Commerce(String nom, Adresse adresse) {
		//this.idCommerce=id;
		this.nomCommerce = nom;
		this.adresseCommerce = adresse;
		this.produitsAff = new HashMap<>();
		this.mapBonsC = new HashMap<>();
		this.mapPartenariats = new HashMap<>();
	}

	public Commerce(int id,String nom, Adresse adresse) {
		this.idCommerce=id;
		this.nomCommerce = nom;
		this.adresseCommerce = adresse;
		this.produitsAff = new HashMap<>();
		this.mapBonsC = new HashMap<>();
		this.mapPartenariats = new HashMap<>();
	}
	// SETTER for ID (called after DB insert)
	public void setIdCommerce(int id) {
		this.idCommerce = id;
	}

	public int getIdCommerce() {
		return idCommerce;
	}

	public String getNomCommerce() {
		return nomCommerce;
	}

	public Adresse getAdCommerce() {
		return adresseCommerce;
	}

	public HashMap<String, Double> getProduitsAff() {
		return produitsAff;
	}

	public double getReducProduit(String produit) {
		return produitsAff.getOrDefault(produit.toLowerCase(), 0.0);
	}

	public HashMap<Integer, BonReduction> getMapBons() {
		return mapBonsC;
	}

	public HashMap<Integer, ContratPartenariat> getMapPartner() {
		return mapPartenariats;
	}

	public void setNomCommerce(String nom) {
		if (nom != null && !nom.isEmpty()) {
			this.nomCommerce = nom;
		}
	}

	public void ajoutProduitAff(String produit, double coeff) {
		produitsAff.put(produit.toLowerCase(), coeff);
	}

	public void supProduitAff(String produit) {
		produitsAff.remove(produit.toLowerCase());
	}

	public void ajoutBon(BonReduction bon) {
		mapBonsC.put(bon.getIdBon(), bon);
	}

	public void ajoutContrat(CentreTri centre, LocalDate dateDP, LocalDate dateFP) {
		ContratPartenariat contrat = new ContratPartenariat(centre, this, dateDP, dateFP);
		int centreId = contrat.getIdCentreP();
		if (mapPartenariats.containsKey(centreId)) {
			mapPartenariats.get(centreId).prolongPartner(dateDP, dateFP);
		} else {
			mapPartenariats.put(centreId, contrat);
			centre.getMapPartenaire().put(idCommerce, contrat);
		}
	}

	public double getReduction(int points, String produit) {
		if (produitsAff.containsKey(produit.toLowerCase())) {
			return Math.floor(100 * (points / 1000.0) * produitsAff.get(produit.toLowerCase())) / 100;
		}
		return 0;
	}

	@Override
	public String toString() {
		return "Nom du commerce : " + nomCommerce + "\nAdresse commerce : " + adresseCommerce;
	}

	public String toDetailedString() {
		return "Commerce {\n\tId commerce : " + idCommerce +
				"\n\tNom commerce : " + nomCommerce +
				"\n\tAdresse commerce : " + adresseCommerce +
				"\n\tProduits affectés : " + produitsAff + "\n}\n";
	}
}
