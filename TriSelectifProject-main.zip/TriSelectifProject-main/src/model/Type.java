package model;
public enum Type {
	verre,
	carton,
	plastique,
	metal,
	papier,
	autre,
	toutType
}
