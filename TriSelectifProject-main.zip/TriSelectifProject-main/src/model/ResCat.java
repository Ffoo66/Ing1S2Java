package model;
public enum ResCat {
	correct,
	incorrect,
	total
}
