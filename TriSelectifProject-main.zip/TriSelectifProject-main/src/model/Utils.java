package model;

import java.util.Random;

public class Utils {
    public static int generateRandomIntBasedOnTime() {
        long currentTime = System.currentTimeMillis(); // Get current time in milliseconds
        Random rand = new Random(currentTime);         // Seed Random with current time
        return rand.nextInt(Integer.MAX_VALUE);        // Return a positive random int
    }

    public static void main(String[] args) {
        System.out.println("Random int: " + generateRandomIntBasedOnTime());
    }
}
