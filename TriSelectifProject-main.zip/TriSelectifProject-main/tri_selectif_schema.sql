-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2025 at 09:22 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tri_selectif_v3`
--

-- --------------------------------------------------------

--
-- Table structure for table `adresse`
--

CREATE TABLE `adresse` (
                           `id` int(11) NOT NULL,
                           `numero` int(11) NOT NULL,
                           `nomrue` varchar(100) NOT NULL,
                           `codepostal` int(11) NOT NULL,
                           `ville` varchar(100) NOT NULL
) ;

--
-- Dumping data for table `adresse`
--

INSERT INTO `adresse` (`id`, `numero`, `nomrue`, `codepostal`, `ville`) VALUES
                                                                            (3, 5, 'Rue du Commerce', 69002, 'Lyon'),
                                                                            (5, 8, 'Rue de la République', 13001, 'Marseille'),
                                                                            (1, 10, 'aa', 75001, 'Paris'),
                                                                            (9, 11, 'RUEEEEA', 89999, 'FES'),
                                                                            (7, 12, 'treet', 90000, 'tanger'),
                                                                            (6, 15, 'Place Bellecour', 69002, 'Lyon'),
                                                                            (8, 18, 'RUUE', 90000, 'AGADIR'),
                                                                            (2, 25, 'Avenue des Champs-Élysées', 75008, 'Paris'),
                                                                            (4, 42, 'Boulevard Victor Hugo', 33000, 'Bordeaux'),
                                                                            (10, 1114, 'RUEEA', 90999, 'FES');

-- --------------------------------------------------------

--
-- Table structure for table `bac`
--

CREATE TABLE `bac` (
                       `idbac` int(11) NOT NULL,
                       `couleur` enum('vert','jaune','bleu','gris','toutCol') NOT NULL,
                       `capacite` int(11) NOT NULL,
                       `contenu` int(11) NOT NULL,
                       `centre_id` int(11) NOT NULL,
                       `adresse_id` int(11) NOT NULL,
                       `datedernierecollecte` date DEFAULT NULL,
                       `prochainecollecte` date DEFAULT NULL
) ;

--
-- Dumping data for table `bac`
--

INSERT INTO `bac` (`idbac`, `couleur`, `capacite`, `contenu`, `centre_id`, `adresse_id`, `datedernierecollecte`, `prochainecollecte`) VALUES
                                                                                                                                          (1, 'jaune', 200, 0, 1, 4, '2025-04-25', NULL),
                                                                                                                                          (2, 'vert', 150, 0, 1, 5, '2025-04-25', NULL),
                                                                                                                                          (492803675, 'toutCol', 122, 1, 1, 10, NULL, '2027-04-25');

-- --------------------------------------------------------

--
-- Table structure for table `bonreduction`
--

CREATE TABLE `bonreduction` (
                                `idbon` int(11) NOT NULL,
                                `valeur` double NOT NULL,
                                `bonutilise` tinyint(1) NOT NULL DEFAULT 0,
                                `commerce_id` int(11) NOT NULL,
                                `menage_id` int(11) NOT NULL,
                                `dateexpiration` date NOT NULL
) ;

--
-- Dumping data for table `bonreduction`
--

INSERT INTO `bonreduction` (`idbon`, `valeur`, `bonutilise`, `commerce_id`, `menage_id`, `dateexpiration`) VALUES
                                                                                                               (1, 15.5, 0, 1, 1, '2025-06-30'),
                                                                                                               (2, 10, 0, 2, 2, '2025-05-15');

-- --------------------------------------------------------

--
-- Table structure for table `centretri`
--

CREATE TABLE `centretri` (
                             `idcentre` int(11) NOT NULL,
                             `nomcentre` varchar(100) NOT NULL,
                             `adresse_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `centretri`
--

INSERT INTO `centretri` (`idcentre`, `nomcentre`, `adresse_id`) VALUES
    (1, 'aa', 1);

-- --------------------------------------------------------

--
-- Table structure for table `commerce`
--

CREATE TABLE `commerce` (
                            `idcommerce` int(11) NOT NULL,
                            `nomcommerce` varchar(100) NOT NULL,
                            `adresse_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `commerce`
--

INSERT INTO `commerce` (`idcommerce`, `nomcommerce`, `adresse_id`) VALUES
                                                                       (1, 'Super Marché Bio', 5),
                                                                       (2, 'Magasin Éco-Responsable', 6),
                                                                       (3, 'marjane', 7);

-- --------------------------------------------------------

--
-- Table structure for table `contratpartenariat`
--

CREATE TABLE `contratpartenariat` (
                                      `idcentrep` int(11) NOT NULL,
                                      `idcommercep` int(11) NOT NULL,
                                      `estpartenaire` tinyint(1) NOT NULL,
                                      `datedebut` date NOT NULL,
                                      `datefin` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contratpartenariat`
--

INSERT INTO `contratpartenariat` (`idcentrep`, `idcommercep`, `estpartenaire`, `datedebut`, `datefin`) VALUES
                                                                                                           (1, 1, 1, '2025-01-01', '2025-12-31'),
                                                                                                           (1, 2, 1, '2025-04-25', '2025-10-25');

-- --------------------------------------------------------

--
-- Table structure for table `depot`
--

CREATE TABLE `depot` (
                         `iddepot` int(11) NOT NULL,
                         `poidsdepot` int(11) NOT NULL,
                         `couleur` enum('vert','jaune','bleu','gris','toutCol') NOT NULL,
                         `typedechet` enum('verre','carton','plastique','metal','papier','autre','toutType') NOT NULL,
                         `resultat` enum('correct','incorrect','total') NOT NULL,
                         `pointsgagnes` int(11) NOT NULL DEFAULT 0,
                         `datedepot` date NOT NULL,
                         `heuredepot` time NOT NULL,
                         `adresse_id` int(11) NOT NULL,
                         `menage_id` int(11) NOT NULL
) ;

--
-- Dumping data for table `depot`
--

INSERT INTO `depot` (`iddepot`, `poidsdepot`, `couleur`, `typedechet`, `resultat`, `pointsgagnes`, `datedepot`, `heuredepot`, `adresse_id`, `menage_id`) VALUES
                                                                                                                                                             (1, 8, 'jaune', 'plastique', 'correct', 25, '2025-04-15', '10:30:00', 4, 1),
                                                                                                                                                             (2, 12, 'vert', 'verre', 'correct', 30, '2025-04-18', '15:45:00', 5, 2),
                                                                                                                                                             (175586691, 111, 'bleu', 'plastique', 'correct', 222, '2025-04-25', '19:22:00', 5, 1),
                                                                                                                                                             (289036633, 111, 'vert', 'verre', 'correct', 222, '2025-04-24', '11:11:00', 2, 1),
                                                                                                                                                             (1696691467, 113, 'vert', 'carton', 'correct', 226, '2025-04-25', '12:59:00', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `menage`
--

CREATE TABLE `menage` (
                          `id` int(11) NOT NULL,
                          `nomcompte` varchar(50) DEFAULT NULL,
                          `motdepasse` varchar(100) NOT NULL,
                          `pointsfidelite` int(11) NOT NULL DEFAULT 0,
                          `adresse_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menage`
--

INSERT INTO `menage` (`id`, `nomcompte`, `motdepasse`, `pointsfidelite`, `adresse_id`) VALUES
                                                                                           (1, 'aa', 'aa', 150, 4),
                                                                                           (2, 'Famille Martin', 'password456', 85, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adresse`
--
ALTER TABLE `adresse`
    ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `adresse_numero_nomrue_codepostal_ville_key` (`numero`,`nomrue`,`codepostal`,`ville`);

--
-- Indexes for table `bac`
--
ALTER TABLE `bac`
    ADD PRIMARY KEY (`idbac`),
  ADD KEY `bac_centre_id_fkey` (`centre_id`),
  ADD KEY `bac_adresse_id_fkey` (`adresse_id`);

--
-- Indexes for table `bonreduction`
--
ALTER TABLE `bonreduction`
    ADD PRIMARY KEY (`idbon`),
  ADD KEY `bonreduction_commerce_id_fkey` (`commerce_id`),
  ADD KEY `bonreduction_menage_id_fkey` (`menage_id`);

--
-- Indexes for table `centretri`
--
ALTER TABLE `centretri`
    ADD PRIMARY KEY (`idcentre`),
  ADD UNIQUE KEY `centretri_nomcentre_key` (`nomcentre`),
  ADD KEY `centretri_adresse_id_fkey` (`adresse_id`);

--
-- Indexes for table `commerce`
--
ALTER TABLE `commerce`
    ADD PRIMARY KEY (`idcommerce`),
  ADD UNIQUE KEY `commerce_nomcommerce_key` (`nomcommerce`),
  ADD KEY `commerce_adresse_id_fkey` (`adresse_id`);

--
-- Indexes for table `contratpartenariat`
--
ALTER TABLE `contratpartenariat`
    ADD PRIMARY KEY (`idcentrep`,`idcommercep`),
  ADD KEY `contratpartenariat_idcommercep_fkey` (`idcommercep`);

--
-- Indexes for table `depot`
--
ALTER TABLE `depot`
    ADD PRIMARY KEY (`iddepot`),
  ADD KEY `depot_adresse_id_fkey` (`adresse_id`),
  ADD KEY `depot_menage_id_fkey` (`menage_id`);

--
-- Indexes for table `menage`
--
ALTER TABLE `menage`
    ADD PRIMARY KEY (`id`),
  ADD KEY `menage_adresse_id_fkey` (`adresse_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adresse`
--
ALTER TABLE `adresse`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bac`
--
ALTER TABLE `bac`
    MODIFY `idbac` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bonreduction`
--
ALTER TABLE `bonreduction`
    MODIFY `idbon` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `centretri`
--
ALTER TABLE `centretri`
    MODIFY `idcentre` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `commerce`
--
ALTER TABLE `commerce`
    MODIFY `idcommerce` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `depot`
--
ALTER TABLE `depot`
    MODIFY `iddepot` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menage`
--
ALTER TABLE `menage`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bac`
--
ALTER TABLE `bac`
    ADD CONSTRAINT `bac_adresse_id_fkey` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bac_centre_id_fkey` FOREIGN KEY (`centre_id`) REFERENCES `centretri` (`idcentre`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bonreduction`
--
ALTER TABLE `bonreduction`
    ADD CONSTRAINT `bonreduction_commerce_id_fkey` FOREIGN KEY (`commerce_id`) REFERENCES `commerce` (`idcommerce`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bonreduction_menage_id_fkey` FOREIGN KEY (`menage_id`) REFERENCES `menage` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `centretri`
--
ALTER TABLE `centretri`
    ADD CONSTRAINT `centretri_adresse_id_fkey` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `commerce`
--
ALTER TABLE `commerce`
    ADD CONSTRAINT `commerce_adresse_id_fkey` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contratpartenariat`
--
ALTER TABLE `contratpartenariat`
    ADD CONSTRAINT `contratpartenariat_idcentrep_fkey` FOREIGN KEY (`idcentrep`) REFERENCES `centretri` (`idcentre`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `contratpartenariat_idcommercep_fkey` FOREIGN KEY (`idcommercep`) REFERENCES `commerce` (`idcommerce`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `depot`
--
ALTER TABLE `depot`
    ADD CONSTRAINT `depot_adresse_id_fkey` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `depot_menage_id_fkey` FOREIGN KEY (`menage_id`) REFERENCES `menage` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `menage`
--
ALTER TABLE `menage`
    ADD CONSTRAINT `menage_adresse_id_fkey` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
